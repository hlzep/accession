# Accession

A slow, careful tour through the history of art.

## What this is

A Duolingo-style PWA for learning art history, anchored at the Met and expanding chronologically. Built in vanilla HTML/CSS/JS for GitHub Pages, mobile-first, mostly offline, with optional Firebase sync for live leaderboard competition.

## To run locally

Any static server works:

```sh
cd accession
python3 -m http.server 8000
# Open http://localhost:8000 on your phone or laptop
```

Or just open `accession-preview.html` directly in a browser — that's the bundled single-file version.

## To deploy to GitHub Pages

1. Create a new GitHub repo named `accession` (or anything).
2. Upload all files in this folder to the root of the repo.
3. Settings → Pages → Source: deploy from branch, main, root.
4. The app will be at `https://YOUR-USERNAME.github.io/accession/`.

## To enable live leaderboard with Brandon

Open `js/core/sync.js` and follow the comment instructions at the top:

1. Make a free Firebase project at console.firebase.google.com.
2. Enable Realtime Database, paste the rules block from the comment.
3. Copy the `firebaseConfig` object from Firebase, paste it into `FIREBASE_CONFIG`.
4. Reload. Both your apps will sync automatically.

Until you configure Firebase, the app runs in pure-local mode — everything works, you just can't see Brandon's stats live.

## Architecture

- **Vanilla JS modules** in `js/`. No build step, no framework.
- **Single source of truth** is `localStorage`, accessed via `js/core/state.js`.
- **Content** lives as JSON in `data/`. Hand-authored so it can be edited.
- **Author mode** unlocks via 5-taps on the profile avatar; lets you override any wall label without editing files.
- **Met Open Access images** are fetched at runtime via the Met API; no big JPEGs in the bundle.

## What's in this MVP

- 6 movements (Egyptian through American Modernism)
- 9 artworks, mostly Met
- 2 fully built lessons (Dutch Golden Age, Impressionism)
- Today, Learn, Collection, Profile tabs
- Onboarding with museum checklist and walkthrough
- Streak system with wax seal + Sunday rest day
- Curator ranks per movement
- Constellation map of mastered works
- PWA manifest + service worker for installable offline use

## What's not in yet

- More lessons (only 2 of a planned ~24)
- Final Exhibitions (boss quizzes)
- Head-to-head challenges
- Author mode editor UI (the data layer is ready, the UI isn't)
- Better imagery for copyrighted works (Hopper, O'Keeffe)
