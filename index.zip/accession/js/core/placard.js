/* ============================================================
   ACCESSION - PLACARD GENERATOR
   Builds a museum-placard SVG for any artwork. Used as the visual
   fallback when no image is available (copyrighted works, offline
   use, or while the Met API request is in flight).

   Returns a data: URL string suitable for use as <img src>.
   Cached per artwork ID for performance.
   ============================================================ */

import { getArtist, getMovement } from './content.js';

const cache = new Map();

const MUSEUM_LABELS = {
  'met':             'THE MET · NEW YORK',
  'british-museum':  'BRITISH MUSEUM · LONDON',
  'louvre':          'MUSÉE DU LOUVRE · PARIS',
  'pergamon-museum': 'PERGAMON MUSEUM · BERLIN',
  'vatican-museums': 'VATICAN MUSEUMS',
};

function locationLabel(artwork) {
  if (artwork.museumId && MUSEUM_LABELS[artwork.museumId]) {
    return MUSEUM_LABELS[artwork.museumId];
  }
  if (artwork.originLabel) return artwork.originLabel.toUpperCase();
  return 'PERMANENT COLLECTION';
}

/**
 * Build a placard SVG for an artwork and return it as a data: URL.
 * Designed to look like a museum wall label — restrained, editorial,
 * on-brand. Always returns something usable, even with missing data.
 */
export function buildPlacard(artwork) {
  if (!artwork) return '';
  if (cache.has(artwork.id)) return cache.get(artwork.id);

  const artist = artwork.artistId ? getArtist(artwork.artistId) : null;
  const movement = getMovement(artwork.movementId);
  const yearLabel = formatYear(artwork.year);
  const accentColor = movement?.color || '#7A6A55';
  const initials = (artist?.shortName || artwork.title || '?').charAt(0).toUpperCase();

  // Use 400x300 to match a 4:3 aspect ratio.
  // The SVG uses our paper palette so it blends with the card backgrounds.
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="g${hash(artwork.id)}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#FBF7EE"/>
        <stop offset="100%" stop-color="#ECE3D2"/>
      </linearGradient>
      <pattern id="p${hash(artwork.id)}" x="0" y="0" width="6" height="6" patternUnits="userSpaceOnUse">
        <circle cx="3" cy="3" r="0.4" fill="${accentColor}" opacity="0.12"/>
      </pattern>
    </defs>
    <rect width="400" height="300" fill="url(#g${hash(artwork.id)})"/>
    <rect width="400" height="300" fill="url(#p${hash(artwork.id)})"/>
    <rect x="20" y="20" width="360" height="260" fill="none" stroke="${accentColor}" stroke-width="0.5" opacity="0.4"/>

    <!-- Large initial as a quiet visual anchor -->
    <text x="200" y="135" font-family="DM Serif Display, Georgia, serif" font-size="86" fill="${accentColor}" text-anchor="middle" opacity="0.18">${escapeXml(initials)}</text>

    <!-- Movement eyebrow -->
    <text x="200" y="175" font-family="Inter, sans-serif" font-size="9" font-weight="500" letter-spacing="2" fill="#7A6A55" text-anchor="middle">${escapeXml((movement?.shortName || '').toUpperCase())}</text>

    <!-- Title -->
    <text x="200" y="208" font-family="DM Serif Display, Georgia, serif" font-size="18" fill="#1F1B16" text-anchor="middle">${escapeXml(truncate(artwork.title, 36))}</text>

    <!-- Artist + year -->
    <text x="200" y="232" font-family="Lora, Georgia, serif" font-style="italic" font-size="12" fill="#7A6A55" text-anchor="middle">${escapeXml(artist?.name || 'Anonymous')} · ${escapeXml(yearLabel)}</text>

    <!-- Small accession plaque at bottom -->
    <line x1="170" y1="252" x2="230" y2="252" stroke="${accentColor}" stroke-width="0.5" opacity="0.4"/>
    <text x="200" y="270" font-family="Inter, sans-serif" font-size="8" letter-spacing="1.5" fill="#B8A88E" text-anchor="middle">${escapeXml(locationLabel(artwork))}</text>
  </svg>`;

  const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  cache.set(artwork.id, url);
  return url;
}

/**
 * Hash a string into a short ID for use in SVG defs.
 * Avoids collisions when multiple placards are on the page at once.
 */
function hash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h) + s.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h).toString(36);
}

function escapeXml(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function truncate(s, max) {
  if (!s) return '';
  return s.length > max ? s.slice(0, max - 1) + '…' : s;
}

function formatYear(year) {
  if (!year && year !== 0) return '';
  if (year < 0) return `${Math.abs(year)} BCE`;
  return String(year);
}
