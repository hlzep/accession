/* ============================================================
   ACCESSION - ARTWORK ORIGIN MAP
   Renders an accurate world map using Natural Earth 110m data
   fetched from CDN. The map shows where an artwork was made.

   On first load (online): fetches world-atlas topojson from CDN,
   decodes with topojson-client, projects with d3-geo, caches path.
   On subsequent renders: uses cached SVG path string.
   Fallback (offline/error): shows a simple ocean rectangle with pin.
   ============================================================ */

export const MAP_W = 320;
export const MAP_H = 160;

// Module-level cache
let _pathCache = null;
let _loadPromise = null;

function pxCoord(lat, lng) {
  const x = Math.round(((lng + 180) / 360) * MAP_W * 10) / 10;
  const y = Math.round(((83 - lat) / 166) * MAP_H * 10) / 10;
  return [x, y];
}

function geoPathString(geojson) {
  // Convert GeoJSON geometry to equirectangular SVG path
  // geojson is a Feature or FeatureCollection or GeometryCollection
  const features = geojson.type === 'FeatureCollection' ? geojson.features
    : geojson.type === 'Feature' ? [geojson]
    : [{ geometry: geojson }];

  let d = '';
  for (const f of features) {
    const geom = f.geometry || f;
    const type = geom.type;
    const coords = geom.coordinates;
    const polys = type === 'Polygon' ? [coords]
      : type === 'MultiPolygon' ? coords : [];

    for (const poly of polys) {
      const ring = poly[0];
      if (!ring || ring.length < 3) continue;
      const pts = [];
      for (const [lon, lat] of ring) {
        const clat = Math.max(-83, Math.min(83, lat));
        const [x, y] = pxCoord(clat, lon);
        if (!pts.length || pts[pts.length-1] !== `${x},${y}`) {
          pts.push(`${x},${y}`);
        }
      }
      if (pts.length >= 3) d += `M${pts.join('L')}Z `;
    }
  }
  return d.trim();
}

async function loadWorldPath() {
  if (_pathCache) return _pathCache;
  if (_loadPromise) return _loadPromise;

  _loadPromise = (async () => {
    try {
      // Load topojson client
      const [topoData, topoLibText] = await Promise.all([
        fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json').then(r => r.json()),
        fetch('https://cdnjs.cloudflare.com/ajax/libs/topojson/3.0.2/topojson.min.js').then(r => r.text()),
      ]);

      // Execute topojson library in isolated scope
      const modObj = { exports: {} };
      // eslint-disable-next-line no-new-func
      new Function('module', 'exports', topoLibText)(modObj, modObj.exports);
      const topojson = modObj.exports;

      // Decode land polygons
      const land = topojson.feature(topoData, topoData.objects.land);

      _pathCache = geoPathString(land);
      // Update any waiting map elements
      document.querySelectorAll('[data-map-pending]').forEach(el => {
        const pathEl = el.querySelector('path[data-world]');
        if (pathEl) pathEl.setAttribute('d', _pathCache);
        el.removeAttribute('data-map-pending');
      });
      return _pathCache;
    } catch (err) {
      console.warn('[Accession] Map world path failed:', err.message);
      return null;
    }
  })();

  return _loadPromise;
}

// Pre-fetch on module load
if (typeof window !== 'undefined') loadWorldPath();

function renderSVG(worldPath, pinMarkup, lineMarkup) {
  const w = MAP_W, h = MAP_H;
  return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg"
      style="width:100%;height:100%;display:block;" shape-rendering="geometricPrecision">
    <rect width="${w}" height="${h}" fill="#EDE4D3"/>
    <path data-world="1" d="${worldPath || ''}" fill="#C8B898"
      stroke="#1F1B16" stroke-width="0.5" stroke-opacity="0.2" fill-rule="evenodd"/>
    <line x1="0" y1="${h/2}" x2="${w}" y2="${h/2}"
      stroke="#1F1B16" stroke-width="0.3" stroke-opacity="0.12" stroke-dasharray="2 5"/>
    ${lineMarkup || ''}${pinMarkup || ''}
  </svg>`;
}

function pinMarkup(x, y) {
  return `<circle cx="${x}" cy="${y}" r="9" fill="#6B2E2E" fill-opacity="0.15"/>
    <circle cx="${x}" cy="${y}" r="5" fill="#6B2E2E" stroke="#F5EFE4" stroke-width="1.5"/>
    <circle cx="${x-1.5}" cy="${y-1.5}" r="1.5" fill="#F5EFE4" fill-opacity="0.5"/>`;
}

/**
 * Build a map div for a single artwork origin.
 * Renders immediately (possibly without world outline if not yet loaded),
 * then upgrades itself once the world path is available.
 */
export function buildArtworkMap(lat, lng, label) {
  if (lat == null || lng == null) return '';
  const [pinX, pinY] = pxCoord(lat, lng);
  if (pinX < 2 || pinX > MAP_W - 2 || pinY < 2 || pinY > MAP_H - 2) return '';

  const lbl = label || '';
  const worldPath = _pathCache || '';
  const pending = worldPath ? '' : ' data-map-pending="1"';
  const svg = renderSVG(worldPath, pinMarkup(pinX, pinY), '');

  return `<div class="artwork-map"${pending}${lbl ? ` aria-label="Origin: ${lbl}"` : ''}>
    ${svg}${lbl ? `<div class="artwork-map__label">${lbl}</div>` : ''}
  </div>`;
}

/**
 * Build a multi-pin comparison map.
 */
export function buildComparisonMap(points) {
  if (!points || !points.length) return '';
  const valid = points.filter(p => p.lat != null && p.lng != null);
  if (!valid.length) return '';

  const pins = valid.map(p => {
    const [x, y] = pxCoord(p.lat, p.lng);
    if (x < 2 || x > MAP_W - 2 || y < 2 || y > MAP_H - 2) return '';
    return pinMarkup(x, y);
  }).join('');

  const lines = valid.slice(0,-1).map((p,i) => {
    const [x1,y1] = pxCoord(p.lat,p.lng);
    const [x2,y2] = pxCoord(valid[i+1].lat,valid[i+1].lng);
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"
      stroke="#6B2E2E" stroke-width="0.8" stroke-opacity="0.3" stroke-dasharray="3 3"/>`;
  }).join('');

  const worldPath = _pathCache || '';
  const pending = worldPath ? '' : ' data-map-pending="1"';
  const svg = renderSVG(worldPath, pins, lines);

  return `<div class="artwork-map artwork-map--comparison"${pending} aria-hidden="true">
    ${svg}
  </div>`;
}
