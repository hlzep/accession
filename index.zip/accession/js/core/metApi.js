/* ============================================================
   ACCESSION - MET API RESOLVER
   Fetches canonical CC0 image URLs from the Met Open Access API
   the first time an artwork is rendered. Caches in localStorage
   so subsequent loads are instant and don't hit the API.

   Why runtime?
   - Image URLs at the Met have shifted historically; resolving at runtime
     means we always get whatever is current.
   - Two of our nine artworks (Hopper, O'Keeffe) are still under copyright,
     and the API correctly returns no primaryImage — we fall back to
     placeholder automatically with no special-casing.
   - The bundle stays tiny: we don't ship multi-megabyte JPEGs.
   ============================================================ */

const CACHE_KEY = 'accession:metImageCache:v1';
const API_BASE = 'https://collectionapi.metmuseum.org/public/collection/v1/objects';

let metImageCache = null;
const inFlight = new Map(); // metObjectId -> Promise

function loadCache() {
  if (metImageCache !== null) return metImageCache;
  try {
    metImageCache = JSON.parse(localStorage.getItem(CACHE_KEY) || '{}');
  } catch {
    metImageCache = {};
  }
  return metImageCache;
}

function saveCache() {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(metImageCache));
  } catch (e) {
    console.warn('Failed to save Met metImageCache:', e);
  }
}

/**
 * Resolve an artwork's image URL by Met object ID. Returns a Promise that
 * resolves to a string URL or null. Null means "use placeholder."
 *
 * Caches both hits (URL) and misses (null) to avoid re-fetching.
 */
export async function resolveMetImage(metObjectId) {
  if (!metObjectId) return null;
  const cacheCopy = loadCache();
  const key = String(metObjectId);
  if (key in cacheCopy) return cacheCopy[key];
  if (inFlight.has(key)) return inFlight.get(key);

  const promise = (async () => {
    try {
      const res = await fetch(`${API_BASE}/${metObjectId}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      // primaryImageSmall is the IIIF "web-large" derivative, perfect for mobile.
      // Falls back to primaryImage if that field is missing.
      const url = data.primaryImageSmall || data.primaryImage || null;
      cacheCopy[key] = url || null;
      saveCache();
      return url || null;
    } catch (err) {
      // On error, metImageCache null so we don't hammer the API on every load.
      cacheCopy[key] = null;
      saveCache();
      return null;
    } finally {
      inFlight.delete(key);
    }
  })();
  inFlight.set(key, promise);
  return promise;
}

/**
 * Convenience: hydrate an <img> element. Sets src once the URL resolves
 * to a real photo. If resolution fails (CORS, offline, copyright), the
 * element keeps its current placard src so the card still looks complete.
 */
export function hydrateMetImage(imgEl, metObjectId) {
  if (!imgEl || !metObjectId) return;
  resolveMetImage(metObjectId).then(url => {
    if (!url) return;
    // Test that the image actually loads before swapping out the placard.
    // This handles cases where the URL resolves but the image 404s.
    const test = new Image();
    test.onload = () => { imgEl.src = url; };
    test.onerror = () => { /* keep the placard */ };
    test.src = url;
  }).catch(() => { /* keep the placard */ });
}

/**
 * Resolve all artworks in a list, optionally returning a map of id -> url.
 * Useful for views that render many works at once.
 */
export async function preloadMetImages(artworks) {
  await Promise.all(artworks.map(a => resolveMetImage(a.metObjectId)));
}
