/* ============================================================
   ACCESSION - STATE MANAGEMENT
   The single source of truth for user data.
   Persists to localStorage on every change.

   VERSIONING & MIGRATIONS
   -----------------------
   Saved state carries a `schemaVersion` field. The migrations
   below run in sequence to bring an older save up to current.
   When you change the state shape in an incompatible way:
     1. Bump CURRENT_SCHEMA_VERSION
     2. Add a migration function to MIGRATIONS keyed by the old
        version it accepts
     3. Test by hand-editing a localStorage payload to the old
        version and reloading
   The merge with DEFAULT_STATE handles additive changes (new
   fields) automatically — only write a migration when you need
   to restructure or backfill existing data.
   ============================================================ */

const STORAGE_KEY = 'accession:userState:v1';
const CURRENT_SCHEMA_VERSION = 3;

// Migration functions: each takes a state and returns the next-version state.
// Keyed by the version it accepts. Run in sequence until current.
const MIGRATIONS = {
  // v2 -> v3: add SRS (spaced repetition) fields.
  // Existing artworkState entries get default SRS values.
  2: function(s) {
    // Add session counter
    if (!s.sessionCount) s.sessionCount = 0;
    // Add review queue if missing
    if (!s.reviewQueue) s.reviewQueue = {};
    // Backfill: any artwork the user has encountered gets an initial SRS entry
    for (const artId in (s.artworkState || {})) {
      const as = s.artworkState[artId];
      if (as.encountered && !s.reviewQueue[artId]) {
        s.reviewQueue[artId] = {
          // Due in 3 sessions (they've already seen it)
          dueAtSession: (s.sessionCount || 0) + 3,
          intervalIndex: 1,   // index into SRS_INTERVALS
          consecutiveMisses: 0,
          quizTier: 'recognition',
          wallLabelDue: (s.sessionCount || 0) + 5,
        };
      }
    }
    s.schemaVersion = 3;
    return s;
  },
  // v1 didn't have cellCompletions; v2 derives them so Z-axis "new content
  // added" detection works for users who completed lessons before we added
  // the cellCompletions tracking.
  1: function(s) {
    if (!s.cellCompletions) s.cellCompletions = {};
    // Map legacy movement IDs to their era:region cells so older
    // completions register as "you've already seen this cell."
    const legacyMap = {
      'egyptian-ancient':      'ancient-worlds:middle-east-north-africa',
      'italian-renaissance':   'renaissances-empires:europe',
      'northern-renaissance':  'renaissances-empires:europe',
      'dutch-golden-age':      'renaissances-empires:europe',
      'impressionism':         'revolution-industry:europe',
      'american-modernism':    'modernism:americas',
    };
    for (const movId in (s.movementProgress || {})) {
      const cellKey = legacyMap[movId];
      if (cellKey && (s.movementProgress[movId].lessonsCompleted || []).length > 0) {
        // Use the current time as a placeholder completion time
        if (!s.cellCompletions[cellKey]) {
          s.cellCompletions[cellKey] = new Date().toISOString();
        }
      }
    }
    s.schemaVersion = 2;
    return s;
  },
};

// Default state shape. Every property must exist here so that
// upgrades from older versions are predictable.
const DEFAULT_STATE = {
  // Schema version — incremented when state shape changes
  schemaVersion: CURRENT_SCHEMA_VERSION,

  // User identity
  userId: null,
  displayName: null,
  partnerName: null,

  // Onboarding
  hasCompletedIntro: false,
  hasCompletedWalkthrough: false,
  visitedMuseums: [],

  // Streak
  streakDays: 0,
  lastSessionDate: null,

  // Session counter — incremented once per app open.
  // Used by the SRS system instead of calendar days.
  sessionCount: 0,

  // Spaced repetition review queue.
  // { [artworkId]: { dueAtSession, intervalIndex, consecutiveMisses, quizTier, wallLabelDue } }
  reviewQueue: {},

  // Per-artwork state
  artworkState: {},

  // Per-movement progress (legacy, kept for compatibility)
  movementProgress: {},

  // NEW (global thesis): Per-cell completion timestamps.
  // Keyed by "${eraId}:${regionId}". Used to detect newly added content.
  cellCompletions: {},

  // NEW: Track the last gap-size we nudged about, so we don't nag.
  lastSyncNudgeGap: 0,

  // NEW: Has the user dismissed the "new content added" prompts for these works?
  acknowledgedNewArtworks: [],

  // NEW: Free Explore mode — when true, the synchronization rule is silent.
  freeExploreMode: false,

  // Per-movement curator rank (legacy)
  curatorRanks: {},

  // Author mode edits
  authorEdits: {},
  authorModeUnlocked: false,

  // App settings
  settings: {
    reducedMotion: false,
  },
};

// In-memory copy of state, mutated then saved.
let state = null;

/**
 * Load state from localStorage, or initialize defaults.
 * Always returns a complete state object.
 *
 * On load, runs any pending migrations to bring older saves up to
 * the current schema version. Failed loads fall back to a fresh
 * state — and we attempt to preserve the unparseable raw data
 * under a backup key so the user could recover manually.
 */
export function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      state = createFreshState();
      saveState();
      return state;
    }
    let parsed = JSON.parse(raw);

    // Treat missing schemaVersion as v1 (we introduced versioning in v2)
    const version = parsed.schemaVersion || 1;
    if (version < CURRENT_SCHEMA_VERSION) {
      // Snapshot the pre-migration state so we can recover if the
      // migration is buggy. Overwrites any previous pre-migration backup.
      try {
        localStorage.setItem(
          STORAGE_KEY + ':pre-migration-v' + version,
          raw
        );
      } catch (_) { /* quota errors are non-fatal */ }
      parsed = runMigrations(parsed, version);
    }

    // Merge with defaults to handle additively-added fields
    state = { ...DEFAULT_STATE, ...parsed };
    return state;
  } catch (err) {
    console.warn('Failed to load state:', err);
    // Preserve corrupt data so the user can recover if needed
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) localStorage.setItem(STORAGE_KEY + ':corrupt-backup', raw);
    } catch (_) {}
    state = createFreshState();
    saveState();
    return state;
  }
}

/**
 * Run all migrations from `fromVersion` up to CURRENT_SCHEMA_VERSION.
 */
function runMigrations(s, fromVersion) {
  let current = s;
  for (let v = fromVersion; v < CURRENT_SCHEMA_VERSION; v++) {
    const migrate = MIGRATIONS[v];
    if (migrate) {
      try {
        current = migrate(current);
      } catch (err) {
        console.warn(`Migration v${v} -> v${v + 1} failed, keeping prior state:`, err);
      }
    }
  }
  return current;
}

/**
 * Create a fresh state object with a generated user ID.
 */
function createFreshState() {
  return {
    ...DEFAULT_STATE,
    userId: generateUserId(),
  };
}

/**
 * Generate a simple user ID. Not cryptographically secure;
 * just unique enough to identify this user's writes to Firebase.
 */
function generateUserId() {
  return 'u_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

/**
 * Get the current state. Read-only — use updateState to modify.
 */
export function getState() {
  if (!state) loadState();
  return state;
}

/**
 * Update state with a partial object or a mutation function.
 * Saves to localStorage and notifies listeners.
 */
export function updateState(patch) {
  if (!state) loadState();
  if (typeof patch === 'function') {
    patch(state);
  } else {
    Object.assign(state, patch);
  }
  saveState();
  notifyListeners();
}

/**
 * Save state to localStorage. Called automatically by updateState.
 */
function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save state:', err);
  }
}

/**
 * Reset all state (for testing, or "start over" feature).
 */
export function resetState() {
  state = createFreshState();
  saveState();
  notifyListeners();
}

// Simple pub/sub for state changes
const listeners = new Set();

export function onStateChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function notifyListeners() {
  listeners.forEach(fn => {
    try { fn(state); } catch (err) { console.error(err); }
  });
}

/* ===== Convenience helpers for specific state operations ===== */

/**
 * Mark an artwork as encountered (shown to the user at least once).
 */
export function markEncountered(artworkId) {
  updateState(s => {
    if (!s.artworkState[artworkId]) {
      s.artworkState[artworkId] = { encountered: false, masteredCount: 0, seenInPerson: null };
    }
    s.artworkState[artworkId].encountered = true;
    s.artworkState[artworkId].lastSeenAt = new Date().toISOString();
  });
}

/**
 * Mark an artwork as correctly identified in a quiz.
 * Increments mastery count.
 */
export function markMastered(artworkId) {
  updateState(s => {
    if (!s.artworkState[artworkId]) {
      s.artworkState[artworkId] = { encountered: true, masteredCount: 0, seenInPerson: null };
    }
    s.artworkState[artworkId].masteredCount += 1;
    s.artworkState[artworkId].lastSeenAt = new Date().toISOString();
  });
}

/**
 * Record the user's response to "have you seen this in person?"
 * value can be 'yes', 'no', or 'maybe'.
 */
export function setSeenInPerson(artworkId, value) {
  updateState(s => {
    if (!s.artworkState[artworkId]) {
      s.artworkState[artworkId] = { encountered: true, masteredCount: 0 };
    }
    s.artworkState[artworkId].seenInPerson = value;
  });
}

/**
 * Mark a lesson as completed within a movement.
 */
/**
 * Mark a lesson as completed. The first argument is a "scope key" — could be
 * a movementId (legacy) or an eraId (new model) or any other grouping. The
 * lesson record is stored in s.movementProgress for backward compat.
 */
export function markLessonCompleted(scopeKey, lessonId) {
  if (!scopeKey) scopeKey = '_global';  // Fall-through bucket
  updateState(s => {
    if (!s.movementProgress[scopeKey]) {
      s.movementProgress[scopeKey] = { lessonsCompleted: [], finalExhibitionPassed: false };
    }
    if (!s.movementProgress[scopeKey].lessonsCompleted.includes(lessonId)) {
      s.movementProgress[scopeKey].lessonsCompleted.push(lessonId);
    }
  });
}

/**
 * Update streak based on whether the user did any activity today.
 *
 * Rules:
 *  - Same day: no change (already counted).
 *  - Consecutive calendar day: increment.
 *  - One missed day (grace): streak preserved and incremented — a single
 *    skipped day does not break the streak.
 *  - Missed day was a Sunday (rest day): preserved across the gap.
 *  - Gap larger than the grace allowance: reset to 1.
 *
 * Day math is done on local calendar dates to avoid timezone drift.
 */
export function tickStreak() {
  const todayDate = startOfLocalDay(new Date());
  const today = localDayString(todayDate);
  const s = getState();

  if (s.lastSessionDate === today) {
    return; // already counted today
  }

  if (!s.lastSessionDate) {
    updateState({ streakDays: 1, lastSessionDate: today });
    return;
  }

  const lastDate = parseLocalDay(s.lastSessionDate);
  const dayDiff = Math.round((todayDate - lastDate) / (1000 * 60 * 60 * 24));

  if (dayDiff <= 0) {
    // Clock changed or stale data — treat as already counted, just update date
    updateState({ lastSessionDate: today });
  } else if (dayDiff === 1) {
    // Consecutive day
    updateState({ streakDays: (s.streakDays || 0) + 1, lastSessionDate: today });
  } else if (dayDiff === 2) {
    // Exactly one day missed. Preserve the streak if:
    //   (a) the missed day was a Sunday (rest day), OR
    //   (b) the one-day grace period (any single missed day is forgiven once)
    updateState({ streakDays: (s.streakDays || 0) + 1, lastSessionDate: today });
  } else {
    // Gap too large — streak broken
    updateState({ streakDays: 1, lastSessionDate: today });
  }
}

// ── Local-date helpers (avoid UTC parsing drift) ──────────────────────────────
function startOfLocalDay(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
function localDayString(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function parseLocalDay(str) {
  const [y, m, d] = str.split('-').map(Number);
  return new Date(y, m - 1, d);
}

/**
 * Returns the streak value safe to display right now, without mutating state.
 * If the last session is too long ago for the streak to still be alive (more
 * than the 1-day grace period), this returns 0 even though the stored
 * streakDays may still hold the old value until the next tickStreak call.
 */
export function getCurrentStreak() {
  const s = getState();
  if (!s.lastSessionDate || !s.streakDays) return 0;
  const today = startOfLocalDay(new Date());
  const last = parseLocalDay(s.lastSessionDate);
  const dayDiff = Math.round((today - last) / (1000 * 60 * 60 * 24));
  // Alive if active today (0), yesterday (1), or one grace day missed (2)
  if (dayDiff <= 2) return s.streakDays;
  return 0;
}

/* ============================================================
   EXPORT / IMPORT
   Lets the user save a JSON backup of their progress and
   restore it on the same or a different device. Critical for
   any case where localStorage is cleared (browser wipe, new
   phone, "reset" tap, paranoid user before a code push).
   ============================================================ */

/**
 * Return the current state as a JSON-serializable object, plus
 * a small metadata envelope identifying it as an Accession backup
 * with a timestamp and the user's display name.
 */
export function exportState() {
  if (!state) loadState();
  return {
    _appName: 'Accession',
    _exportedAt: new Date().toISOString(),
    _displayName: state.displayName || null,
    schemaVersion: state.schemaVersion || CURRENT_SCHEMA_VERSION,
    state: state,
  };
}

/**
 * Trigger a browser download of the current state as a JSON file.
 * Filename uses the displayName + date.
 */
export function downloadBackup() {
  const payload = exportState();
  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const stamp = new Date().toISOString().slice(0, 10);
  const name = (state.displayName || 'accession').replace(/[^a-z0-9-]/gi, '_').toLowerCase();
  a.href = url;
  a.download = `accession-backup-${name}-${stamp}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Restore state from a backup payload (the object returned by
 * exportState). Validates the envelope, runs any pending
 * migrations, and saves. Returns { ok: true } or { ok: false, error }.
 *
 * Does NOT prompt for confirmation — the caller (Profile view)
 * handles the "are you sure?" UX.
 */
export function importState(payload) {
  try {
    if (!payload || typeof payload !== 'object') {
      return { ok: false, error: 'Backup file is empty or not valid JSON.' };
    }
    if (payload._appName !== 'Accession') {
      return { ok: false, error: 'That file is not an Accession backup.' };
    }
    if (!payload.state || typeof payload.state !== 'object') {
      return { ok: false, error: 'Backup file is missing state data.' };
    }
    // Run migrations if the backup is older
    let restored = payload.state;
    const version = restored.schemaVersion || payload.schemaVersion || 1;
    if (version < CURRENT_SCHEMA_VERSION) {
      restored = runMigrations(restored, version);
    }
    // Merge with current defaults to fill in any fields added since
    state = { ...DEFAULT_STATE, ...restored };
    saveState();
    notifyListeners();
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message || 'Unknown error reading backup.' };
  }
}

/* ============================================================
   SPACED REPETITION SYSTEM (SRS)
   Session-based intervals. The session counter increments once
   per app open; review due dates are compared against it.
   Intervals: 1 → 3 → 7 → 21 → 60 sessions.
   ============================================================ */

export const SRS_INTERVALS = [1, 3, 7, 21, 60];

/** Minimum wall-clock time before a reviewed item can reappear (4 hours). */
export const MIN_REVIEW_INTERVAL_MS = 4 * 60 * 60 * 1000;

/**
 * Increment the session counter. Call once on app boot.
 */
export function tickSession() {
  updateState(s => { s.sessionCount = (s.sessionCount || 0) + 1; });
}

/**
 * Schedule an artwork for review after a lesson encounter.
 * Called when the user first encounters an artwork.
 */
export function scheduleReview(artworkId) {
  if (!state) loadState();
  const current = state.sessionCount || 0;
  if (state.reviewQueue[artworkId]) return; // already scheduled
  updateState(s => {
    s.reviewQueue[artworkId] = {
      dueAtSession: current + SRS_INTERVALS[0],
      intervalIndex: 0,
      consecutiveMisses: 0,
      quizTier: 'recognition',
      wallLabelDue: current + SRS_INTERVALS[1],
    };
  });
}

/**
 * Record a correct answer for an artwork in the review queue.
 * Advances the interval and resets consecutive misses.
 */
export function recordReviewCorrect(artworkId) {
  if (!state) loadState();
  const current = state.sessionCount || 0;
  updateState(s => {
    const entry = s.reviewQueue[artworkId];
    if (!entry) return;
    const nextIndex = Math.min(entry.intervalIndex + 1, SRS_INTERVALS.length - 1);
    entry.intervalIndex = nextIndex;
    entry.dueAtSession = current + SRS_INTERVALS[nextIndex];
    entry.consecutiveMisses = 0;
    entry.lastAnsweredAt = new Date().toISOString();
    // Advance wall label on correct answers too, but more slowly
    entry.wallLabelDue = current + SRS_INTERVALS[Math.min(nextIndex + 1, SRS_INTERVALS.length - 1)];
  });
}

/**
 * Record an incorrect answer.
 * First miss: reschedule +1 session, same tier.
 * Second consecutive miss: step back one tier.
 */
export function recordReviewMiss(artworkId) {
  if (!state) loadState();
  const current = state.sessionCount || 0;
  const tiers = ['recognition', 'context', 'synthesis'];
  updateState(s => {
    const entry = s.reviewQueue[artworkId];
    if (!entry) return;
    entry.consecutiveMisses = (entry.consecutiveMisses || 0) + 1;
    entry.lastAnsweredAt = new Date().toISOString();
    // Reschedule for next session — but the time-floor in getDueItems
    // prevents it appearing again within MIN_REVIEW_INTERVAL_MS (4 hours)
    entry.dueAtSession = current + 1;
    if (entry.consecutiveMisses >= 2) {
      // Step back one tier
      const currentTierIdx = tiers.indexOf(entry.quizTier);
      if (currentTierIdx > 0) {
        entry.quizTier = tiers[currentTierIdx - 1];
      }
      entry.consecutiveMisses = 0;
      entry.intervalIndex = Math.max(0, entry.intervalIndex - 1);
    }
  });
}

/**
 * Mark a wall label as reviewed. Advances its due date.
 */
export function recordWallLabelReview(artworkId) {
  if (!state) loadState();
  const current = state.sessionCount || 0;
  updateState(s => {
    const entry = s.reviewQueue[artworkId];
    if (!entry) return;
    const nextIndex = Math.min((entry.intervalIndex || 0) + 1, SRS_INTERVALS.length - 1);
    entry.wallLabelDue = current + SRS_INTERVALS[nextIndex];
  });
}

/**
 * Get all items due for review this session.
 * Returns { quizItems: [artworkId], wallLabelItems: [artworkId] }
 *
 * Time-floor: any item answered within the last MIN_REVIEW_INTERVAL_MS
 * (4 hours) is excluded regardless of session count, preventing a missed
 * artwork from reappearing immediately if the app is opened twice quickly.
 */
export function getDueReviewItems() {
  if (!state) loadState();
  const current = state.sessionCount || 0;
  const now = Date.now();
  const quizItems = [];
  const wallLabelItems = [];
  for (const [artId, entry] of Object.entries(state.reviewQueue || {})) {
    // Time-floor: skip if answered too recently
    if (entry.lastAnsweredAt) {
      const elapsed = now - new Date(entry.lastAnsweredAt).getTime();
      if (elapsed < MIN_REVIEW_INTERVAL_MS) continue;
    }
    if (entry.dueAtSession <= current) quizItems.push(artId);
    if (entry.wallLabelDue <= current) wallLabelItems.push(artId);
  }
  return { quizItems, wallLabelItems };
}

/**
 * Get the review count for the Today view badge.
 */
export function getDueReviewCount() {
  const { quizItems, wallLabelItems } = getDueReviewItems();
  // Deduplicate — an artwork may appear in both
  const all = new Set([...quizItems, ...wallLabelItems]);
  return all.size;
}
