/* ============================================================
   ACCESSION - SYNC LAYER
   Optional Firebase integration for live leaderboard with Brandon.
   The whole app works without it; this is purely additive.

   Setup (one-time, ~10 minutes):
   1. Go to console.firebase.google.com, create a new project.
   2. In "Build" → "Realtime Database", create a database (locked mode is fine
      to start; you'll relax it below).
   3. In Project Settings → General → Your apps, register a web app and
      copy the firebaseConfig object.
   4. Paste it below into FIREBASE_CONFIG.
   5. In Realtime Database → Rules, paste:
        {
          "rules": {
            "users": {
              "$uid": {
                ".read": true,
                ".write": "$uid === auth.uid || auth == null"
              }
            },
            "challenges": {
              ".read": true,
              ".write": true
            }
          }
        }
      (For two trusted users this is fine. Lock down later if you want.)
   6. Reload the app — both you and Brandon's stats will sync live.
   ============================================================ */

import { getState, onStateChange } from './state.js';

// Paste your Firebase config object here. While this is null,
// the app runs in pure-local mode with no networking.
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyCKlX8J8qhLm2MmTaC0k4-vjK63OABI6HU",
  authDomain: "accession-82bc0.firebaseapp.com",
  projectId: "accession-82bc0",
  storageBucket: "accession-82bc0.firebasestorage.app",
  messagingSenderId: "511992645274",
  appId: "1:511992645274:web:7a450204adf341934fc123",
  databaseURL: "https://accession-82bc0-default-rtdb.firebaseio.com",
};
// Example shape:
// const FIREBASE_CONFIG = {
//   apiKey: "...",
//   authDomain: "...",
//   databaseURL: "https://your-project-default-rtdb.firebaseio.com",
//   projectId: "...",
//   appId: "...",
// };

let firebase = null;
let db = null;
let isReady = false;

/**
 * Subscribers waiting for partner data updates.
 */
const partnerListeners = new Set();
let lastPartnerData = null;

/**
 * Initialize Firebase if configured. Idempotent.
 */
export async function initSync() {
  if (!FIREBASE_CONFIG) {
    console.info('Sync: running in offline-only mode (no Firebase config).');
    return false;
  }
  try {
    // Dynamically import Firebase modules from the CDN.
    // This means we ship no Firebase code in the bundle for offline users.
    const { initializeApp } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js');
    const { getDatabase, ref, set, onValue, push } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js');
    firebase = { initializeApp, ref, set, onValue, push };
    const app = initializeApp(FIREBASE_CONFIG);
    db = getDatabase(app);
    isReady = true;
    // Push current state once, then subscribe to changes.
    pushUserStats();
    onStateChange(pushUserStats);
    return true;
  } catch (err) {
    console.warn('Sync: Firebase init failed, running offline:', err);
    return false;
  }
}

/**
 * Push a summarized version of the user's stats to Firebase.
 * We never push raw content edits or personal data — only public scoreboard fields.
 */
function pushUserStats() {
  if (!isReady) return;
  const s = getState();
  if (!s.userId || !s.displayName) return;

  const stats = {
    displayName: s.displayName,
    streakDays: s.streakDays,
    lastSessionDate: s.lastSessionDate,
    encountered: Object.values(s.artworkState).filter(a => a.encountered).length,
    mastered: Object.values(s.artworkState).filter(a => a.masteredCount >= 2).length,
    seenInPerson: Object.values(s.artworkState).filter(a => a.seenInPerson === 'yes').length,
    updatedAt: Date.now(),
  };
  firebase.set(firebase.ref(db, `users/${s.userId}`), stats);
}

/**
 * Subscribe to the partner's stats. Returns an unsubscribe function.
 * If sync isn't ready, the callback fires once with null.
 */
export function subscribeToPartner(partnerUserId, callback) {
  partnerListeners.add(callback);

  if (!isReady || !partnerUserId) {
    callback(lastPartnerData);
    return () => partnerListeners.delete(callback);
  }

  const partnerRef = firebase.ref(db, `users/${partnerUserId}`);
  const unsub = firebase.onValue(partnerRef, snapshot => {
    lastPartnerData = snapshot.val();
    partnerListeners.forEach(fn => {
      try { fn(lastPartnerData); } catch (e) { console.error(e); }
    });
  });

  return () => {
    partnerListeners.delete(callback);
    unsub();
  };
}

/**
 * Send a challenge to the partner. A challenge is a set of pre-baked
 * quiz questions both players take, scores compared.
 */
export async function sendChallenge(challenge) {
  if (!isReady) {
    // Fallback: copy a shareable code to clipboard
    const code = btoa(JSON.stringify(challenge));
    try {
      await navigator.clipboard.writeText(code);
      return { mode: 'code', code };
    } catch {
      return { mode: 'code', code };
    }
  }
  const challengeRef = firebase.push(firebase.ref(db, 'challenges'));
  await firebase.set(challengeRef, {
    ...challenge,
    fromUserId: getState().userId,
    createdAt: Date.now(),
  });
  return { mode: 'live', id: challengeRef.key };
}

export function syncStatus() {
  return {
    configured: !!FIREBASE_CONFIG,
    ready: isReady,
  };
}

/**
 * Post your score for a named challenge round to Firebase.
 * Path: challenges/{roundId}/scores/{userId}
 */
export async function postChallengeScore(roundId, score, total) {
  if (!isReady) return false;
  const s = getState();
  try {
    await firebase.set(
      firebase.ref(db, `challenges/${roundId}/scores/${s.userId}`),
      { score, total, displayName: s.displayName || 'You', finishedAt: Date.now() }
    );
    return true;
  } catch (e) {
    console.error('postChallengeScore', e);
    return false;
  }
}

/**
 * Listen for all scores on a challenge round.
 * Calls callback({ [userId]: { score, total, displayName, finishedAt } })
 * Returns an unsubscribe function.
 */
export function subscribeToChallengeScores(roundId, callback) {
  if (!isReady) { callback({}); return () => {}; }
  const scoresRef = firebase.ref(db, `challenges/${roundId}/scores`);
  const unsub = firebase.onValue(scoresRef, snapshot => {
    callback(snapshot.val() || {});
  });
  return unsub;
}
