/* ============================================================
   ACCESSION - PROGRESSION ENGINE
   The global thesis version.

   The user progresses across two axes (era × region) with depth
   (mastery) as a hidden Z-axis. Key responsibilities:

   1. Compute per-cell mastery (era × region).
   2. Compute per-region mastery (across all eras).
   3. Compute per-era mastery (across all regions).
   4. Detect synchronization gaps — when one region races ahead.
   5. Determine the difficulty tier a user faces for a given artwork
      (Recognition / Context / Synthesis) based on their breadth.
   ============================================================ */

import { getState } from './state.js';
import {
  getArtworksForCell, getArtworksForRegion, getArtworksForEra,
  getAllArtworks, getEras, getRegions,
} from './content.js';

// Curator rank names per region
export const RANK_NAMES = [
  'Visitor',
  'Member',
  'Apprentice Curator',
  'Curator',
  'Curator Emeritus',
];

// Difficulty tiers (the Z-axis)
export const DIFFICULTY_TIERS = {
  RECOGNITION: 'recognition',
  CONTEXT:     'context',
  SYNTHESIS:   'synthesis',
};

/**
 * Has the user "encountered" an artwork? (Seen it in any lesson.)
 */
function isEncountered(artworkId) {
  const s = getState().artworkState[artworkId];
  return !!(s && s.encountered);
}

/**
 * Per-artwork mastery count (number of correct quiz answers).
 */
function masteryCount(artworkId) {
  const s = getState().artworkState[artworkId];
  return s ? s.masteredCount : 0;
}

/**
 * Per-artwork mastery level (0-3).
 */
export function getArtworkMastery(artworkId) {
  const count = masteryCount(artworkId);
  if (count >= 4) return 3;
  if (count >= 2) return 2;
  if (count >= 1) return 1;
  if (isEncountered(artworkId)) return 1;
  return 0;
}

/* ===== CELL MASTERY (era × region) ===== */

export function getCellMastery(eraId, regionId) {
  const arts = getArtworksForCell(eraId, regionId);
  if (arts.length === 0) return null;
  const totalMastery = arts.reduce((sum, a) => sum + getArtworkMastery(a.id), 0);
  return totalMastery / (arts.length * 3);
}

export function getNewArtworksInCell(eraId, regionId) {
  const state = getState();
  const lastCompletedAt = (state.cellCompletions || {})[`${eraId}:${regionId}`];
  if (!lastCompletedAt) return [];
  return getArtworksForCell(eraId, regionId).filter(a => {
    const seen = state.artworkState[a.id];
    return !seen || !seen.encountered;
  });
}

/* ===== REGION MASTERY (Y-axis) ===== */

export function getRegionMastery(regionId) {
  const eras = getEras();
  let cells = 0;
  let totalFraction = 0;
  for (const era of eras) {
    const cm = getCellMastery(era.id, regionId);
    if (cm !== null) {
      cells += 1;
      totalFraction += cm;
    }
  }
  return cells === 0 ? 0 : totalFraction / cells;
}

export function getCuratorRank(regionId) {
  const m = getRegionMastery(regionId);
  if (m >= 1.0) return 4;
  if (m >= 0.7) return 3;
  if (m >= 0.4) return 2;
  if (m >= 0.2) return 1;
  return 0;
}

export function getFurthestEraInRegion(regionId) {
  const eras = getEras();
  let furthest = null;
  for (const era of eras) {
    const arts = getArtworksForCell(era.id, regionId);
    if (arts.length === 0) continue;
    const anyEncountered = arts.some(a => isEncountered(a.id));
    if (anyEncountered) furthest = era;
  }
  return furthest;
}

/* ===== ERA MASTERY (X-axis) ===== */

export function getEraMastery(eraId) {
  const regions = getRegions();
  let cells = 0;
  let totalFraction = 0;
  for (const region of regions) {
    const cm = getCellMastery(eraId, region.id);
    if (cm !== null) {
      cells += 1;
      totalFraction += cm;
    }
  }
  return cells === 0 ? 0 : totalFraction / cells;
}

/* ===== GLOBAL SYNCHRONIZATION RULE (soft nudge) ===== */

export function getSynchronizationGap() {
  const regions = getRegions();
  const furthestPerRegion = {};
  for (const region of regions) {
    const furthest = getFurthestEraInRegion(region.id);
    furthestPerRegion[region.id] = furthest ? furthest.order : 0;
  }
  const sorted = Object.entries(furthestPerRegion)
    .map(([id, order]) => ({ id, order }))
    .filter(r => r.order > 0)
    .sort((a, b) => b.order - a.order);

  if (sorted.length < 2) return null;
  const leader = sorted[0];
  const second = sorted[1];
  if (leader.order < 2) return null;
  const gap = leader.order - second.order;
  if (gap < 3) return null;
  return {
    aheadRegion: leader.id,
    behindRegions: sorted.slice(1).map(s => s.id),
    gap,
  };
}

export function shouldFireNudge() {
  const gap = getSynchronizationGap();
  if (!gap) return null;
  const state = getState();
  const lastFiredGap = state.lastSyncNudgeGap || 0;
  if (gap.gap > lastFiredGap) return gap;
  return null;
}

/* ===== Z-AXIS: DIFFICULTY TIER SELECTION ===== */

export function pickDifficultyTier(artworkId) {
  const art = getAllArtworks().find(a => a.id === artworkId);
  if (!art) return DIFFICULTY_TIERS.RECOGNITION;

  const ownMastery = getArtworkMastery(artworkId);
  if (ownMastery >= 2) {
    const regionM = getRegionMastery(art.regionId);
    if (regionM >= 0.4) return DIFFICULTY_TIERS.SYNTHESIS;
    return DIFFICULTY_TIERS.CONTEXT;
  }
  const cellMastery = getCellMastery(art.eraId, art.regionId);
  if (cellMastery && cellMastery >= 0.5) return DIFFICULTY_TIERS.CONTEXT;
  return DIFFICULTY_TIERS.RECOGNITION;
}

/* ===== COLLECTION VIEW HELPERS ===== */

export function getNodeState(artworkId) {
  const s = getState().artworkState[artworkId];
  if (!s || !s.encountered) return 'unencountered';
  if (s.seenInPerson === 'yes') return 'gold';   // always gold if seen in person
  if (s.masteredCount >= 2) return 'lit';
  return 'faint';
}

export function getCollectionStats() {
  const state = getState();
  const entries = Object.values(state.artworkState);
  return {
    encountered: entries.filter(e => e.encountered).length,
    mastered: entries.filter(e => e.masteredCount >= 2).length,
    seenInPerson: entries.filter(e => e.seenInPerson === 'yes').length,
  };
}

/**
 * Composite completion percentage combining:
 *   50% — artworks with masteredCount >= 1 or seenInPerson
 *   35% — lessons completed out of full sequence
 *   15% — Final Exhibitions passed out of total eras
 *
 * Returns { pct, artworkPct, lessonPct, exhibitionPct,
 *           artworkDone, artworkTotal,
 *           lessonDone, lessonTotal,
 *           exhibitionDone, exhibitionTotal }
 */
export function getCompletionStats() {
  const state = getState();
  const allArts = getAllArtworks();

  // ── Artwork pillar ────────────────────────────────────────────────────────
  const artworkTotal = allArts.length;
  const artworkDone = allArts.filter(a => {
    const s = state.artworkState[a.id];
    return s && ((s.masteredCount >= 1) || (s.seenInPerson === 'yes'));
  }).length;
  const artworkPct = artworkTotal > 0 ? artworkDone / artworkTotal : 0;

  // ── Lesson pillar ─────────────────────────────────────────────────────────
  const sequence = getFullSequence();
  const lessonTotal = sequence.length;
  const completedSet = new Set(
    Object.entries(state.movementProgress || {})
      .flatMap(([, v]) => v.lessonsCompleted || [])
  );
  // also check cellCompletions keys as a proxy for completed lessons
  const lessonDone = sequence.filter(lid => completedSet.has(lid)).length;
  const lessonPct = lessonTotal > 0 ? lessonDone / lessonTotal : 0;

  // ── Exhibition pillar ─────────────────────────────────────────────────────
  let exhibitionState = {};
  try {
    exhibitionState = JSON.parse(
      (typeof localStorage !== 'undefined'
        ? localStorage.getItem('accession:finalExhibitions')
        : null) || '{}'
    );
  } catch (e) {}
  const eras = getEras();
  const exhibitionTotal = eras.length;
  const exhibitionDone = eras.filter(e => exhibitionState[e.id]?.passed).length;
  const exhibitionPct = exhibitionTotal > 0 ? exhibitionDone / exhibitionTotal : 0;

  // ── Composite ─────────────────────────────────────────────────────────────
  const pct = Math.round((artworkPct * 0.50 + lessonPct * 0.35 + exhibitionPct * 0.15) * 100);

  return {
    pct,
    artworkPct: Math.round(artworkPct * 100),
    lessonPct: Math.round(lessonPct * 100),
    exhibitionPct: Math.round(exhibitionPct * 100),
    artworkDone, artworkTotal,
    lessonDone, lessonTotal,
    exhibitionDone, exhibitionTotal,
  };
}

/* ===== LESSON SEQUENCE ===== */

// Module-level sequence so both getFullSequence and getNextLesson share it
const LESSON_SEQUENCE = [
    'prehistoric-africa-01',
    'prehistoric-africa-apollo',
    'prehistoric-americas-01',
    'prehistoric-americas-capivara',
    'prehistoric-cave-art-01',
    'prehistoric-cave-art-altamira',
    'prehistoric-east-asia-01',
    'prehistoric-east-asia-jade',
    'prehistoric-europe-monuments',
    'prehistoric-europe-venus-laussel',
    'prehistoric-global-art',
    'prehistoric-global-venus',
    'prehistoric-mena-01',
    'prehistoric-mena-gobekli',
    'prehistoric-oceania-01',
    'prehistoric-oceania-kimberley',
    'prehistoric-portable-art',
    'prehistoric-south-asia-01',
    'prehistoric-south-asia-edakkal',
    'prehistoric-sulawesi-01',
    'prehistoric-why-animals',
    'african-ancient-01',
    'americas-ancient-01',
    'ancient-europe-materials-comparison',
    'ancient-materials-01',
    'ancient-worlds-death-afterlife',
    'ancient-worlds-first-writing',
    'ancient-worlds-sampler',
    'bronze-age-europe-01',
    'chinese-ancient-01',
    'egypt-amarna-01',
    'egyptian-ancient-01',
    'etruscan-ancient-01',
    'greek-ancient-01',
    'greek-arc-ancient-01',
    'greek-body-politics-01',
    'greek-symposium-01',
    'han-china-tomb-01',
    'hellenism-global-01',
    'indian-ancient-01',
    'jomon-ancient-01',
    'jomon-to-yayoi-comparison',
    'mesopotamian-ancient-01',
    'mesopotamian-ancient-02',
    'mesopotamian-royal-power-comparison',
    'minoan-ancient-01',
    'oceania-ancient-01',
    'olmec-teotihuacan-01',
    'roman-copies-01',
    'roman-imperial-portrait-01',
    'roman-painting-mosaic-01',
    'sanchi-buddhist-01',
    'southeast-asia-ancient-01',
    'africa-across-eras-comparison',
    'african-sacred-medieval-01',
    'americas-across-eras-comparison',
    'borobudur-angkor-comparison',
    'byzantine-mosaic-01',
    'byzantine-sacred-medieval-01',
    'ceramic-traditions-01',
    'china-across-eras-comparison',
    'chinese-sacred-medieval-01',
    'chola-india-01',
    'death-medieval-01',
    'ethiopia-africa-medieval-01',
    'gothic-before-renaissance-01',
    'gothic-stained-glass-01',
    'greek-to-byzantine-comparison',
    'greek-to-christian-01',
    'hagia-sophia-byzantine-01',
    'heian-japan-01',
    'india-across-eras-comparison',
    'indian-sacred-medieval-01',
    'islamic-calligraphy-01',
    'islamic-geometric-pattern-01',
    'islamic-sacred-medieval-01',
    'korea-east-asia-medieval-01',
    'lost-wax-bronze-01',
    'manuscript-tradition-01',
    'maya-sacred-medieval-01',
    'maya-writing-01',
    'oceania-sacred-medieval-01',
    'pala-south-asia-01',
    'persian-manuscript-01',
    'romanesque-gothic-01',
    'sacred-medieval-sacred-image',
    'sacred-medieval-sampler',
    'sasanian-abbasid-01',
    'southeast-asia-khmer-01',
    'southeast-asia-sacred-medieval-01',
    'tang-dynasty-01',
    'aztec-renaissances-01',
    'benin-bronzes-renaissances-01',
    'bruegel-landscape-01',
    'burmese-buddha-01',
    'caravaggio-baroque-01',
    'dutch-golden-age-01',
    'el-greco-michelangelo-01',
    'fresco-tempera-oil-01',
    'hawaiian-renaissances-01',
    'high-renaissance-01',
    'ife-benin-africa-01',
    'italian-renaissance-01',
    'joseon-east-asia-01',
    'kongo-africa-renaissances-01',
    'ming-dynasty-renaissances-01',
    'mughal-akbar-01',
    'mughal-renaissances-01',
    'northern-renaissance-01',
    'oil-revolution-01',
    'ottoman-renaissances-01',
    'rembrandt-vermeer-01',
    'visual-mastery-sampler',
    'safavid-renaissances-01',
    'spanish-encounter-americas-01',
    'velazquez-spanish-golden-age-01',
    'venetian-renaissance-01',
    'hokusai-japanese-prints-01',
    'impressionism-01',
    'impressionism-02',
    'impressionism-paris-01',
    'manet-01',
    'hudson-river-school-01',
    'revolution-africa-01',
    'raja-ravi-varma-01',
    'ottoman-revi-01',
    'monet-degas-01',
    'seurat-signac-01',
    'aboriginal-contemporary-01',
    'american-modernism-01',
    'japanese-postwar-01',
    'global-modernism-01',
    'indian-modernism-01',
    'american-modernism-aic-01',
    'modernism-americas-02',
    'modernism-europe-01',
];

/** Returns the full ordered lesson sequence. */
export function getFullSequence() {
  return LESSON_SEQUENCE;
}

/* ===== "WHAT NEXT" RECOMMENDER ===== */

/**
 * Returns the next lesson the user should take, or null if all are done.
 */
export function getNextLesson() {
  const state = getState();
  const completed = new Set();
  for (const movId in state.movementProgress) {
    for (const lid of (state.movementProgress[movId].lessonsCompleted || [])) {
      completed.add(lid);
    }
  }

  for (const lid of LESSON_SEQUENCE) {
    if (!completed.has(lid)) return { lessonId: lid };
  }
  return null;
}
