/* ============================================================
   ACCESSION - CONTENT LOADER
   Loads bundled JSON data from /data folder.
   Caches in memory once loaded. Applies author edits on top.
   ============================================================ */

import { getState } from './state.js';

// In-memory cache. Populated on first load.
const cache = {
  paths: {},
  eras: {},
  regions: {},
  subregions: {},
  movements: {},
  artists: {},
  artworks: {},
  museums: {},
  lessons: {},
};

let isLoaded = false;
let loadPromise = null;

/**
 * Manifests of every content file we ship. Hard-coded here so that
 * we don't need a server-side directory listing.
 * Add new files to these arrays when you create them.
 */
const MANIFEST = {
  paths: ['met-chronological'],
  eras: [
    'ancient-worlds', 'modernism', 'prehistoric', 'renaissances-empires',
    'revolution-industry', 'sacred-medieval',
  ],
  regions: [
    'americas', 'east-asia', 'europe', 'middle-east-north-africa', 
    'oceania', 'south-asia', 'southeast-asia', 'sub-saharan-africa'
  ],
  subregions: [
    'aboriginal-australian', 'africa-prehistoric', 'amazonian', 'americas-prehistoric',
    'andean', 'argentinian', 'austrian', 'aztec',
    'benin', 'brazilian', 'bronze-age-europe', 'burmese',
    'canadian', 'caribbean', 'chinese', 'colonial-mexico',
    'contemporary-african', 'dong-son', 'dutch', 'dutch-golden-age',
    'east-asia-prehistoric', 'eastern-european', 'egyptian', 'english',
    'ethiopian', 'etruscan', 'europe-prehistoric', 'flemish',
    'fon-dahomey', 'french', 'french-impressionism', 'german',
    'greek-byzantine', 'han-china', 'hawaiian', 'heian-japan',
    'hispano-indigenous', 'hudson-river-school', 'ife', 'indian',
    'indian-colonial', 'indian-modernism', 'islamic', 'italian',
    'japanese', 'japanese-postwar', 'javanese', 'joseon-korea',
    'khartoum-school', 'khmer', 'konbaung-burma', 'kongo',
    'korean', 'lapita', 'maghreb', 'maori',
    'maurya-shunga', 'maya', 'melanesian', 'mena-prehistoric',
    'mesopotamian', 'mexican', 'ming-china', 'minoan',
    'mixtec', 'nepalese', 'new-kingdom-egypt', 'nok',
    'north-american-indigenous', 'northern-european', 'oceania-prehistoric', 'olmec',
    'ottoman', 'ottoman-tanzimat', 'pala-dynasty', 'persian',
    'polynesian', 'roman', 'roman-imperial', 'russian',
    'safavid-persia', 'saharan-prehistoric', 'south-asia-prehistoric', 'spanish',
    'spanish-golden-age', 'sri-lankan', 'sukhothai', 'tang-china',
    'thai', 'tibetan', 'us-american', 'venetian-renaissance',
    'vietnamese', 'vietnamese-southeast', 'west-african-contemporary', 'yoruba',
    'zapotec',
  ],
  movements: [
    'american-modernism', 'dutch-golden-age', 'egyptian-ancient', 'impressionism', 
    'italian-renaissance', 'northern-renaissance'
  ],
  museums: [
    'art-institute-chicago', 'british-museum', 'louvre', 'met',
    'pergamon-museum', 'vatican-museums',
  ],
  artists: [
    'bellini', 'botticelli', 'bruegel-elder', 'caillebotte',
    'cimabue', 'clifford-possum-tjapaltjarri', 'degas', 'duccio',
    'grant-wood', 'hokusai', 'hopper', 'matisse',
    'monet', 'okeeffe', 'petrus-christus', 'picasso',
    'rembrandt', 'rivera', 'seurat', 'van-gogh',
    'vermeer', 'wu-zhen',
  ],
  artworks: [
    'aic-american-gothic', 'aic-bathers-by-river', 'aic-grande-jatte', 'aic-nighthawks',
    'aic-old-guitarist', 'aic-paris-street-rainy-day', 'aic-rivera-weaving', 'aic-van-gogh-bedroom',
    'akhenaten-bust', 'alhambra-court-lions', 'altamira-polychrome-ceiling', 'amrita-sher-gil-three-girls',
    'angkor-wat-devata', 'apollo-11-cave-stones', 'ardabil-carpet', 'ashoka-lion-capital',
    'augustus-prima-porta', 'aztec-coatlicue', 'aztec-sun-stone', 'bhimbetka-rock-paintings',
    'blombos-engraved-ochre', 'borobudur-stupa-buddha', 'british-ashurbanipal-hunt', 'british-ram-thicket',
    'bruegel-hunters-snow', 'burmese-konbaung-buddha', 'caravaggio-calling-matthew', 'chauvet-panel-horses',
    'china-jade-bi-disc', 'china-si-mu-wu-fang-ding', 'codex-zouche-nuttall', 'cole-oxbow',
    'cueva-de-las-manos', 'degas-little-dancer', 'dolni-vestonice-venus', 'dome-of-the-rock',
    'dong-son-bronze-drum', 'edakkal-cave-petroglyphs', 'el-anatsui-earth-map', 'el-castillo-hand-stencils',
    'el-greco-view-toledo', 'etruscan-bronze-statuette', 'fon-dahomey-royal-tapestry', 'gandhara-bodhisattva-maitreya',
    'genji-tale-screen', 'gobekli-tepe-pillar', 'hagia-sophia-deesis', 'hagia-sophia-exterior',
    'hawaiian-feather-cloak', 'hiroshima-torii-gate-1945', 'ibrahim-el-salahi-reborn-sounds', 'ife-brass-head-british-museum',
    'ife-seated-figure', 'india-nataraja', 'indus-dancing-girl', 'jomon-flame-vessel',
    'jomon-goggle-dogu', 'jomon-venus', 'joseon-moon-jar', 'kimberley-bradshaw-figures',
    'kongo-nkangi-kiditu', 'ladies-preparing-silk', 'lascaux-hall-bulls', 'laussel-venus',
    'lienzo-tlaxcala', 'lion-man-hohlenstein', 'louvre-hammurabi-code', 'louvre-naram-sin-stele',
    'manet-bar-folies-bergere', 'manet-olympia', 'maori-pataka-panel', 'mawangdui-silk-banner',
    'maya-jade-death-mask', 'met-aboriginal-dot-painting', 'met-achaemenid-rhyton', 'met-angkor-vishnu',
    'met-assyrian-lamassu', 'met-bellini-madonna', 'met-benin-plaque', 'met-bharhut-railing',
    'met-borobudur-photo', 'met-botticelli-jerome', 'met-bruegel-harvesters', 'met-byzantine-icon',
    'met-byzantine-ivory', 'met-christus-carthusian', 'met-cylinder-seal', 'met-degas-rehearsal',
    'met-duccio-madonna', 'met-ethiopian-cross', 'met-fayum-portrait', 'met-gothic-stained-glass',
    'met-greek-grave-stele', 'met-gudea-statue', 'met-han-tomb-figures', 'met-hatshepsut-kneeling',
    'met-heian-buddha', 'met-hellenistic-head', 'met-hokusai-great-wave', 'met-hopper-tables',
    'met-ife-head', 'met-illuminated-manuscript', 'met-indus-seal', 'met-islamic-ceramic',
    'met-iznik-tile', 'met-jade-burial-suit', 'met-korean-celadon', 'met-kouros',
    'met-lapita-pottery', 'met-mamluk-mosque-lamp', 'met-maya-stela', 'met-maya-vessel',
    'met-monet-bridge', 'met-mughal-emperor', 'met-nok-head', 'met-okeeffe-cow-skull',
    'met-olmec-head', 'met-olmec-mask', 'met-parvati', 'met-persian-battle-folio',
    'met-quran-folio', 'met-red-figure-kylix', 'met-rembrandt-self-portrait', 'met-roman-portrait',
    'met-romanesque-virgin', 'met-sasanian-plate', 'met-shang-bronze-vessel', 'met-song-landscape',
    'met-standard-of-ur', 'met-tang-horse', 'met-temple-dendur', 'met-teotihuacan-mask',
    'met-vermeer-water-pitcher', 'met-wu-zhen-bamboo', 'michelangelo-pieta', 'ming-blue-white-vase',
    'ming-court-ladies-garden', 'minoan-bull-leaping-fresco', 'minoan-snake-goddess', 'monet-water-lilies-pond',
    'mughal-akbarnama-battle', 'murujuga-petroglyphs', 'nebra-sky-disc', 'nefertiti-bust',
    'nok-male-head-brooklyn', 'olmec-san-lorenzo-head', 'osman-hamdi-bey-tortoise-trainer', 'ottoman-suleiman-miniature',
    'pakal-sarcophagus-lid', 'pala-manuscript-prajnaparamita', 'pergamon-abbasid-lusterware', 'pompeii-villa-mysteries-fresco',
    'raja-ravi-varma-galaxy-musicians', 'raphael-school-of-athens', 'ravenna-justinian-mosaic', 'rembrandt-night-watch',
    'roman-alexander-mosaic', 'sanchi-stupa-gateway', 'serra-da-capivara-paintings', 'seurat-bathers-asnieres',
    'shang-oracle-bone', 'signac-felix-feneon', 'stonehenge', 'sukhothai-walking-buddha',
    'sulawesi-leang-karampuang', 'tassili-najjer-cattle', 'teotihuacan-feathered-serpent-head', 'titian-venus-urbino',
    'uffizi-cimabue-crucifix', 'van-eyck-arnolfini', 'velazquez-las-meninas', 'venus-of-willendorf',
    'vermeer-girl-pearl-earring', 'xinglongwa-jade-pendant', 'yayoi-dotaku-bell', 'yuchanyan-pottery',
  ],
  lessons: [
    'aboriginal-contemporary-01', 'africa-across-eras-comparison', 'african-ancient-01', 'african-sacred-medieval-01',
    'american-modernism-01', 'american-modernism-aic-01', 'americas-across-eras-comparison', 'americas-ancient-01',
    'ancient-europe-materials-comparison', 'ancient-materials-01', 'ancient-worlds-death-afterlife', 'ancient-worlds-first-writing',
    'ancient-worlds-sampler', 'aztec-renaissances-01', 'benin-bronzes-renaissances-01', 'borobudur-angkor-comparison',
    'bronze-age-europe-01', 'bruegel-landscape-01', 'burmese-buddha-01', 'byzantine-mosaic-01',
    'byzantine-sacred-medieval-01', 'caravaggio-baroque-01', 'ceramic-traditions-01', 'china-across-eras-comparison',
    'chinese-ancient-01', 'chinese-sacred-medieval-01', 'chola-india-01', 'death-medieval-01',
    'dutch-golden-age-01', 'egypt-amarna-01', 'egyptian-ancient-01', 'el-greco-michelangelo-01',
    'ethiopia-africa-medieval-01', 'etruscan-ancient-01', 'fresco-tempera-oil-01', 'global-modernism-01',
    'gothic-before-renaissance-01', 'gothic-stained-glass-01', 'greek-ancient-01', 'greek-arc-ancient-01',
    'greek-body-politics-01', 'greek-symposium-01', 'greek-to-byzantine-comparison', 'greek-to-christian-01',
    'hagia-sophia-byzantine-01', 'han-china-tomb-01', 'hawaiian-renaissances-01', 'heian-japan-01',
    'hellenism-global-01', 'high-renaissance-01', 'hokusai-japanese-prints-01', 'hudson-river-school-01',
    'ife-benin-africa-01', 'impressionism-01', 'impressionism-02', 'impressionism-paris-01',
    'india-across-eras-comparison', 'indian-ancient-01', 'indian-modernism-01', 'indian-sacred-medieval-01',
    'islamic-calligraphy-01', 'islamic-geometric-pattern-01', 'islamic-sacred-medieval-01', 'italian-renaissance-01',
    'japanese-postwar-01', 'jomon-ancient-01', 'jomon-to-yayoi-comparison', 'joseon-east-asia-01',
    'kongo-africa-renaissances-01', 'korea-east-asia-medieval-01', 'lost-wax-bronze-01', 'manet-01',
    'manuscript-tradition-01', 'maya-sacred-medieval-01', 'maya-writing-01', 'mesopotamian-ancient-01',
    'mesopotamian-ancient-02', 'mesopotamian-royal-power-comparison', 'ming-dynasty-renaissances-01', 'minoan-ancient-01',
    'modernism-americas-02', 'modernism-europe-01', 'monet-degas-01', 'mughal-akbar-01',
    'mughal-renaissances-01', 'northern-renaissance-01', 'oceania-ancient-01', 'oceania-sacred-medieval-01',
    'oil-revolution-01', 'olmec-teotihuacan-01', 'ottoman-renaissances-01', 'ottoman-revi-01',
    'pala-south-asia-01', 'persian-manuscript-01', 'prehistoric-africa-01', 'prehistoric-africa-apollo',
    'prehistoric-americas-01', 'prehistoric-americas-capivara', 'prehistoric-cave-art-01', 'prehistoric-cave-art-altamira',
    'prehistoric-east-asia-01', 'prehistoric-east-asia-jade', 'prehistoric-europe-monuments', 'prehistoric-europe-venus-laussel',
    'prehistoric-global-art', 'prehistoric-global-venus', 'prehistoric-mena-01', 'prehistoric-mena-gobekli',
    'prehistoric-oceania-01', 'prehistoric-oceania-kimberley', 'prehistoric-portable-art', 'prehistoric-south-asia-01',
    'prehistoric-south-asia-edakkal', 'prehistoric-sulawesi-01', 'prehistoric-why-animals', 'raja-ravi-varma-01',
    'rembrandt-vermeer-01', 'revolution-africa-01', 'roman-copies-01', 'roman-imperial-portrait-01',
    'roman-painting-mosaic-01', 'romanesque-gothic-01', 'sacred-medieval-sacred-image', 'sacred-medieval-sampler',
    'safavid-renaissances-01', 'sanchi-buddhist-01', 'sasanian-abbasid-01', 'seurat-signac-01',
    'southeast-asia-ancient-01', 'southeast-asia-khmer-01', 'southeast-asia-sacred-medieval-01', 'spanish-encounter-americas-01',
    'tang-dynasty-01', 'velazquez-spanish-golden-age-01', 'venetian-renaissance-01', 'visual-mastery-sampler',
  ],
};

/**
 * Load all content from /data. Returns a promise that resolves when done.
 * Safe to call multiple times — only loads once.
 */
export function loadContent() {
  if (isLoaded) return Promise.resolve();
  if (loadPromise) return loadPromise;

  loadPromise = (async () => {
    const types = Object.keys(MANIFEST);
    await Promise.all(types.map(loadType));
    isLoaded = true;
  })();
  return loadPromise;
}

async function loadType(type) {
  const ids = MANIFEST[type];
  ids.forEach(id => {
    const json = (window.__BUNDLED_DATA && window.__BUNDLED_DATA[type])
      ? window.__BUNDLED_DATA[type][id]
      : null;
    if (json) cache[type][id] = json;
  });
}

/* ===== Lookup helpers ===== */

export function getPath(id) {
  return applyEdits(cache.paths[id], id);
}

export function getEra(id) {
  return applyEdits(cache.eras[id], id);
}

export function getEras() {
  // Return in order so the X-axis renders chronologically
  return Object.values(cache.eras).sort((a, b) => a.order - b.order);
}

export function getRegion(id) {
  return applyEdits(cache.regions[id], id);
}

export function getRegions() {
  return Object.values(cache.regions).sort((a, b) => a.order - b.order);
}

export function getSubRegion(id) {
  return applyEdits(cache.subregions[id], id);
}

export function getSubRegions() {
  return Object.values(cache.subregions);
}

export function getSubRegionsForRegion(regionId) {
  return Object.values(cache.subregions).filter(sr => sr.parentRegionId === regionId);
}

export function getMovement(id) {
  return applyEdits(cache.movements[id], id);
}

export function getMovements() {
  return Object.values(cache.movements);
}

export function getArtist(id) {
  return applyEdits(cache.artists[id], id);
}

export function getArtwork(id) {
  return applyEdits(cache.artworks[id], id);
}

export function getMuseum(id) {
  return applyEdits(cache.museums[id], id);
}

export function getLesson(id) {
  return applyEdits(cache.lessons[id], id);
}

export function getLessonsForMovement(movementId) {
  return Object.values(cache.lessons).filter(l => l.movementId === movementId);
}

export function getArtworksForMovement(movementId) {
  return Object.values(cache.artworks).filter(a => a.movementId === movementId);
}

/**
 * Artworks tagged to an era. Used by the global timeline grid.
 */
export function getArtworksForEra(eraId) {
  return Object.values(cache.artworks).filter(a => a.eraId === eraId);
}

/**
 * Artworks tagged to a region (top-level). Used for region drill-downs.
 */
export function getArtworksForRegion(regionId) {
  return Object.values(cache.artworks).filter(a => a.regionId === regionId);
}

/**
 * Artworks at a specific era/region cell on the grid.
 */
export function getArtworksForCell(eraId, regionId) {
  return Object.values(cache.artworks).filter(
    a => a.eraId === eraId && a.regionId === regionId
  );
}

/**
 * Artworks tagged to a sub-region.
 */
export function getArtworksForSubRegion(subRegionId) {
  return Object.values(cache.artworks).filter(a => a.subRegionId === subRegionId);
}

export function getAllArtworks() {
  return Object.values(cache.artworks);
}

export function getAllLessons() {
  return Object.values(cache.lessons);
}

/**
 * Apply any author-mode edits from state on top of the base content.
 * This lets the user override wall labels, etc., without changing files.
 */
function applyEdits(content, id) {
  if (!content) return content;
  const edits = getState().authorEdits[id];
  if (!edits) return content;
  return { ...content, ...edits };
}

/**
 * Save an author edit to a piece of content.
 * Used by author mode.
 */
export function saveAuthorEdit(id, patch) {
  // Imported lazily to avoid circular dep
  import('./state.js').then(({ updateState }) => {
    updateState(s => {
      s.authorEdits[id] = { ...(s.authorEdits[id] || {}), ...patch };
    });
  });
}
