/* ============================================================
   ACCESSION - DAILY CHALLENGE CORE
   Deterministic 5-question challenge picked from existing visual
   mastery cards. Same questions globally per day (Wordle parity).

   The "day number" is days since the epoch start (2026-01-01),
   so day #1 = Jan 1 2026. Both your device and Brandon's device
   pick the same 5 questions from the same seed on the same date.
   ============================================================ */

import { getAllLessons } from './content.js';
import { getState, updateState } from './state.js';

// Anchor date — day #1 of Accession Daily. Local-time YYYY-MM-DD.
// Today (June 14, 2026) is day #1; tomorrow is #2, and so on.
const EPOCH = new Date(2026, 5, 14); // June 14, 2026 local (month is 0-indexed)
const DAILY_QUESTIONS = 5;

// ── Day-number math ─────────────────────────────────────────────────────────
function startOfLocalDay(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
function localDayString(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** Day number for today (local time). Day 1 = 2026-01-01. */
export function getTodayNumber() {
  const today = startOfLocalDay(new Date());
  const epoch = startOfLocalDay(EPOCH);
  return Math.floor((today - epoch) / (1000 * 60 * 60 * 24)) + 1;
}

/** Local-time ISO date string for today, YYYY-MM-DD. */
export function getTodayDateString() {
  return localDayString(new Date());
}

// ── Deterministic seeded shuffle ────────────────────────────────────────────
/**
 * Mulberry32 PRNG — deterministic 32-bit hash → pseudo-random sequence.
 * Same seed → same sequence on any device. Perfect for daily parity.
 */
function mulberry32(seed) {
  return function() {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = seed;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function seededShuffle(arr, seed) {
  const rng = mulberry32(seed);
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

// ── Question pool & daily selection ─────────────────────────────────────────

const VISUAL_TYPES = ['quiz-detail', 'quiz-timeline', 'quiz-technique', 'quiz-compare'];

/** Collect every visual-mastery card from every lesson with its source. */
function buildQuestionPool() {
  const pool = [];
  for (const lesson of getAllLessons()) {
    for (const card of (lesson.cards || [])) {
      if (VISUAL_TYPES.includes(card.type)) {
        pool.push({
          ...card,
          // Tag with source lesson so we can show context if needed
          _sourceLessonId: lesson.id,
          _sourceEra: lesson.eraId,
        });
      }
    }
  }
  return pool;
}

/**
 * Returns today's 5 daily challenge questions.
 * Deterministic: same date → same questions on every device.
 * Tries to vary the mix across the four visual mastery types.
 */
export function getDailyQuestions() {
  const dayNum = getTodayNumber();
  const pool = buildQuestionPool();
  if (pool.length === 0) return [];

  // Group by type so we can guarantee variety
  const byType = {};
  for (const type of VISUAL_TYPES) byType[type] = [];
  for (const q of pool) byType[q.type].push(q);

  // Deterministically shuffle each type bucket by seed (so same day → same picks)
  for (const type of VISUAL_TYPES) {
    byType[type] = seededShuffle(byType[type], dayNum * 31 + type.length);
  }

  // Round-robin take from each bucket until we have 5
  const picks = [];
  let i = 0;
  while (picks.length < DAILY_QUESTIONS && i < 20) {
    for (const type of VISUAL_TYPES) {
      if (picks.length >= DAILY_QUESTIONS) break;
      if (byType[type][i]) picks.push(byType[type][i]);
    }
    i++;
  }

  // Final deterministic shuffle so the type order isn't predictable
  return seededShuffle(picks, dayNum * 7919).slice(0, DAILY_QUESTIONS);
}

// ── Daily state (separate from regular streak) ──────────────────────────────

const DAILY_STORAGE_KEY = 'accession:daily';

/**
 * Daily state schema:
 *   {
 *     lastCompletedDay: 142,              // day number, not date
 *     lastCompletedDate: '2026-05-22',    // ISO local-day string
 *     streak: 7,                          // consecutive days
 *     totalCompleted: 18,
 *     perfectDates: ['2026-05-19', ...],  // dates with 5/5 (for badge)
 *     history: {
 *       '142': { score: 4, total: 5, pattern: [1,1,0,1,1] },
 *       ...
 *     }
 *   }
 */
export function getDailyState() {
  try {
    return JSON.parse(localStorage.getItem(DAILY_STORAGE_KEY) || '{}');
  } catch (e) {
    return {};
  }
}

function saveDailyState(state) {
  localStorage.setItem(DAILY_STORAGE_KEY, JSON.stringify(state));
}

/** Has the user completed today's daily? */
export function hasCompletedToday() {
  const state = getDailyState();
  return state.lastCompletedDay === getTodayNumber();
}

/** Get today's result if completed, else null. */
export function getTodaysResult() {
  const state = getDailyState();
  const today = getTodayNumber();
  if (state.lastCompletedDay !== today) return null;
  return state.history?.[String(today)] || null;
}

/**
 * Record completion of today's daily.
 * pattern = array of 1/0 for correct/incorrect per question.
 *
 * Streak rules: increment on consecutive days. One missed day breaks
 * the streak (no grace period — the point of a daily streak is daily).
 */
export function recordDailyCompletion(pattern) {
  const today = getTodayNumber();
  const todayDate = getTodayDateString();
  const score = pattern.reduce((a, b) => a + b, 0);
  const total = pattern.length;
  const perfect = score === total;

  const state = getDailyState();

  // Streak logic
  let newStreak = 1;
  if (state.lastCompletedDay === today - 1) {
    newStreak = (state.streak || 0) + 1;
  } else if (state.lastCompletedDay === today) {
    newStreak = state.streak || 1; // already counted today
  }

  const newState = {
    ...state,
    lastCompletedDay: today,
    lastCompletedDate: todayDate,
    streak: newStreak,
    totalCompleted: (state.totalCompleted || 0) + (state.lastCompletedDay === today ? 0 : 1),
    perfectDates: perfect
      ? [...(state.perfectDates || []), todayDate].filter((d, i, a) => a.indexOf(d) === i)
      : (state.perfectDates || []),
    history: {
      ...(state.history || {}),
      [String(today)]: { score, total, pattern, perfect, date: todayDate },
    },
  };

  saveDailyState(newState);
  return newState;
}

/**
 * Returns the current displayable daily streak, accounting for missed days.
 * Same logic as the main streak: if you missed yesterday, streak is dead.
 */
export function getCurrentDailyStreak() {
  const state = getDailyState();
  if (!state.lastCompletedDay || !state.streak) return 0;
  const today = getTodayNumber();
  const lastDay = state.lastCompletedDay;
  // Alive if completed today or yesterday
  if (lastDay === today || lastDay === today - 1) return state.streak;
  return 0;
}

// ── Share text (Wordle-style) ───────────────────────────────────────────────

/**
 * Generate the shareable result text.
 * Format:
 *   Accession #142 — 4/5 ⭐
 *   🟩🟩⬛🟩🟩
 *   accession.app
 *
 * The ⭐ appears only for perfect scores.
 */
export function generateShareText(dayNum, pattern, score, total) {
  const squares = pattern.map(p => p ? '🟩' : '⬛').join('');
  const perfect = score === total;
  const badge = perfect ? ' ⭐' : '';
  return `Accession #${dayNum} — ${score}/${total}${badge}\n${squares}`;
}
