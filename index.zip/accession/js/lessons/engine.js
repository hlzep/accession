/* ============================================================
   ACCESSION - LESSON ENGINE
   Plays through a lesson card by card.
   Each card type is a small render function below.
   ============================================================ */

import { getLesson, getArtwork, getArtist, getMovement, getRegion } from '../core/content.js';
import { markEncountered, markMastered, markLessonCompleted, tickStreak, scheduleReview, recordReviewCorrect, recordReviewMiss, recordWallLabelReview, setSeenInPerson, getState } from '../core/state.js';
import { navigate } from '../app.js';
import { buildPlacard } from '../core/placard.js';
import { buildReviewLesson } from './review.js';
import { buildArtworkMap, buildComparisonMap } from '../core/map.js';
let currentLesson = null;
let currentCardIndex = 0;
let correctCount = 0;
let incorrectCount = 0;

/**
 * Start a lesson. Renders into a full-screen shell.
 * Called by app.js's startLesson wrapper; views should call that, not this.
 */
export function startLessonImpl(lessonId) {
  currentLesson = getLesson(lessonId);
  if (!currentLesson) {
    alert('Lesson not found: ' + lessonId);
    return;
  }
  currentCardIndex = 0;
  correctCount = 0;
  incorrectCount = 0;
  tickStreak();
  renderShell();
  renderCurrentCard();
}

/**
 * Start a review session from the SRS queue.
 */
export function startReviewImpl() {
  const lesson = buildReviewLesson();
  if (!lesson) {
    alert('Nothing due for review right now.');
    return;
  }
  currentLesson = lesson;
  currentCardIndex = 0;
  correctCount = 0;
  incorrectCount = 0;
  tickStreak();
  renderShell();
  renderCurrentCard();
}

function renderShell() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="lesson-shell">
      <div class="lesson-progress-bar">
        <div class="lesson-progress-bar__fill" id="lesson-progress-fill" style="width: 0%"></div>
      </div>
      <header class="lesson-header">
        <button class="lesson-close" id="lesson-close" aria-label="Close lesson">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
        <span class="lesson-step" id="lesson-step"></span>
        <div style="width: 36px;"></div>
      </header>
      <main class="lesson-body" id="lesson-body"></main>
      <footer class="lesson-footer" id="lesson-footer"></footer>
    </div>
  `;
  document.getElementById('lesson-close').addEventListener('click', () => {
    if (confirm('Leave this lesson? Your progress will be lost.')) navigate('today');
  });
}

function renderCurrentCard() {
  const card = currentLesson.cards[currentCardIndex];
  if (!card) {
    finishLesson();
    return;
  }
  // Update progress bar and step indicator
  const progress = ((currentCardIndex) / currentLesson.cards.length) * 100;
  document.getElementById('lesson-progress-fill').style.width = progress + '%';
  document.getElementById('lesson-step').textContent =
    `${currentCardIndex + 1} of ${currentLesson.cards.length}`;

  const body = document.getElementById('lesson-body');
  const footer = document.getElementById('lesson-footer');
  body.innerHTML = '';
  footer.innerHTML = '';

  switch (card.type) {
    case 'context':       renderContextCard(card, body, footer); break;
    case 'wall-label':    renderWallLabelCard(card, body, footer); break;
    case 'quiz-artist':   renderArtistQuiz(card, body, footer); break;
    case 'quiz-movement': renderMovementQuiz(card, body, footer); break;
    case 'quiz-region':   renderRegionQuiz(card, body, footer); break;
    case 'quiz-date':     renderDateQuiz(card, body, footer); break;
    case 'quiz-before-after': renderBeforeAfterQuiz(card, body, footer); break;
    case 'quiz-medium':    renderMediumQuiz(card, body, footer); break;
    case 'comparison':    renderComparisonCard(card, body, footer); break;
    case 'reward':        renderReward(body, footer); break;
    // Visual mastery games
    case 'quiz-detail':     renderDetailChallenge(card, body, footer); break;
    case 'quiz-timeline':   renderTimelineChallenge(card, body, footer); break;
    case 'quiz-technique':  renderTechniqueChallenge(card, body, footer); break;
    case 'quiz-compare':    renderCompareChallenge(card, body, footer); break;
    default:
      body.innerHTML = `<p>Unknown card type: ${card.type}</p>`;
      renderContinueButton(footer);
  }
}

function advance() {
  currentCardIndex += 1;
  renderCurrentCard();
}

/* ===== CARD RENDERERS ===== */

// 1. CONTEXT CARD: pure historical prose, no quiz.
function renderContextCard(card, body, footer) {
  body.innerHTML = `
    <div class="lesson-card-title">${card.title}</div>
    <div class="lesson-card-meta">Historical context</div>
    <div class="lesson-card-body">${card.body}</div>
  `;
  renderContinueButton(footer, 'Continue');
}

// 2. WALL LABEL: artwork image with description, like a museum wall.
function renderWallLabelCard(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) return;
  markEncountered(art.id);
  // If this is a review session, record the wall label as reviewed
  if (currentLesson && currentLesson.isReviewSession) {
    recordWallLabelReview(art.id);
  } else {
    // First encounter: schedule for future review
    scheduleReview(art.id);
  }

  const artist = art.artistId ? getArtist(art.artistId) : null;
  const artistLine = artist
    ? `${artist.name} <span class="year">${formatYear(art.year)}</span>`
    : `<span class="year">${formatYear(art.year)}</span>`;

  const mapHtml = buildArtworkMap(art.lat, art.lng, art.originLabel || '');
  const artState = (getState().artworkState || {})[art.id] || {};

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="${art.title}" />
    ${mapHtml}
    <div class="lesson-card-title">${art.title}</div>
    <div class="lesson-card-meta">${artistLine}</div>
    <div class="lesson-card-body">${art.wallLabel}</div>
    <div class="seen-in-person-row">
      <span class="seen-in-person-label">Seen in person?</span>
      <div class="seen-in-person-btns">
        <button class="seen-in-person-btn${artState && artState.seenInPerson === 'yes' ? ' is-active' : ''}" data-val="yes">Yes</button>
        <button class="seen-in-person-btn${artState && artState.seenInPerson === 'maybe' ? ' is-active' : ''}" data-val="maybe">Maybe</button>
        <button class="seen-in-person-btn${artState && artState.seenInPerson === 'no' ? ' is-active' : ''}" data-val="no">No</button>
      </div>
    </div>
  `;
  body.querySelectorAll('.seen-in-person-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const v = btn.dataset.val;
      setSeenInPerson(art.id, v);
      body.querySelectorAll('.seen-in-person-btn').forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
    });
  });
  renderContinueButton(footer, 'Continue');
}

// 3. ARTIST QUIZ: image + 4 artist names, pick the painter.
function renderArtistQuiz(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) return;
  const options = shuffle([card.correctArtistId, ...card.distractorArtistIds]);

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image lesson-card-image--quiz" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="" />
    <div class="lesson-question">Who painted this?</div>
    <div id="quiz-options">
      ${options.map(id => {
        const artist = getArtist(id);
        return `<button class="quiz-option" data-id="${id}">${artist?.name || id}</button>`;
      }).join('')}
    </div>
    <div id="quiz-feedback"></div>
  `;
  bindQuizOptions({
    artworkId: art.id,
    correctId: card.correctArtistId,
    explanationFn: id => {
      const correct = getArtist(card.correctArtistId);
      if (id === card.correctArtistId) {
        return `${correct.name}, ${formatYear(art.year)}. ${correct.blurb}`;
      }
      const guess = getArtist(id);
      return `Not quite — that's the right era but not the right hand. This is by ${correct.name}.`;
    },
    footer,
  });
}

// 4. MOVEMENT QUIZ: image + 4 movement names.
function renderMovementQuiz(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) return;
  const options = shuffle([card.correctMovementId, ...card.distractorMovementIds]);

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image lesson-card-image--quiz" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="" />
    <div class="lesson-question">Which movement does this belong to?</div>
    <div id="quiz-options">
      ${options.map(id => {
        const mov = getMovement(id);
        return `<button class="quiz-option" data-id="${id}">${mov?.name || id}</button>`;
      }).join('')}
    </div>
    <div id="quiz-feedback"></div>
  `;
  bindQuizOptions({
    artworkId: art.id,
    correctId: card.correctMovementId,
    explanationFn: id => {
      const correct = getMovement(card.correctMovementId);
      if (id === card.correctMovementId) {
        return `Correct. ${correct.blurb}`;
      }
      return `Close but no — this is ${correct.name}.`;
    },
    footer,
  });
}

// 5. DATE QUIZ: slider + editable year input, both synced.
function renderDateQuiz(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) return;
  const midYear = Math.round((card.rangeStart + card.rangeEnd) / 2);

  // Pick a verb based on medium
  const medium = (art.medium || '').toLowerCase();
  const verb = /marble|stone|limestone|basalt|carved|petroglyph|schist/.test(medium) ? 'carved'
             : /bronze|cast|copper/.test(medium) ? 'cast'
             : /fresco|mosaic|brick|architecture/.test(medium) ? 'built'
             : 'made';

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image lesson-card-image--quiz" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="" />
    <div class="lesson-question">When was this ${verb}?</div>
    <div class="date-slider">
      <div class="date-slider__input-row">
        <input type="number" id="date-input" class="date-slider__text-input"
               value="${midYear}" min="${card.rangeStart}" max="${card.rangeEnd}"
               inputmode="numeric" autocomplete="off" aria-label="Year guess" />
        <span class="date-slider__era-label" id="date-era-label">${midYear < 0 ? 'BCE' : 'CE'}</span>
      </div>
      <input type="range" id="date-range" min="${card.rangeStart}" max="${card.rangeEnd}" value="${midYear}" />
      <div class="date-slider__range">
        <span>${formatYear(card.rangeStart)}</span>
        <span>${formatYear(card.rangeEnd)}</span>
      </div>
    </div>
    <div id="quiz-feedback"></div>
  `;

  const inputEl = document.getElementById('date-input');
  const rangeEl = document.getElementById('date-range');
  const eraEl   = document.getElementById('date-era-label');

  function clamp(v) { return Math.max(card.rangeStart, Math.min(card.rangeEnd, v)); }

  // Slider → text input
  rangeEl.addEventListener('input', () => {
    const v = parseInt(rangeEl.value, 10);
    inputEl.value = v;
    eraEl.textContent = v < 0 ? 'BCE' : 'CE';
  });

  // Text input → slider (live as user types)
  inputEl.addEventListener('input', () => {
    const v = parseInt(inputEl.value, 10);
    if (!isNaN(v)) {
      rangeEl.value = clamp(v);
      eraEl.textContent = v < 0 ? 'BCE' : 'CE';
    }
  });

  // Snap to valid range on blur
  inputEl.addEventListener('blur', () => {
    const v = parseInt(inputEl.value, 10);
    const clamped = isNaN(v) ? midYear : clamp(v);
    inputEl.value = clamped;
    rangeEl.value = clamped;
    eraEl.textContent = clamped < 0 ? 'BCE' : 'CE';
  });

  // Submit
  footer.innerHTML = `<button class="btn btn--primary btn--full btn--lg" id="submit-date">Confirm guess</button>`;
  document.getElementById('submit-date').addEventListener('click', () => {
    const raw = parseInt(inputEl.value, 10);
    const guess = isNaN(raw) ? parseInt(rangeEl.value, 10) : clamp(raw);
    const diff = Math.abs(guess - card.correctYear);
    rangeEl.disabled = true;
    inputEl.disabled = true;
    const isClose = diff <= 25;
    if (isClose) { correctCount++; markMastered(art.id); }
    else { incorrectCount++; }
    const feedback = document.getElementById('quiz-feedback');
    feedback.className = 'lesson-feedback' + (isClose ? '' : ' is-incorrect');
    feedback.innerHTML = `
      <span class="lesson-feedback__label">${isClose ? '✓ Within 25 years' : 'Off by ' + diff + ' years'}</span>
      <strong>${art.title}</strong> was ${verb} in ${formatYear(card.correctYear)}.
    `;
    renderContinueButton(footer, 'Continue');
  });
}

// 6. BEFORE / AFTER: two artworks, which came first?
function renderBeforeAfterQuiz(card, body, footer) {
  const earlier = getArtwork(card.earlierArtworkId);
  const later = getArtwork(card.laterArtworkId);
  if (!earlier || !later) return;
  // Randomly position them
  const swap = Math.random() < 0.5;
  const left = swap ? later : earlier;
  const right = swap ? earlier : later;

  body.innerHTML = `
    <div class="lesson-question">Which came first?</div>
    <div class="before-after-grid">
      <button class="before-after-option" data-id="${left.id}">
        <img referrerpolicy="no-referrer" src="${left.image || buildPlacard(left)}" data-placard="${buildPlacard(left)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${left.metObjectId || ''}" alt="" />
        <div class="before-after-option__caption">${left.title}</div>
      </button>
      <button class="before-after-option" data-id="${right.id}">
        <img referrerpolicy="no-referrer" src="${right.image || buildPlacard(right)}" data-placard="${buildPlacard(right)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${right.metObjectId || ''}" alt="" />
        <div class="before-after-option__caption">${right.title}</div>
      </button>
    </div>
    <div id="quiz-feedback"></div>
  `;
  body.querySelectorAll('.before-after-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const guess = btn.dataset.id;
      const isCorrect = guess === earlier.id;
      // Reveal answers
      body.querySelectorAll('.before-after-option').forEach(b => {
        b.disabled = true;
        if (b.dataset.id === earlier.id) b.classList.add('is-correct');
        else if (b === btn) b.classList.add('is-incorrect');
      });
      if (isCorrect) {
        correctCount++;
        markMastered(earlier.id);
      } else {
        incorrectCount++;
      }
      const feedback = document.getElementById('quiz-feedback');
      feedback.className = 'lesson-feedback' + (isCorrect ? '' : ' is-incorrect');
      feedback.innerHTML = `
        <span class="lesson-feedback__label">${isCorrect ? 'Correct' : 'Other way around'}</span>
        <strong>${earlier.title}</strong> (${formatYear(earlier.year)}) came before <strong>${later.title}</strong> (${formatYear(later.year)}).
      `;
      renderContinueButton(footer, 'Continue');
    });
  });
}

// 6b. REGION QUIZ: image + 4 region names. "Where was this made?"
function renderRegionQuiz(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) return;
  const options = shuffle([card.correctRegionId, ...card.distractorRegionIds]);

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image lesson-card-image--quiz" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="" />
    <div class="lesson-question">Where in the world was this made?</div>
    <div id="quiz-options">
      ${options.map(id => {
        const r = getRegion(id);
        return `<button class="quiz-option" data-id="${id}">${r?.name || id}</button>`;
      }).join('')}
    </div>
    <div id="quiz-feedback"></div>
  `;
  bindQuizOptions({
    artworkId: art.id,
    correctId: card.correctRegionId,
    explanationFn: id => {
      const correct = getRegion(card.correctRegionId);
      if (id === card.correctRegionId) {
        return `Correct. ${correct.blurb}`;
      }
      return `Not quite — this is from ${correct.name}.`;
    },
    footer,
  });
}

// 6c-MEDIUM QUIZ: image + 4 medium options. "What material is this made from?"
// card: { type: 'quiz-medium', artworkId, correctMedium, distractorMediums: [...], explanation }
// correctMedium and distractorMediums are short display strings e.g. "Marble", "Bronze", "Fresco", "Terracotta"
function renderMediumQuiz(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) return;
  const options = shuffle([card.correctMedium, ...card.distractorMediums]);

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image lesson-card-image--quiz" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="" />
    <div class="lesson-question">What material or technique was used to make this?</div>
    <div id="quiz-options">
      ${options.map(m => `<button class="quiz-option" data-id="${m}">${m}</button>`).join('')}
    </div>
    <div id="quiz-feedback"></div>
  `;
  bindQuizOptions({
    artworkId: art.id,
    correctId: card.correctMedium,
    explanationFn: id => {
      if (id === card.correctMedium) {
        return `Correct — ${card.explanation || card.correctMedium + '.'}`;
      }
      return `Not quite — this is ${card.correctMedium}. ${card.explanation || ''}`;
    },
    footer,
  });
}


// No quiz; this is a Synthesis-tier card. The user reads, looks, and continues.
function renderComparisonCard(card, body, footer) {
  for (const aid of card.artworkIds || []) {
    markEncountered(aid);
  }
  const arts = (card.artworkIds || []).map(getArtwork).filter(Boolean);
  if (arts.length === 0) {
    body.innerHTML = `<p>No artworks for this comparison.</p>`;
    renderContinueButton(footer);
    return;
  }

  // Build comparison map if artworks have coordinates
  const mapPoints = arts
    .filter(a => a.lat != null && a.lng != null)
    .map(a => ({ lat: a.lat, lng: a.lng }));
  const mapHtml = mapPoints.length >= 2 ? buildComparisonMap(mapPoints) : '';

  const itemsHtml = arts.map(art => {
    const artist = art.artistId ? getArtist(art.artistId) : null;
    return `
      <div class="comparison-item">
        <img referrerpolicy="no-referrer" class="comparison-item__image" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="${art.title}" />
        <div class="comparison-item__title">${art.title}</div>
        <div class="comparison-item__meta">${artist ? artist.shortName + ' · ' : ''}${formatYear(art.year)} · ${getRegion(art.regionId)?.name || ''}</div>
      </div>
    `;
  }).join('');

  body.innerHTML = `
    <div class="lesson-card-title">${card.title}</div>
    <div class="lesson-card-meta">A comparison across regions</div>
    <div class="comparison-grid">${itemsHtml}</div>
    ${mapHtml}
    <div class="lesson-card-body">${card.body || ''}</div>
  `;
  renderContinueButton(footer, 'Continue');
}

// 6d. COMPREHENSION QUIZ: used during review sessions after wall labels resurface.
// Question and options come from the artwork's comprehensionQuestion field.
function renderComprehensionQuiz(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) { renderContinueButton(footer); return; }

  const options = card.options || [];
  const shuffled = [...options]; // keep original order for comprehension questions

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image lesson-card-image--quiz" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" alt="" />
    <div class="lesson-question">${card.question}</div>
    <div id="quiz-options">
      ${shuffled.map((opt, i) => `<button class="quiz-option" data-id="${i}">${opt}</button>`).join('')}
    </div>
    <div id="quiz-feedback"></div>
  `;

  const correctIndexStr = String(card.correctIndex);
  bindQuizOptions({
    artworkId: art.id,
    correctId: correctIndexStr,
    explanationFn: id => {
      if (id === correctIndexStr) return card.explanation || '';
      return `Not quite. ${card.explanation || ''}`;
    },
    footer,
    isReview: !!(currentLesson && currentLesson.isReviewSession),
  });
}

// 7. REWARD: end-of-lesson screen.
function renderReward(body, footer) {
  // Lessons may be tagged with either movementId (legacy) or eraId (new model)
  const movement = currentLesson.movementId ? getMovement(currentLesson.movementId) : null;
  const subtitle = movement?.name || currentLesson.subtitle || '';
  body.innerHTML = `
    <div class="reward-screen">
      <div class="reward-seal-wrap">
        <div class="wax-seal wax-seal--with-ring">
          <span class="wax-seal__number">✓</span>
        </div>
      </div>
      <div class="reward-eyebrow">Lesson complete</div>
      <h1 class="reward-title">${currentLesson.title}</h1>
      <p class="reward-subtitle">${subtitle}</p>
      <div class="reward-stats">
        <div class="plaque">
          <span class="plaque__label">Correct</span>
          <span class="plaque__value">${correctCount}</span>
        </div>
        <div class="plaque">
          <span class="plaque__label">Missed</span>
          <span class="plaque__value">${incorrectCount}</span>
        </div>
        <div class="plaque">
          <span class="plaque__label">New works</span>
          <span class="plaque__value">${countNewArtworks()}</span>
        </div>
      </div>
    </div>
  `;
  document.getElementById('lesson-progress-fill').style.width = '100%';
  footer.innerHTML = `<button class="btn btn--primary btn--full btn--lg" id="finish-btn">Return to today</button>`;
  document.getElementById('finish-btn').addEventListener('click', () => {
    markLessonCompleted(currentLesson.movementId || currentLesson.eraId, currentLesson.id);
    navigate('today');
  });
}

function finishLesson() {
  markLessonCompleted(currentLesson.movementId || currentLesson.eraId, currentLesson.id);
  navigate('today');
}

/* ===== HELPERS ===== */

function bindQuizOptions({ artworkId, correctId, explanationFn, footer, isReview, onCorrect }) {
  const container = document.getElementById('quiz-options');
  container.querySelectorAll('.quiz-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const guess = btn.dataset.id;
      const isCorrect = guess === correctId;

      container.querySelectorAll('.quiz-option').forEach(b => {
        if (b.dataset.id === correctId) b.classList.add('is-correct');
        else if (b === btn) b.classList.add('is-incorrect');
        else b.classList.add('is-disabled');
        b.disabled = true;
      });

      if (isCorrect) {
        correctCount++;
        markMastered(artworkId);
        if (isReview) recordReviewCorrect(artworkId);
        else scheduleReview(artworkId);
        if (onCorrect) onCorrect();
      } else {
        incorrectCount++;
        if (isReview) recordReviewMiss(artworkId);
      }
      const feedback = document.getElementById('quiz-feedback');
      feedback.className = 'lesson-feedback' + (isCorrect ? '' : ' is-incorrect');
      feedback.innerHTML = `
        <span class="lesson-feedback__label">${isCorrect ? '✓ Correct' : 'Not this time'}</span>
        ${explanationFn(guess)}
      `;
      renderContinueButton(footer, 'Continue');
    });
  });
}

// ── VISUAL MASTERY GAMES ──────────────────────────────────────────────────────

// DETAIL CHALLENGE: identify an artwork from a tight crop of it.
function renderDetailChallenge(card, body, footer) {
  // card.artworkId = the correct artwork
  // card.distractorIds = 3 other artwork IDs
  // card.cropPercent = { x, y, w, h } as 0–100 values (default: random corner crop ~30%)
  const art = getArtwork(card.artworkId);
  if (!art) return;
  const all = shuffle([card.artworkId, ...(card.distractorIds || [])]);
  const options = all.map(id => getArtwork(id)).filter(Boolean);

  const crop = card.cropPercent || { x: 30, y: 20, w: 35, h: 35 };
  // CSS object-position trick to show only a crop of the image
  const pos = `${crop.x}% ${crop.y}%`;
  const size = `${Math.round(100 / (crop.w / 100))}%`;

  body.innerHTML = `
    <div class="detail-challenge">
      <div class="detail-challenge__hint">Which artwork is this detail from?</div>
      <div class="detail-challenge__crop">
        <img referrerpolicy="no-referrer" src="${art.image || buildPlacard(art)}"
             data-placard="${buildPlacard(art)}"
             onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
             style="object-fit:cover;object-position:${pos};width:100%;height:100%;display:block;"
             alt="" />
      </div>
      <div class="detail-challenge__options">
        ${options.map(o => `
          <button class="detail-option" data-id="${o.id}">
            <img referrerpolicy="no-referrer" src="${o.image || buildPlacard(o)}"
                 data-placard="${buildPlacard(o)}"
                 onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
                 alt="${o.title}" />
            <span class="detail-option__title">${o.title.length > 32 ? o.title.slice(0, 32) + '…' : o.title}</span>
          </button>
        `).join('')}
      </div>
      <div id="quiz-feedback"></div>
    </div>
  `;

  // After correct answer, reveal full image
  bindQuizOptions({
    artworkId: art.id,
    correctId: card.artworkId,
    explanationFn: id => {
      const chosen = getArtwork(id);
      if (id === card.artworkId) return `Correct — <strong>${art.title}</strong> (${formatYear(art.year)}).`;
      return `Not quite — that's <strong>${chosen?.title || id}</strong>. The detail was from <strong>${art.title}</strong>.`;
    },
    onCorrect: () => {
      // Reveal the full image
      const cropEl = body.querySelector('.detail-challenge__crop img');
      if (cropEl) {
        cropEl.style.transition = 'object-position 0.8s ease, object-size 0.8s ease';
        cropEl.style.objectPosition = '50% 50%';
        cropEl.style.objectFit = 'contain';
      }
    },
    footer,
  });
}

// TIMELINE CHALLENGE: tap artworks in chronological order.
function renderTimelineChallenge(card, body, footer) {
  // card.artworkIds = 3 artwork IDs to sort chronologically
  const artworks = (card.artworkIds || []).map(getArtwork).filter(Boolean);
  if (artworks.length < 2) { renderContinueButton(footer); return; }

  const sorted = [...artworks].sort((a, b) => a.year - b.year);
  const shuffled = shuffle([...artworks]);
  let selected = []; // IDs in selection order
  let answered = false;

  function render() {
    body.innerHTML = `
      <div class="timeline-challenge">
        <div class="timeline-challenge__hint">Tap in chronological order — earliest first</div>
        <div class="timeline-challenge__queue" id="tl-queue">
          ${shuffled.filter(a => !selected.includes(a.id)).map(a => `
            <button class="tl-card ${answered ? 'is-disabled' : ''}" data-id="${a.id}">
              <img referrerpolicy="no-referrer" src="${a.image || buildPlacard(a)}"
                   data-placard="${buildPlacard(a)}"
                   onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
                   alt="${a.title}" />
              <span class="tl-card__title">${a.title.length > 28 ? a.title.slice(0,28)+'…' : a.title}</span>
            </button>
          `).join('')}
        </div>
        <div class="timeline-challenge__selected" id="tl-selected">
          ${selected.map((id, i) => {
            const a = getArtwork(id);
            return `<div class="tl-slot tl-slot--filled" data-pos="${i}">
              <img referrerpolicy="no-referrer" src="${a?.image || ''}" alt="${a?.title || ''}" />
              <span>${a?.title?.slice(0,20) || ''}</span>
            </div>`;
          }).join('')}
          ${Array.from({length: artworks.length - selected.length}).map(() =>
            `<div class="tl-slot tl-slot--empty"></div>`
          ).join('')}
        </div>
        <div id="quiz-feedback" class="timeline-challenge__feedback"></div>
      </div>
    `;

    if (!answered) {
      body.querySelectorAll('.tl-card').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.id;
          selected.push(id);
          markEncountered(id);

          if (selected.length === artworks.length) {
            // Check order
            answered = true;
            const isCorrect = selected.every((id, i) => id === sorted[i].id);
            const fb = document.getElementById('quiz-feedback');

            if (isCorrect) {
              correctCount++;
              selected.forEach(id => markMastered(id));
              fb.className = 'timeline-challenge__feedback lesson-feedback';
              fb.innerHTML = `<span class="lesson-feedback__label">✓ Correct order!</span>
                ${sorted.map(a => `<strong>${a.title}</strong> (${formatYear(a.year)})`).join(' → ')}`;
            } else {
              incorrectCount++;
              fb.className = 'timeline-challenge__feedback lesson-feedback is-incorrect';
              fb.innerHTML = `<span class="lesson-feedback__label">The correct order was:</span>
                ${sorted.map(a => `<strong>${a.title}</strong> (${formatYear(a.year)})`).join(' → ')}`;
            }
            renderContinueButton(footer, 'Continue');
          } else {
            render();
          }
        });
      });
    }
  }
  render();
}

// TECHNIQUE CHALLENGE: choose the correct technique from a visual.
// This is a specialised medium quiz that groups options into meaningful
// technique families rather than free-form medium strings.
function renderTechniqueChallenge(card, body, footer) {
  // card.artworkId, card.correctTechnique, card.distractorTechniques, card.explanation
  const art = getArtwork(card.artworkId);
  if (!art) return;
  const options = shuffle([card.correctTechnique, ...(card.distractorTechniques || [])]);

  const techniqueIcons = {
    'Fresco': '🖌️', 'Tempera': '🥚', 'Oil on panel': '🪵', 'Oil on canvas': '🎨',
    'Lost-wax bronze': '🔥', 'Carved marble': '⛏️', 'Carved stone': '⛏️',
    'Mosaic': '🟦', 'Stained glass': '🪟', 'Woodblock print': '🌲',
    'Watercolor on paper': '💧', 'Porcelain': '⚪', 'Terracotta': '🏺',
  };

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image lesson-card-image--quiz"
         src="${art.image || buildPlacard(art)}"
         data-placard="${buildPlacard(art)}"
         onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
         data-met-id="${art.metObjectId || ''}" alt="" />
    <div class="lesson-question">What technique was used to make this?</div>
    <div id="quiz-options">
      ${options.map(t => `
        <button class="quiz-option technique-option" data-id="${t}">
          <span class="technique-option__icon">${techniqueIcons[t] || '🖼️'}</span>
          <span class="technique-option__label">${t}</span>
        </button>
      `).join('')}
    </div>
    <div id="quiz-feedback"></div>
  `;

  bindQuizOptions({
    artworkId: art.id,
    correctId: card.correctTechnique,
    explanationFn: id => {
      if (id === card.correctTechnique) return `Correct — ${card.explanation || card.correctTechnique + '.'}`;
      return `Not quite — this is ${card.correctTechnique}. ${card.explanation || ''}`;
    },
    footer,
  });
}

// COMPARE CHALLENGE: two images side by side, spot the correct statement
// about how they differ (or share something).
function renderCompareChallenge(card, body, footer) {
  // card.artworkIds = [idA, idB]
  // card.question = string
  // card.options = [{ text, correct, explanation }, ...]
  const [artA, artB] = (card.artworkIds || []).map(getArtwork).filter(Boolean);
  if (!artA || !artB) { renderContinueButton(footer); return; }

  const options = shuffle(card.options || []);
  let revealed = false;

  body.innerHTML = `
    <div class="compare-challenge">
      <div class="compare-challenge__hint">${card.question || 'What is the key difference?'}</div>
      <div class="compare-challenge__images">
        <div class="compare-item">
          <img referrerpolicy="no-referrer" src="${artA.image || buildPlacard(artA)}"
               data-placard="${buildPlacard(artA)}"
               onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
               alt="${artA.title}" />
          <span class="compare-item__label">${artA.title.length > 24 ? artA.title.slice(0,24)+'…' : artA.title}</span>
        </div>
        <div class="compare-challenge__vs">vs</div>
        <div class="compare-item">
          <img referrerpolicy="no-referrer" src="${artB.image || buildPlacard(artB)}"
               data-placard="${buildPlacard(artB)}"
               onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
               alt="${artB.title}" />
          <span class="compare-item__label">${artB.title.length > 24 ? artB.title.slice(0,24)+'…' : artB.title}</span>
        </div>
      </div>
      <div id="compare-options" class="compare-challenge__options">
        ${options.map((o, i) => `
          <button class="quiz-option compare-option" data-idx="${i}">
            ${o.text}
          </button>
        `).join('')}
      </div>
      <div id="quiz-feedback"></div>
    </div>
  `;

  const correct = options.find(o => o.correct);
  body.querySelectorAll('.compare-option').forEach(btn => {
    btn.addEventListener('click', () => {
      if (revealed) return;
      revealed = true;
      const idx = parseInt(btn.dataset.idx, 10);
      const chosen = options[idx];
      const isCorrect = !!chosen?.correct;

      if (isCorrect) { correctCount++; markMastered(artA.id); markMastered(artB.id); }
      else incorrectCount++;

      // Highlight options
      body.querySelectorAll('.compare-option').forEach((b, i) => {
        const opt = options[i];
        b.disabled = true;
        if (opt.correct) b.classList.add('is-correct');
        else if (i === idx && !isCorrect) b.classList.add('is-incorrect');
      });

      const fb = document.getElementById('quiz-feedback');
      fb.className = 'lesson-feedback' + (isCorrect ? '' : ' is-incorrect');
      fb.innerHTML = `
        <span class="lesson-feedback__label">${isCorrect ? '✓ Correct' : '✗ ' + correct?.text}</span>
        ${chosen?.explanation || correct?.explanation || ''}
      `;
      renderContinueButton(footer, 'Continue');
    });
  });
}

// ── Continue button ──────────────────────────────────────────────────────────

function renderContinueButton(footer, label = 'Continue') {
  footer.innerHTML = `<button class="btn btn--primary btn--full btn--lg" id="continue-btn">${label}</button>`;
  document.getElementById('continue-btn').addEventListener('click', advance);
}



function shuffle(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function countNewArtworks() {
  // Count artworks referenced in this lesson
  const ids = new Set();
  for (const card of currentLesson.cards) {
    if (card.artworkId) ids.add(card.artworkId);
    if (card.earlierArtworkId) ids.add(card.earlierArtworkId);
    if (card.laterArtworkId) ids.add(card.laterArtworkId);
  }
  return ids.size;
}

function formatYear(year) {
  if (year < 0) return `${Math.abs(year)} BCE`;
  return year;
}
