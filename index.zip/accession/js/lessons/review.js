/* ============================================================
   ACCESSION - REVIEW SESSION BUILDER
   Takes SRS due items and builds a lesson-shaped object that
   the existing lesson engine can play. Supports:
   - Wall label resurfacing with comprehension question
   - Quiz resurfacing at the correct difficulty tier
   ============================================================ */

import { getDueReviewItems } from '../core/state.js';
import { getArtwork } from '../core/content.js';

const MAX_REVIEW_ITEMS = 10;

/**
 * Build a review lesson from whatever is currently due.
 * Returns a lesson object (same shape as data/lessons/*.json)
 * or null if nothing is due.
 */
export function buildReviewLesson() {
  const { quizItems, wallLabelItems } = getDueReviewItems();
  if (quizItems.length === 0 && wallLabelItems.length === 0) return null;

  const cards = [];

  // Opening context card
  const totalDue = new Set([...quizItems, ...wallLabelItems]).size;
  cards.push({
    type: 'context',
    title: 'Revisit',
    body: `${totalDue} work${totalDue === 1 ? '' : 's'} to revisit. Some you've seen recently; some haven't crossed your desk in a while. The point is not to test you but to keep these works alive in memory — the way you keep any conversation going.`,
  });

  // Interleave wall labels and quizzes, capped at MAX_REVIEW_ITEMS
  const seen = new Set();
  let count = 0;

  // Wall labels first (re-encounters with the work), then quiz
  const allItems = [...new Set([...wallLabelItems, ...quizItems])].slice(0, MAX_REVIEW_ITEMS);

  for (const artId of allItems) {
    if (count >= MAX_REVIEW_ITEMS) break;
    const art = getArtwork(artId);
    if (!art) continue;

    // Wall label card if it's due
    if (wallLabelItems.includes(artId)) {
      cards.push({ type: 'wall-label', artworkId: artId });
      // Comprehension question if one exists
      if (art.comprehensionQuestion) {
        cards.push({
          type: 'quiz-comprehension',
          artworkId: artId,
          ...art.comprehensionQuestion,
        });
      }
    }

    // Quiz card if it's due (and we haven't already done wall label for this item)
    if (quizItems.includes(artId) && !wallLabelItems.includes(artId)) {
      cards.push(buildQuizCard(art));
    } else if (quizItems.includes(artId) && wallLabelItems.includes(artId)) {
      // Both due — add quiz after the wall label
      cards.push(buildQuizCard(art));
    }

    seen.add(artId);
    count++;
  }

  if (cards.length <= 1) return null; // Only the context card — nothing real to show

  // Reward card at end
  cards.push({ type: 'reward' });

  return {
    id: 'review-session',
    title: 'Revisit',
    subtitle: `${totalDue} work${totalDue === 1 ? '' : 's'} from your collection`,
    estimatedMinutes: Math.max(3, Math.round(cards.length * 0.5)),
    isReviewSession: true,
    cards,
  };
}

/**
 * Build a quiz card for an artwork, respecting its current SRS tier.
 */
function buildQuizCard(art) {
  // Default to region quiz — works for anonymous and attributed works
  // The engine already handles quiz-region and quiz-before-after
  return {
    type: 'quiz-region',
    artworkId: art.id,
    correctRegionId: art.regionId,
    distractorRegionIds: pickDistractors(art.regionId),
    _isReview: true,
  };
}

function pickDistractors(correctRegionId) {
  const all = [
    'europe', 'middle-east-north-africa', 'east-asia', 'south-asia',
    'southeast-asia', 'sub-saharan-africa', 'americas', 'oceania',
  ];
  return all.filter(r => r !== correctRegionId).slice(0, 3);
}
