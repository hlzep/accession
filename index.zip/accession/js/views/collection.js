/* ============================================================
   ACCESSION - COLLECTION VIEW (global thesis)
   The primary mode is a 6-era × N-region grid showing the user's
   progress across the global timeline. Tapping a dot shows the
   artwork in that cell.
   ============================================================ */

import { getState, setSeenInPerson } from '../core/state.js';
import {
  getAllArtworks, getEras, getRegions, getArtwork, getArtist,
  getArtworksForCell, getRegion, getEra,
} from '../core/content.js';
import { getNodeState, getCollectionStats, getCompletionStats, getCellMastery, getEraMastery } from '../core/progression.js';
import { buildPlacard } from '../core/placard.js';
import { buildArtworkMap } from '../core/map.js';

let viewMode = 'timeline';

export function renderCollection() {
  const app = document.getElementById('app');
  const stats = getCollectionStats();
  const total = getAllArtworks().length;
  const completion = getCompletionStats();

  app.innerHTML = `
    <div class="view">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-2)">
        <div class="eyebrow">Your accession</div>
        <button id="settings-btn" style="background:none;border:none;cursor:pointer;padding:var(--space-2);color:var(--color-sepia)">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="width:20px;height:20px">
            <circle cx="12" cy="8" r="3.5"/>
            <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
          </svg>
        </button>
      </div>
      <h1 style="margin-bottom: var(--space-4);">Collection</h1>

      <div class="reward-stats" style="margin-bottom: var(--space-6);">
        <div class="plaque">
          <span class="plaque__label">Encountered</span>
          <span class="plaque__value">${stats.encountered} <span style="color: var(--color-sepia-light); font-size: var(--type-body-s);">/ ${total}</span></span>
        </div>
        <div class="plaque">
          <span class="plaque__label">Mastered</span>
          <span class="plaque__value">${stats.mastered}</span>
        </div>
        <div class="plaque">
          <span class="plaque__label">In person</span>
          <span class="plaque__value">${stats.seenInPerson}</span>
        </div>
        <div class="plaque">
          <span class="plaque__label">Complete</span>
          <span class="plaque__value">${completion.pct}%</span>
        </div>
      </div>

      <div class="completion-breakdown">
        <div class="completion-bar-row">
          <span class="completion-bar-label">Artworks</span>
          <div class="completion-bar-track">
            <div class="completion-bar-fill completion-bar-fill--artworks" style="width:${completion.artworkPct}%"></div>
          </div>
          <span class="completion-bar-value">${completion.artworkDone}/${completion.artworkTotal}</span>
        </div>
        <div class="completion-bar-row">
          <span class="completion-bar-label">Lessons</span>
          <div class="completion-bar-track">
            <div class="completion-bar-fill completion-bar-fill--lessons" style="width:${completion.lessonPct}%"></div>
          </div>
          <span class="completion-bar-value">${completion.lessonDone}/${completion.lessonTotal}</span>
        </div>
        <div class="completion-bar-row">
          <span class="completion-bar-label">Exhibitions</span>
          <div class="completion-bar-track">
            <div class="completion-bar-fill completion-bar-fill--exhibitions" style="width:${completion.exhibitionPct}%"></div>
          </div>
          <span class="completion-bar-value">${completion.exhibitionDone}/${completion.exhibitionTotal}</span>
        </div>
      </div>

      <div style="display: flex; gap: var(--space-2); margin-bottom: var(--space-5);">
        <button class="btn ${viewMode === 'timeline' ? 'btn--primary' : 'btn--secondary'}" id="view-timeline" style="flex: 1;">Timeline</button>
        <button class="btn ${viewMode === 'grid' ? 'btn--primary' : 'btn--secondary'}" id="view-grid" style="flex: 1;">Grid</button>
      </div>

      <div id="collection-canvas"></div>
    </div>
  `;

  document.getElementById('settings-btn')?.addEventListener('click', () => {
    import('../app.js').then(m => m.navigate('profile'));
  });
  document.getElementById('view-timeline').addEventListener('click', () => {
    viewMode = 'timeline'; renderCollection();
  });
  document.getElementById('view-grid').addEventListener('click', () => {
    viewMode = 'grid'; renderCollection();
  });

  const canvas = document.getElementById('collection-canvas');
  if (viewMode === 'timeline') renderTimelineGrid(canvas);
  else renderTileGrid(canvas);
}

function renderTimelineGrid(container) {
  const eras = getEras();
  const regions = getRegions();
  const populatedRegions = regions.filter(r =>
    getAllArtworks().some(a => a.regionId === r.id)
  );

  const headerCells = [`<div class="timeline-grid__cell timeline-grid__header"></div>`];
  for (const era of eras) {
    headerCells.push(`
      <div class="timeline-grid__cell timeline-grid__header" title="${era.name}">${era.name}</div>
    `);
  }

  const rows = populatedRegions.map(region => {
    const cells = [`<div class="timeline-grid__cell timeline-grid__row-label">${region.name}</div>`];
    for (const era of eras) {
      const arts = getArtworksForCell(era.id, region.id);
      if (arts.length === 0) {
        cells.push(`<div class="timeline-grid__cell"></div>`);
      } else {
        const dots = arts.map(a => {
          const state = getNodeState(a.id);
          return `<span class="timeline-dot" data-state="${state}" data-artwork-id="${a.id}" title="${a.title}"></span>`;
        }).join('');
        cells.push(`
          <div class="timeline-grid__cell" data-era-id="${era.id}" data-region-id="${region.id}">
            <div class="timeline-grid__cell-content">${dots}</div>
          </div>
        `);
      }
    }
    return cells.join('');
  }).join('');

  container.innerHTML = `
    <div class="timeline-grid__wrap">
      <div class="timeline-grid" style="grid-template-columns: 100px repeat(${eras.length}, 120px);">
        ${headerCells.join('')}
        ${rows}
      </div>
    </div>
    <div style="padding: var(--space-3) 0; text-align: center; font-family: var(--font-serif); font-style: italic; color: var(--color-sepia); font-size: var(--type-body-s);">
      Swipe to scroll · Tap a dot to see the work · Gold rings mean seen in person
    </div>
    <div id="cell-detail"></div>
  `;

  container.querySelectorAll('.timeline-dot').forEach(dot => {
    dot.addEventListener('click', () => showArtworkPreview(dot.dataset.artworkId));
  });
}

function showArtworkPreview(artworkId) {
  const art = getArtwork(artworkId);
  if (!art) return;

  const region = getRegion(art.regionId);
  const era = getEra(art.eraId);
  const artist = art.artistId ? getArtist(art.artistId) : null;
  const state = getState();
  const artState = state.artworkState[art.id] || {};
  const seenValue = artState.seenInPerson;

  const mapHtml = buildArtworkMap(art.lat, art.lng, '');

  // Build or reuse the overlay
  let overlay = document.getElementById('artwork-sheet-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'artwork-sheet-overlay';
    overlay.className = 'artwork-sheet-overlay';
    document.body.appendChild(overlay);
  }

  overlay.innerHTML = `
    <div class="artwork-sheet" id="artwork-sheet">
      <div class="artwork-sheet__handle"></div>

      <img referrerpolicy="no-referrer" class="artwork-sheet__image"
        src="${art.image || buildPlacard(art)}"
        data-placard="${buildPlacard(art)}"
        onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
        alt="${art.title}"
      />

      ${mapHtml}

      <div class="artwork-sheet__body">
        <div class="eyebrow" style="margin-bottom: var(--space-1);">
          ${era?.name || ''} · ${region?.name || ''}
        </div>
        <h2 class="artwork-sheet__title">${art.title}</h2>
        <div class="artwork-sheet__meta">
          ${artist ? `${artist.name} · ` : ''}${formatYear(art.year)}
          ${art.medium ? ` · ${art.medium}` : ''}
        </div>

        <p class="artwork-sheet__wall-label">${art.wallLabel || ''}</p>

        ${art.longForm ? `<p class="artwork-sheet__long-form">${art.longForm}</p>` : ''}

        <div class="artwork-sheet__seen-row">
          <span class="artwork-sheet__seen-label">Seen in person?</span>
          <div class="artwork-sheet__seen-btns">
            <button class="artwork-sheet__seen-btn ${seenValue === 'yes' ? 'is-active' : ''}" data-val="yes">Yes</button>
            <button class="artwork-sheet__seen-btn ${seenValue === 'maybe' ? 'is-active' : ''}" data-val="maybe">Maybe</button>
            <button class="artwork-sheet__seen-btn ${seenValue === 'no' ? 'is-active' : ''}" data-val="no">No</button>
          </div>
        </div>
      </div>
    </div>
  `;

  // Show with animation
  requestAnimationFrame(() => {
    overlay.classList.add('is-visible');
    document.getElementById('artwork-sheet').classList.add('is-open');
  });

  // Dismiss on backdrop tap
  overlay.addEventListener('click', e => {
    if (e.target === overlay) dismissSheet(overlay);
  }, { once: true });

  // Dismiss on drag down (simple velocity check)
  const sheet = document.getElementById('artwork-sheet');
  let startY = 0;
  sheet.addEventListener('touchstart', e => { startY = e.touches[0].clientY; }, { passive: true });
  sheet.addEventListener('touchend', e => {
    if (e.changedTouches[0].clientY - startY > 60) dismissSheet(overlay);
  }, { passive: true });

  // Seen-in-person buttons
  overlay.querySelectorAll('.artwork-sheet__seen-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.dataset.val;
      setSeenInPerson(art.id, val);
      overlay.querySelectorAll('.artwork-sheet__seen-btn').forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
    });
  });
}

function dismissSheet(overlay) {
  const sheet = document.getElementById('artwork-sheet');
  if (sheet) sheet.classList.remove('is-open');
  overlay.classList.remove('is-visible');
  setTimeout(() => { if (overlay.parentNode) overlay.parentNode.removeChild(overlay); }, 350);
}

function renderTileGrid(container) {
  const artworks = getAllArtworks();
  const state = getState();
  container.innerHTML = `
    <div class="collection-grid">
      ${artworks.map(art => {
        const s = state.artworkState[art.id];
        const encountered = s && s.encountered;
        const seenInPerson = s && s.seenInPerson === 'yes';
        const nodeState = getNodeState(art.id);
        return `
          <div class="collection-tile ${encountered ? '' : 'is-faint'} ${seenInPerson ? 'is-seen-in-person' : ''}" data-artwork-id="${art.id}" style="cursor:pointer;">
            <img referrerpolicy="no-referrer" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" alt="${art.title}" />
            ${seenInPerson ? `<div class="collection-tile__seen-badge" title="Seen in person">★</div>` : ''}
            <div class="collection-tile__caption">${art.title}</div>
          </div>
        `;
      }).join('')}
    </div>
  `;

  container.querySelectorAll('[data-artwork-id]').forEach(tile => {
    tile.addEventListener('click', () => showArtworkPreview(tile.dataset.artworkId));
  });
}

function formatYear(year) {
  if (!year && year !== 0) return '';
  if (year < 0) return `${Math.abs(year)} BCE`;
  return String(year);
}
