/* ============================================================
   ACCESSION - PROFILE VIEW
   Curator ranks per movement, settings, partner pairing, author mode.
   ============================================================ */

import { getState, updateState, resetState, downloadBackup, importState } from '../core/state.js';
import { getRegions, getAllArtworks } from '../core/content.js';
import { getCuratorRank, RANK_NAMES, getCollectionStats } from '../core/progression.js';
import { syncStatus } from '../core/sync.js';

let avatarTapCount = 0;
let avatarTapTimer = null;

export function renderProfile() {
  const app = document.getElementById('app');
  const state = getState();
  const stats = getCollectionStats();
  const sync = syncStatus();

  app.innerHTML = `
    <div class="view">
      <div style="text-align: center; padding-top: var(--space-4); margin-bottom: var(--space-8);">
        <div id="profile-avatar" style="width: 80px; height: 80px; border-radius: 50%; background: var(--color-paper-deep); border: 1px solid var(--color-line); margin: 0 auto var(--space-3); display: flex; align-items: center; justify-content: center; font-family: var(--font-display); font-size: 2rem; cursor: pointer; user-select: none;">
          ${(state.displayName || 'A').charAt(0).toUpperCase()}
        </div>
        <h2 style="margin-bottom: 4px;">${state.displayName || 'Anonymous Visitor'}</h2>
        <div class="eyebrow">${stats.mastered} works mastered</div>
      </div>

      <h3 class="today-section__title"><span>Curator ranks</span></h3>
      <div class="card" style="margin-bottom: var(--space-6);">
        ${getRegions().filter(r => getAllArtworks().some(a => a.regionId === r.id)).map(r => renderRankRow(r)).join('')}
      </div>

      <h3 class="today-section__title"><span>Partner</span></h3>
      <div class="card" style="margin-bottom: var(--space-6);">
        <p style="font-size: var(--type-body-m); margin-bottom: var(--space-3);">
          ${state.partnerName ? `Connected with <strong>${state.partnerName}</strong>` : 'Not paired with anyone yet.'}
        </p>
        ${sync.configured ? `
          <div style="display: flex; gap: var(--space-2);">
            <button class="btn btn--secondary" id="pair-btn" style="flex: 1;">
              ${state.partnerName ? 'Change partner code' : 'Pair with Brandon'}
            </button>
          </div>
          <p style="margin-top: var(--space-3); font-size: var(--type-body-s); color: var(--color-sepia);">
            Your code: <strong style="font-family: monospace;">${state.userId}</strong>
          </p>
        ` : `
          <p style="font-size: var(--type-body-s); color: var(--color-sepia);">
            Live partner stats require a one-time Firebase setup. See /js/core/sync.js for instructions.
          </p>
        `}
      </div>

      <h3 class="today-section__title"><span>Settings</span></h3>
      <div class="card" style="margin-bottom: var(--space-6);">
        <div style="display: flex; flex-direction: column; gap: var(--space-3);">
          <button class="btn btn--secondary" id="set-name-btn">
            ${state.displayName ? 'Change display name' : 'Set display name'}
          </button>
          <button class="btn btn--secondary" id="redo-walkthrough-btn">Redo museum walkthrough</button>
          ${state.authorModeUnlocked ? `
            <button class="btn btn--secondary" id="author-mode-btn" style="border-color: var(--color-gold); color: var(--color-gold);">
              Author mode: ON
            </button>
          ` : ''}
        </div>
      </div>

      <h3 class="today-section__title"><span>Backup</span></h3>
      <div class="card" style="margin-bottom: var(--space-6);">
        <p style="font-size: var(--type-body-m); margin-bottom: var(--space-3); color: var(--color-sepia);">
          Save a copy of your progress to a file. Restore it later, or move it to another device.
        </p>
        <div style="display: flex; flex-direction: column; gap: var(--space-3);">
          <button class="btn btn--secondary" id="backup-btn">Save backup</button>
          <button class="btn btn--secondary" id="restore-btn">Restore from backup</button>
        </div>
        <input type="file" id="restore-file-input" accept="application/json,.json" style="display: none;" />
      </div>

      <div style="text-align: center; padding: var(--space-6) 0;">
        <button id="reset-btn" style="font-family: var(--font-sans); font-size: var(--type-body-s); color: var(--color-sepia-light); text-decoration: underline;">
          Reset all data
        </button>
      </div>
    </div>
  `;

  // Easter egg: 5 taps on avatar unlocks author mode
  document.getElementById('profile-avatar').addEventListener('click', () => {
    avatarTapCount += 1;
    clearTimeout(avatarTapTimer);
    avatarTapTimer = setTimeout(() => { avatarTapCount = 0; }, 1500);
    if (avatarTapCount >= 5) {
      avatarTapCount = 0;
      updateState({ authorModeUnlocked: true });
      alert('Author mode unlocked. You can now edit any card via a pencil icon.');
      renderProfile();
    }
  });

  document.getElementById('set-name-btn').addEventListener('click', () => {
    const name = prompt('What should we call you?', state.displayName || '');
    if (name && name.trim()) updateState({ displayName: name.trim() });
    renderProfile();
  });

  document.getElementById('redo-walkthrough-btn').addEventListener('click', () => {
    if (confirm('Redo the walkthrough? This will reset which works you marked as seen in person.')) {
      updateState(s => {
        s.hasCompletedWalkthrough = false;
        Object.keys(s.artworkState).forEach(id => {
          s.artworkState[id].seenInPerson = null;
        });
      });
      // Trigger re-route
      window.location.hash = '#walkthrough';
      window.location.reload();
    }
  });

  const pairBtn = document.getElementById('pair-btn');
  if (pairBtn) {
    pairBtn.addEventListener('click', () => {
      const code = prompt('Paste Brandon\'s code here:');
      const name = prompt('What is their name?', 'Brandon');
      if (code && name) {
        localStorage.setItem('accession:partnerUserId', code.trim());
        updateState({ partnerName: name.trim() });
        renderProfile();
      }
    });
  }

  document.getElementById('reset-btn').addEventListener('click', () => {
    if (confirm('Reset everything? This cannot be undone.')) {
      resetState();
      window.location.reload();
    }
  });

  // Backup
  document.getElementById('backup-btn').addEventListener('click', () => {
    try {
      downloadBackup();
    } catch (err) {
      alert('Could not save backup: ' + (err.message || err));
    }
  });

  // Restore — trigger the hidden file input
  const restoreBtn = document.getElementById('restore-btn');
  const fileInput = document.getElementById('restore-file-input');
  restoreBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (!confirm('Restoring will replace all current progress with the contents of this backup. Continue?')) {
      fileInput.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const payload = JSON.parse(reader.result);
        const result = importState(payload);
        if (result.ok) {
          alert('Backup restored.');
          window.location.reload();
        } else {
          alert('Could not restore: ' + result.error);
        }
      } catch (err) {
        alert('That file isn\'t a valid JSON backup.');
      }
      fileInput.value = '';
    };
    reader.onerror = () => {
      alert('Could not read the file.');
      fileInput.value = '';
    };
    reader.readAsText(file);
  });
}

function renderRankRow(region) {
  const rank = getCuratorRank(region.id);
  const pct = (rank / 4) * 100;
  return `
    <div class="rank-row">
      <div class="rank-row__name">
        <div class="rank-row__movement" style="color: ${region.color || 'var(--color-ink)'}">${region.name}</div>
        <div class="rank-row__rank">${RANK_NAMES[rank]}</div>
      </div>
      <div class="rank-row__progress">
        <div class="rank-row__progress-fill" style="width: ${pct}%; background: ${region.color || 'var(--color-burgundy)'}"></div>
      </div>
    </div>
  `;
}
