/* ============================================================
   ACCESSION - VERSUS VIEW
   Head-to-head challenge mode vs Brandon.
   Draws questions dynamically from all available artworks.
   Syncs scores to Firebase in real time.
   ============================================================ */

import { getAllArtworks, getArtwork, getRegions, getEras } from '../core/content.js';
import { getArtworkMastery, getRegionMastery, getCollectionStats } from '../core/progression.js';
import { getState, updateState } from '../core/state.js';
import { subscribeToPartner, sendChallenge, syncStatus, postChallengeScore, subscribeToChallengeScores } from '../core/sync.js';
import { buildPlacard } from '../core/placard.js';
import { startLesson } from '../app.js';

// ── State ────────────────────────────────────────────────────────────────────
let vsMode = 'lobby';          // 'lobby' | 'challenge' | 'results'
let currentChallenge = null;   // { questions, answers, score, partnerScore, roundId }
let partnerData = null;        // live partner stats from Firebase
let unsubScores = null;        // unsubscribe fn for score listener

// ── Helpers ──────────────────────────────────────────────────────────────────

function getCompletedLessons() {
  const s = getState();
  const set = new Set();
  for (const movId in s.movementProgress || {}) {
    for (const lid of s.movementProgress[movId].lessonsCompleted || []) set.add(lid);
  }
  return set;
}

function myStats() {
  const s = getState();
  const arts = getAllArtworks();
  const encountered = arts.filter(a => s.artworkState?.[a.id]?.encountered).length;
  const mastered = arts.filter(a => (s.artworkState?.[a.id]?.masteredCount || 0) >= 2).length;
  const lessons = getCompletedLessons().size;
  return { encountered, mastered, lessons, streak: s.streakDays || 0 };
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ── Challenge generation ─────────────────────────────────────────────────────

function generateChallenge(count = 5) {
  const s = getState();
  const arts = getAllArtworks();
  const regions = getRegions();
  const eras = getEras();

  // Only use artworks the user has encountered
  const pool = arts.filter(a => s.artworkState?.[a.id]?.encountered);
  if (pool.length < 4) return null;

  const questions = [];
  const used = new Set();

  const types = ['region', 'date', 'before-after'];

  while (questions.length < count && pool.length - used.size >= 4) {
    const remaining = pool.filter(a => !used.has(a.id));
    const art = remaining[Math.floor(Math.random() * remaining.length)];
    if (!art) break;
    used.add(art.id);

    const type = types[Math.floor(Math.random() * types.length)];

    if (type === 'region' && art.regionId) {
      const allRegions = regions.map(r => r.id);
      const distractors = shuffle(allRegions.filter(r => r !== art.regionId)).slice(0, 3);
      if (distractors.length < 3) continue;
      const opts = shuffle([art.regionId, ...distractors]);
      questions.push({
        type: 'region',
        artworkId: art.id,
        question: 'Where in the world was this made?',
        options: opts.map(id => ({ id, label: regions.find(r => r.id === id)?.name || id })),
        correctId: art.regionId,
      });
    } else if (type === 'date' && art.year != null) {
      // Multiple-choice date: 4 options with the correct year and 3 plausible wrong ones
      const y = art.year;
      const deltas = shuffle([150, 400, 800, 1500, 2000].filter(d => {
        const wrong = y + (Math.random() > 0.5 ? d : -d);
        return wrong !== y;
      })).slice(0, 3);
      const wrongs = deltas.map(d => y + (Math.random() > 0.5 ? d : -d));
      const opts = shuffle([y, ...wrongs]);
      questions.push({
        type: 'date',
        artworkId: art.id,
        question: 'Approximately when was this made?',
        options: opts.map(y2 => ({ id: String(y2), label: y2 < 0 ? `${Math.abs(y2)} BCE` : `${y2} CE` })),
        correctId: String(y),
      });
    } else if (type === 'before-after') {
      // Pick a second artwork to compare
      const others = remaining.filter(a => a.id !== art.id && a.year != null && art.year != null);
      if (others.length === 0) continue;
      const other = others[Math.floor(Math.random() * others.length)];
      used.add(other.id);
      const earlier = art.year <= other.year ? art : other;
      const later = art.year <= other.year ? other : art;
      questions.push({
        type: 'before-after',
        artworkId: earlier.id,
        artworkId2: later.id,
        question: 'Which came first?',
        options: [
          { id: earlier.id, label: earlier.title },
          { id: later.id, label: later.title },
        ],
        correctId: earlier.id,
      });
    }
  }

  return questions.length > 0 ? questions : null;
}

// ── Render ───────────────────────────────────────────────────────────────────

export function renderVersus() {
  if (vsMode === 'challenge' && currentChallenge) {
    renderChallengeActive();
  } else if (vsMode === 'results' && currentChallenge) {
    renderChallengeResults();
  } else {
    renderLobby();
  }
}

function renderLobby() {
  const app = document.getElementById('app');
  const state = getState();
  const me = myStats();
  const partner = partnerData;
  const synced = syncStatus();
  const pool = getAllArtworks().filter(a => state.artworkState?.[a.id]?.encountered);

  // Subscribe to partner data if paired
  if (state.partnerUserId && !partnerData) {
    subscribeToPartner(state.partnerUserId, data => {
      partnerData = data;
      if (vsMode === 'lobby') renderVersus();
    });
  }

  app.innerHTML = `
    <div class="view-versus">
      <div class="view-header">
        <div class="view-header__title" style="font-family:var(--font-display);font-size:var(--type-display-l)">Head to Head</div>
        <div class="view-header__sub" style="color:var(--color-sepia);font-family:var(--font-serif);font-style:italic;font-size:var(--type-body-m);margin-top:4px">Challenge ${state.partnerName || 'Brandon'} to a quiz duel</div>
      </div>

      <!-- Scoreboard -->
      <div class="vs-scoreboard">
        <div class="vs-player vs-player--me">
          <div class="vs-player__name">You</div>
          <div class="vs-player__stat vs-player__stat--big">${me.lessons}</div>
          <div class="vs-player__label">lessons done</div>
          <div class="vs-player__row">
            <span>${me.encountered} artworks seen</span>
            <span>${me.mastered} mastered</span>
          </div>
          <div class="vs-streak">${me.streak}-day streak</div>
        </div>

        <div class="vs-divider">VS</div>

        <div class="vs-player vs-player--partner">
          <div class="vs-player__name">${state.partnerName || 'Brandon'}</div>
          ${partner ? `
            <div class="vs-player__stat vs-player__stat--big">${partner.lessonsCompleted || 0}</div>
            <div class="vs-player__label">lessons done</div>
            <div class="vs-player__row">
              <span>${partner.artworksEncountered || 0} seen</span>
              <span>${partner.artworksMastered || 0} mastered</span>
            </div>
            <div class="vs-streak">${partner.streakDays || 0}-day streak</div>
          ` : `
            <div class="vs-player__stat vs-player__stat--big" style="opacity:0.3">—</div>
            <div class="vs-player__label">${synced ? 'No data yet' : 'Not connected'}</div>
          `}
        </div>
      </div>

      <!-- Lead indicator -->
      ${partner ? (() => {
        const myL = me.lessons, pL = partner.lessonsCompleted || 0;
        const diff = myL - pL;
        if (diff > 0) return `<div class="vs-lead vs-lead--winning">You're ahead by ${diff} lesson${diff !== 1 ? 's' : ''}</div>`;
        if (diff < 0) return `<div class="vs-lead vs-lead--losing">${state.partnerName || 'Brandon'} is ahead by ${Math.abs(diff)} lesson${Math.abs(diff) !== 1 ? 's' : ''} — catch up!</div>`;
        return `<div class="vs-lead vs-lead--tied">Dead even.</div>`;
      })() : ''}

      <!-- Challenge button -->
      <div class="vs-actions">
        ${pool.length >= 4 ? `
          <button class="btn btn--primary btn--full btn--lg" id="start-challenge-btn">
            Start Challenge — 5 questions
          </button>
          <div class="vs-hint">Questions drawn from artworks you've already studied</div>
        ` : `
          <div class="vs-empty">Complete more lessons to unlock challenges.<br>You need at least 4 artworks encountered.</div>
          <button class="btn btn--secondary btn--full" id="go-learn-btn">Go to Learn →</button>
        `}
      </div>

      <!-- Past challenge history -->
      ${renderChallengeHistory()}

      <!-- Sync status -->
      <div class="vs-sync-status">${synced ? 'Live — synced with ' + (state.partnerName || 'Brandon') : 'Offline — pair via Profile to sync'}</div>
    </div>
  `;

  document.getElementById('start-challenge-btn')?.addEventListener('click', () => {
    const qs = generateChallenge(5);
    if (!qs) return;
    // Generate a shared round ID — same seed means same questions for both players
    // Use timestamp bucketed to 24h so replays feel fresh each day
    const roundId = `round-${Math.floor(Date.now() / (1000 * 60 * 60 * 24))}-${Math.random().toString(36).slice(2, 8)}`;
    currentChallenge = { questions: qs, answers: [], score: 0, roundId, startedAt: Date.now() };
    vsMode = 'challenge';
    renderVersus();
  });

  document.getElementById('go-learn-btn')?.addEventListener('click', () => {
    import('../app.js').then(m => m.navigate('learn'));
  });
}

function renderChallengeHistory() {
  try {
    const raw = localStorage.getItem('accession:challengeHistory');
    if (!raw) return '';
    const history = JSON.parse(raw).slice(-5).reverse();
    if (!history.length) return '';
    return `
      <div class="vs-history">
        <div class="vs-history__title">Recent Challenges</div>
        ${history.map(h => `
          <div class="vs-history__item">
            <span>${h.score}/${h.total} correct</span>
            <span style="color:var(--color-sepia);font-size:var(--type-body-s)">${new Date(h.at).toLocaleDateString()}</span>
          </div>
        `).join('')}
      </div>
    `;
  } catch(e) { return ''; }
}

// ── Active challenge ──────────────────────────────────────────────────────────

function renderChallengeActive() {
  const app = document.getElementById('app');
  const ch = currentChallenge;
  const qIdx = ch.answers.length;

  if (qIdx >= ch.questions.length) {
    vsMode = 'results';
    // Save to history
    try {
      const raw = localStorage.getItem('accession:challengeHistory') || '[]';
      const history = JSON.parse(raw);
      history.push({ score: ch.score, total: ch.questions.length, at: Date.now() });
      localStorage.setItem('accession:challengeHistory', JSON.stringify(history.slice(-20)));
    } catch(e) {}
    renderVersus();
    return;
  }

  const q = ch.questions[qIdx];
  const art = getArtwork(q.artworkId);
  const art2 = q.artworkId2 ? getArtwork(q.artworkId2) : null;

  app.innerHTML = `
    <div class="view-versus view-versus--challenge">
      <div class="challenge-header">
        <div class="challenge-progress">${qIdx + 1} / ${ch.questions.length}</div>
        <div class="challenge-score">Score: ${ch.score}</div>
      </div>
      <div class="challenge-progress-bar">
        <div class="challenge-progress-fill" style="width:${(qIdx / ch.questions.length) * 100}%"></div>
      </div>

      <div class="challenge-question">${q.question}</div>

      ${q.type === 'before-after' ? `
        <div class="challenge-two-images">
          <img referrerpolicy="no-referrer" class="challenge-img challenge-img--half" src="${art?.image || buildPlacard(art)}"
               data-placard="${buildPlacard(art)}"
               onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
               alt="" />
          <img referrerpolicy="no-referrer" class="challenge-img challenge-img--half" src="${art2?.image || buildPlacard(art2)}"
               data-placard="${buildPlacard(art2)}"
               onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
               alt="" />
        </div>
      ` : `
        <img referrerpolicy="no-referrer" class="challenge-img" src="${art?.image || buildPlacard(art)}"
             data-placard="${buildPlacard(art)}"
             onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
             data-met-id="${art?.metObjectId || ''}" alt="" />
      `}

      <div class="challenge-options" id="challenge-options">
        ${q.options.map(opt => `
          <button class="challenge-option" data-id="${opt.id}">${opt.label}</button>
        `).join('')}
      </div>
      <div id="challenge-feedback" class="challenge-feedback"></div>
    </div>
  `;

  document.querySelectorAll('.challenge-option').forEach(btn => {
    btn.addEventListener('click', () => handleAnswer(btn.dataset.id, q));
  });
}

function handleAnswer(chosen, q) {
  const correct = chosen === q.correctId;
  if (correct) currentChallenge.score++;
  currentChallenge.answers.push({ chosen, correct });

  // Disable all buttons and highlight
  document.querySelectorAll('.challenge-option').forEach(btn => {
    btn.disabled = true;
    if (btn.dataset.id === q.correctId) btn.classList.add('is-correct');
    else if (btn.dataset.id === chosen) btn.classList.add('is-incorrect');
  });

  const fb = document.getElementById('challenge-feedback');
  if (fb) {
    fb.textContent = correct ? ' Correct!' : ' Not quite';
    fb.className = 'challenge-feedback ' + (correct ? 'is-correct' : 'is-incorrect');
  }

  setTimeout(() => renderChallengeActive(), 1200);
}

// ── Results ───────────────────────────────────────────────────────────────────

function renderChallengeResults() {
  const app = document.getElementById('app');
  const ch = currentChallenge;
  const state = getState();
  const pct = Math.round((ch.score / ch.questions.length) * 100);
  const medals = pct === 100 ? 'Perfect' : pct >= 80 ? 'Excellent' : pct >= 60 ? 'Good effort' : 'Keep studying';
  const partnerName = state.partnerName || 'Brandon';

  // Post our score to Firebase immediately
  if (ch.roundId) {
    postChallengeScore(ch.roundId, ch.score, ch.questions.length);
  }

  function drawResults(scores) {
    const myId = state.userId;
    // Find partner score — any entry that isn't us
    const partnerEntry = Object.entries(scores).find(([id]) => id !== myId);
    const partnerScore = partnerEntry ? partnerEntry[1] : null;

    const breakdown = ch.questions.map((q, i) => {
      const art = getArtwork(q.artworkId);
      const ans = ch.answers[i];
      return `
        <div class="results-item ${ans?.correct ? 'is-correct' : 'is-incorrect'}">
          <img referrerpolicy="no-referrer" class="results-thumb" src="${art?.image || buildPlacard(art)}"
               data-placard="${buildPlacard(art)}"
               onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
               alt="" />
          <div class="results-item__body">
            <div class="results-item__title">${art?.title || q.artworkId}</div>
            <div class="results-item__verdict">${ans?.correct ? '✓ Correct' : '✗ Wrong'}</div>
          </div>
        </div>
      `;
    }).join('');

    let headToHead = '';
    if (partnerScore) {
      const diff = ch.score - partnerScore.score;
      const outcome = diff > 0 ? `You won by ${diff} point${diff !== 1 ? 's' : ''} 🏆`
                    : diff < 0 ? `${partnerName} won by ${Math.abs(diff)} point${Math.abs(diff) !== 1 ? 's' : ''}`
                    : 'It\'s a tie!';
      headToHead = `
        <div class="results-h2h">
          <div class="results-h2h__row">
            <div class="results-h2h__player">
              <div class="results-h2h__name">You</div>
              <div class="results-h2h__score">${ch.score}/${ch.questions.length}</div>
            </div>
            <div class="results-h2h__vs">VS</div>
            <div class="results-h2h__player">
              <div class="results-h2h__name">${partnerName}</div>
              <div class="results-h2h__score">${partnerScore.score}/${partnerScore.total}</div>
            </div>
          </div>
          <div class="results-h2h__outcome ${diff > 0 ? 'is-win' : diff < 0 ? 'is-loss' : 'is-tie'}">${outcome}</div>
        </div>
      `;
    } else {
      headToHead = `
        <div class="results-h2h results-h2h--waiting">
          <div class="results-h2h__row">
            <div class="results-h2h__player">
              <div class="results-h2h__name">You</div>
              <div class="results-h2h__score">${ch.score}/${ch.questions.length}</div>
            </div>
            <div class="results-h2h__vs">VS</div>
            <div class="results-h2h__player">
              <div class="results-h2h__name">${partnerName}</div>
              <div class="results-h2h__score results-h2h__score--waiting">—</div>
            </div>
          </div>
          <div class="results-h2h__hint">Score posted — updates live when ${partnerName} plays</div>
        </div>
      `;
    }

    app.innerHTML = `
      <div class="view-versus view-versus--results">
        <div class="results-header">
          <div class="results-medal">${medals}</div>
          <div class="results-score">${ch.score} / ${ch.questions.length}</div>
          <div class="results-pct">${pct}% correct</div>
        </div>
        ${headToHead}
        <div class="results-breakdown">${breakdown}</div>
        <div class="results-actions">
          <button class="btn btn--primary btn--full btn--lg" id="new-challenge-btn">Play Again</button>
          <button class="btn btn--secondary btn--full" id="back-lobby-btn">Back to Lobby</button>
        </div>
      </div>
    `;

    document.getElementById('new-challenge-btn')?.addEventListener('click', () => {
      if (unsubScores) { unsubScores(); unsubScores = null; }
      const qs = generateChallenge(5);
      if (qs) {
        const roundId = `round-${Math.random().toString(36).slice(2, 10)}`;
        currentChallenge = { questions: qs, answers: [], score: 0, roundId, startedAt: Date.now() };
        vsMode = 'challenge';
      }
      renderVersus();
    });

    document.getElementById('back-lobby-btn')?.addEventListener('click', () => {
      if (unsubScores) { unsubScores(); unsubScores = null; }
      vsMode = 'lobby';
      currentChallenge = null;
      renderVersus();
    });
  }

  // Initial render with just our score
  drawResults({});

  // Subscribe to live scores — re-renders when partner posts theirs
  if (ch.roundId) {
    if (unsubScores) unsubScores();
    unsubScores = subscribeToChallengeScores(ch.roundId, scores => {
      if (vsMode === 'results') drawResults(scores);
    });
  }
}
