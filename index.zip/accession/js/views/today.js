/* ============================================================
   ACCESSION - TODAY VIEW (global thesis)
   The daily hub. Streak, card of the day, next lesson, leaderboard.
   ============================================================ */

import { getState, getDueReviewCount, getCurrentStreak } from '../core/state.js';
import { getAllArtworks, getArtwork, getArtist, getRegion, getEra, getLesson } from '../core/content.js';
import { getNextLesson, getCollectionStats } from '../core/progression.js';
import { subscribeToPartner } from '../core/sync.js';
import { navigate, startLesson, startReview } from '../app.js';
import { buildPlacard } from '../core/placard.js';
import { hasCompletedToday, getTodayNumber, getCurrentDailyStreak, getTodaysResult } from '../core/daily.js';

export function renderToday() {
  const app = document.getElementById('app');
  const state = getState();

  // New API: getNextLesson() returns { lessonId } or null
  const nextRef = getNextLesson();
  const nextLesson = nextRef ? getLesson(nextRef.lessonId) : null;
  const reviewCount = getDueReviewCount();

  const cardOfTheDay = pickCardOfTheDay();
  const stats = getCollectionStats();
  const streak = getCurrentStreak();
  const dailyDone = hasCompletedToday();
  const dailyResult = getTodaysResult();
  const dailyNum = getTodayNumber();
  const dailyStreak = getCurrentDailyStreak();

  app.innerHTML = `
    <div class="view">
      <h2 class="today-greeting">Good ${timeOfDayGreeting()}${state.displayName ? ', ' + state.displayName : ''}.</h2>
      <div class="today-date">${formatDate()}</div>

      <!-- DAILY CHALLENGE -->
      <section class="today-section today-section--daily">
        <div class="card daily-card ${dailyDone ? 'daily-card--done' : 'daily-card--ready'}" id="daily-card">
          <div class="daily-card__header">
            <div class="daily-card__label">Daily Challenge</div>
            <div class="daily-card__number">#${dailyNum}</div>
          </div>
          ${dailyDone && dailyResult ? `
            <div class="daily-card__done">
              <div class="daily-card__squares">${dailyResult.pattern.map(p => p ? '🟩' : '⬛').join('')}</div>
              <div class="daily-card__score">${dailyResult.score}/${dailyResult.total}${dailyResult.score === dailyResult.total ? ' ⭐' : ''}</div>
            </div>
            <div class="daily-card__cta">Tap to view & share · 🔥 ${dailyStreak}-day streak</div>
          ` : `
            <div class="daily-card__pitch">5 questions. Same for everyone. One shot.</div>
            <div class="daily-card__cta">
              ${dailyStreak > 0 ? `🔥 ${dailyStreak}-day streak — don't break it` : 'Begin →'}
            </div>
          `}
        </div>
      </section>

      <!-- STREAK -->
      <section class="today-section">
        <div class="card">
          <div class="streak-row">
            <div class="wax-seal ${streak > 0 ? 'wax-seal--with-ring' : ''}">
              <span class="wax-seal__number">${streak}</span>
            </div>
            <div class="streak-row__copy">
              <div class="streak-row__count">${streak} day${streak === 1 ? '' : 's'}</div>
              <div class="streak-row__caption">${streakCaption(streak)}</div>
            </div>
          </div>
        </div>
      </section>

      <!-- CARD OF THE DAY -->
      ${cardOfTheDay ? renderCardOfTheDay(cardOfTheDay) : ''}

      <!-- REVISIT (SRS review) -->
      ${reviewCount > 0 ? `
        <section class="today-section">
          <h3 class="today-section__title"><span>Revisit</span></h3>
          <div class="card" id="review-card" style="cursor: pointer;">
            <div class="eyebrow" style="margin-bottom: var(--space-1);">Spaced repetition</div>
            <h3 style="margin-bottom: var(--space-1);">${reviewCount} work${reviewCount === 1 ? '' : 's'} to revisit</h3>
            <p style="font-size: var(--type-body-m); margin-bottom: var(--space-4); color: var(--color-sepia);">
              These are due for review. A short session keeps them fresh.
            </p>
            <button class="btn btn--secondary btn--full" id="start-review-btn">Begin review</button>
          </div>
        </section>
      ` : ''}

      <!-- CONTINUE PATH -->
      ${nextLesson ? renderNextLesson(nextLesson) : `
        <section class="today-section">
          <div class="card"><p>You have completed every lesson available. New paths coming soon.</p></div>
        </section>
      `}

      <!-- LEADERBOARD -->
      <section class="today-section">
        <h3 class="today-section__title">
          <span>Wing rivalry</span>
          <span style="font-size:9px;color:var(--color-sepia-light)" id="sync-indicator">offline</span>
        </h3>
        <div class="card">
          <div id="leaderboard-rows">
            ${renderLeaderboardRow({
              name: state.displayName || 'You',
              streak: streak,
              mastered: stats.mastered,
              isYou: true,
            })}
            ${renderLeaderboardRow({
              name: state.partnerName || 'Brandon',
              streak: 0,
              mastered: 0,
              isYou: false,
              loading: true,
            })}
          </div>
        </div>
      </section>

      <!-- HEAD TO HEAD -->
      <section class="today-section">
        <h3 class="today-section__title"><span>Head to Head</span></h3>
        <div class="card" id="versus-card" style="cursor:pointer;">
          <div class="eyebrow" style="margin-bottom:var(--space-2);">Challenge ${state.partnerName || 'Brandon'}</div>
          <p style="font-size:var(--type-body-s);color:var(--color-sepia);margin-bottom:var(--space-4);">
            5 questions drawn from artworks you've studied. First to answer wins the round.
          </p>
          <button class="btn btn--secondary btn--full">Open Head to Head</button>
        </div>
      </section>
    </div>
  `;

  // Daily challenge card click
  const dailyCard = document.getElementById('daily-card');
  if (dailyCard) dailyCard.addEventListener('click', () => navigate('daily'));

  // Card of the Day click — show longForm
  const cotd = document.getElementById('cotd-card');
  if (cotd) cotd.addEventListener('click', () => {
    const id = cotd.dataset.artworkId;
    const art = getArtwork(id);
    if (art) alert(art.longForm || art.wallLabel);
  });

  // Review button
  const reviewBtn = document.getElementById('start-review-btn');
  if (reviewBtn) reviewBtn.addEventListener('click', () => startReview());

  // Next lesson button
  const nextBtn = document.getElementById('start-next-lesson');
  if (nextBtn && nextLesson) {
    nextBtn.addEventListener('click', () => startLesson(nextLesson.id));
  }

  // Versus card
  const versusCard = document.getElementById('versus-card');
  if (versusCard) versusCard.addEventListener('click', () => navigate('versus'));

  // Partner sync
  subscribeToPartner(localStorage.getItem('accession:partnerUserId'), partnerData => {
    if (!partnerData) return;
    const rows = document.getElementById('leaderboard-rows');
    if (!rows) return;
    rows.innerHTML = `
      ${renderLeaderboardRow({
        name: state.displayName || 'You',
        streak: streak,
        mastered: stats.mastered,
        isYou: true,
      })}
      ${renderLeaderboardRow({
        name: partnerData.displayName || 'Brandon',
        streak: partnerData.streakDays || 0,
        mastered: partnerData.mastered || 0,
        isYou: false,
      })}
    `;
    const ind = document.getElementById('sync-indicator');
    if (ind) {
      ind.textContent = 'live';
      ind.style.color = 'var(--color-sage)';
    }
  });
}

function renderCardOfTheDay(art) {
  const artist = art.artistId ? getArtist(art.artistId) : null;
  const region = getRegion(art.regionId);
  const era = getEra(art.eraId);
  // Eyebrow shows region + era, the new model's primary axes
  const eyebrow = [region?.name, era?.name].filter(Boolean).join(' · ');
  return `
    <section class="today-section">
      <h3 class="today-section__title"><span>Card of the day</span></h3>
      <div class="hero-panel" id="cotd-card" data-artwork-id="${art.id}" style="cursor: pointer;">
        <img referrerpolicy="no-referrer" class="hero-panel__image" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="${art.title}" />
        <div class="hero-panel__body">
          <div class="lesson-card-meta" style="margin-bottom: var(--space-1);">${eyebrow}</div>
          <div class="lesson-card-title" style="margin-bottom: var(--space-1);">${art.title}</div>
          <div class="lesson-card-meta">${artist ? artist.name + ', ' : ''}${formatYear(art.year)}</div>
        </div>
      </div>
    </section>
  `;
}

function renderNextLesson(lesson) {
  // Lesson may be tagged with eraId (new model) or movementId (legacy).
  // We just show the lesson title + subtitle; the eyebrow is "Lesson".
  return `
    <section class="today-section">
      <h3 class="today-section__title"><span>Continue your path</span></h3>
      <div class="card card--accent">
        <div class="eyebrow" style="margin-bottom: var(--space-1);">${lesson.isSampler ? 'Sampler' : 'Lesson'}</div>
        <h3 style="margin-bottom: var(--space-1);">${lesson.title}</h3>
        <p style="font-size: var(--type-body-m); margin-bottom: var(--space-4); color: var(--color-sepia);">
          ${lesson.subtitle || ''} · ${lesson.estimatedMinutes || 5} min
        </p>
        <button class="btn btn--primary btn--full" id="start-next-lesson">Begin ${lesson.isSampler ? 'sampler' : 'lesson'}</button>
      </div>
    </section>
  `;
}

function renderLeaderboardRow({ name, streak, mastered, isYou, loading }) {
  if (loading) {
    return `
      <div class="leaderboard-row" style="opacity: 0.5;">
        <div class="leaderboard-row__avatar">B</div>
        <div class="leaderboard-row__name">${name}</div>
        <div><div class="leaderboard-row__substat">connecting…</div></div>
      </div>
    `;
  }
  const initial = (name || '?').charAt(0).toUpperCase();
  return `
    <div class="leaderboard-row">
      <div class="leaderboard-row__avatar">${initial}</div>
      <div class="leaderboard-row__name">${name}${isYou ? ' <span class="leaderboard-row__substat">you</span>' : ''}</div>
      <div style="text-align: right;">
        <div class="leaderboard-row__stat">${streak}</div>
        <div class="leaderboard-row__substat">day streak</div>
      </div>
    </div>
  `;
}

function pickCardOfTheDay() {
  const artworks = getAllArtworks();
  if (artworks.length === 0) return null;
  const today = new Date();
  const dayKey = today.getFullYear() * 1000 + dayOfYear(today);
  return artworks[dayKey % artworks.length];
}

function dayOfYear(d) {
  const start = new Date(d.getFullYear(), 0, 0);
  return Math.floor((d - start) / (1000 * 60 * 60 * 24));
}

function timeOfDayGreeting() {
  const h = new Date().getHours();
  if (h < 5) return 'evening';
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
}

function formatDate() {
  return new Date().toLocaleDateString('en-US', {
    weekday: 'long', month: 'long', day: 'numeric',
  });
}

function streakCaption(days) {
  if (days === 0) return 'Begin a streak today.';
  if (days < 3) return 'A quiet start.';
  if (days < 7) return 'Building momentum.';
  if (days < 30) return 'A real practice now.';
  return 'A serious accession.';
}

function formatYear(year) {
  if (!year && year !== 0) return '';
  if (year < 0) return `${Math.abs(year)} BCE`;
  return String(year);
}
