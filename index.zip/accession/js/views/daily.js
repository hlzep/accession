/* ============================================================
   ACCESSION - DAILY CHALLENGE VIEW
   Wordle-style 5-question daily, same questions for everyone.
   One shot per day. Streak + shareable result text.
   ============================================================ */

import {
  getDailyQuestions, getTodayNumber, getTodayDateString,
  hasCompletedToday, getTodaysResult, recordDailyCompletion,
  getCurrentDailyStreak, getDailyState, generateShareText,
} from '../core/daily.js';
import { getArtwork } from '../core/content.js';
import { buildPlacard } from '../core/placard.js';

// Local year formatter (matches engine.js private helper)
function formatYear(year) {
  if (year === undefined || year === null) return '';
  if (year < 0) return `${Math.abs(year)} BCE`;
  return `${year}`;
}

let questions = [];
let currentIndex = 0;
let pattern = [];  // 1/0 per question

// ── Entry point ─────────────────────────────────────────────────────────────

export function renderDaily() {
  const app = document.getElementById('app');

  if (hasCompletedToday()) {
    renderAlreadyDone();
    return;
  }

  questions = getDailyQuestions();
  currentIndex = 0;
  pattern = [];

  if (questions.length === 0) {
    app.innerHTML = `
      <div class="view">
        <button class="btn btn--ghost" id="back-btn">← Back</button>
        <h2 class="today-greeting">No daily today</h2>
        <p class="daily-empty">Check back tomorrow.</p>
      </div>
    `;
    document.getElementById('back-btn').addEventListener('click', () =>
      window.__accessionNav && window.__accessionNav('today'));
    return;
  }

  renderIntro();
}

// ── Intro screen ────────────────────────────────────────────────────────────

function renderIntro() {
  const app = document.getElementById('app');
  const dayNum = getTodayNumber();
  const streak = getCurrentDailyStreak();
  const state = getDailyState();

  app.innerHTML = `
    <div class="view view--daily">
      <button class="btn btn--ghost daily-back" id="back-btn">← Back to Today</button>

      <div class="daily-intro">
        <div class="daily-intro__label">Today's Daily Challenge</div>
        <div class="daily-intro__number">Accession #${dayNum}</div>
        <div class="daily-intro__subtitle">Five questions. One shot. Same for everyone.</div>

        <div class="daily-intro__stats">
          <div class="daily-stat">
            <div class="daily-stat__value">${streak}</div>
            <div class="daily-stat__label">day streak</div>
          </div>
          <div class="daily-stat">
            <div class="daily-stat__value">${state.totalCompleted || 0}</div>
            <div class="daily-stat__label">total completed</div>
          </div>
          <div class="daily-stat">
            <div class="daily-stat__value">${(state.perfectDates || []).length}</div>
            <div class="daily-stat__label">perfect ⭐</div>
          </div>
        </div>

        <button class="btn btn--primary btn--full btn--lg" id="start-daily-btn">Begin</button>
        <div class="daily-intro__hint">No retries — your first answers count.</div>
      </div>
    </div>
  `;

  document.getElementById('back-btn').addEventListener('click', () =>
    window.__accessionNav && window.__accessionNav('today'));
  document.getElementById('start-daily-btn').addEventListener('click', () => {
    renderCurrentQuestion();
  });
}

// ── Per-question rendering ──────────────────────────────────────────────────

function renderCurrentQuestion() {
  const app = document.getElementById('app');
  const card = questions[currentIndex];
  const dayNum = getTodayNumber();

  app.innerHTML = `
    <div class="view view--daily">
      <div class="daily-header">
        <div class="daily-header__label">Accession #${dayNum}</div>
        <div class="daily-progress">
          ${pattern.map(p => `<span class="daily-progress__sq ${p ? 'is-correct' : 'is-wrong'}"></span>`).join('')}
          <span class="daily-progress__sq is-current"></span>
          ${Array.from({length: questions.length - currentIndex - 1})
            .map(() => `<span class="daily-progress__sq"></span>`).join('')}
        </div>
        <div class="daily-header__count">${currentIndex + 1} / ${questions.length}</div>
      </div>

      <div class="lesson-card-body" id="daily-card-body"></div>
      <div class="lesson-card-footer" id="daily-card-footer"></div>
    </div>
  `;

  const body = document.getElementById('daily-card-body');
  const footer = document.getElementById('daily-card-footer');

  // Dispatch to the right renderer based on card type
  if (card.type === 'quiz-detail') renderDetail(card, body, footer);
  else if (card.type === 'quiz-timeline') renderTimeline(card, body, footer);
  else if (card.type === 'quiz-technique') renderTechnique(card, body, footer);
  else if (card.type === 'quiz-compare') renderCompare(card, body, footer);
  else recordAndAdvance(false); // unsupported — skip
}

// ── Question type renderers (lightweight, daily-specific) ───────────────────

function shuffle(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function renderDetail(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) return recordAndAdvance(false);
  const all = shuffle([card.artworkId, ...(card.distractorIds || [])]);
  const options = all.map(getArtwork).filter(Boolean);
  const crop = card.cropPercent || { x: 30, y: 20, w: 35, h: 35 };

  body.innerHTML = `
    <div class="detail-challenge">
      <div class="detail-challenge__hint">Which artwork is this detail from?</div>
      <div class="detail-challenge__crop">
        <img referrerpolicy="no-referrer" src="${art.image || buildPlacard(art)}"
             data-placard="${buildPlacard(art)}"
             onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
             style="object-fit:cover;object-position:${crop.x}% ${crop.y}%;width:100%;height:100%;display:block;"
             alt="" />
      </div>
      <div class="detail-challenge__options">
        ${options.map(o => `
          <button class="detail-option" data-id="${o.id}">
            <img referrerpolicy="no-referrer" src="${o.image || buildPlacard(o)}"
                 data-placard="${buildPlacard(o)}"
                 onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
                 alt="${o.title}" />
            <span class="detail-option__title">${o.title.length > 32 ? o.title.slice(0,32)+'…' : o.title}</span>
          </button>
        `).join('')}
      </div>
      <div id="daily-feedback"></div>
    </div>
  `;

  body.querySelectorAll('.detail-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const correct = btn.dataset.id === card.artworkId;
      body.querySelectorAll('.detail-option').forEach(b => {
        b.disabled = true;
        if (b.dataset.id === card.artworkId) b.classList.add('is-correct');
        else if (b === btn) b.classList.add('is-incorrect');
        else b.classList.add('is-disabled');
      });
      const fb = document.getElementById('daily-feedback');
      fb.className = 'lesson-feedback' + (correct ? '' : ' is-incorrect');
      fb.innerHTML = correct
        ? `<strong>${art.title}</strong> (${formatYear(art.year)})`
        : `That's ${getArtwork(btn.dataset.id)?.title || ''}. The answer was <strong>${art.title}</strong>.`;
      showNextButton(footer, correct);
    });
  });
}

function renderTimeline(card, body, footer) {
  const artworks = (card.artworkIds || []).map(getArtwork).filter(Boolean);
  if (artworks.length < 2) return recordAndAdvance(false);
  const sorted = [...artworks].sort((a, b) => a.year - b.year);
  const shuffled = shuffle([...artworks]);
  let selected = [];
  let answered = false;

  function render() {
    body.innerHTML = `
      <div class="timeline-challenge">
        <div class="timeline-challenge__hint">Tap in chronological order — earliest first</div>
        <div class="timeline-challenge__queue">
          ${shuffled.filter(a => !selected.includes(a.id)).map(a => `
            <button class="tl-card ${answered ? 'is-disabled' : ''}" data-id="${a.id}">
              <img referrerpolicy="no-referrer" src="${a.image || buildPlacard(a)}"
                   data-placard="${buildPlacard(a)}"
                   onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
                   alt="${a.title}" />
              <span class="tl-card__title">${a.title.length > 28 ? a.title.slice(0,28)+'…' : a.title}</span>
            </button>
          `).join('')}
        </div>
        <div class="timeline-challenge__selected">
          ${selected.map(id => {
            const a = getArtwork(id);
            return `<div class="tl-slot tl-slot--filled">
              <img referrerpolicy="no-referrer" src="${a?.image || ''}" alt="${a?.title || ''}" />
              <span>${a?.title?.slice(0,20) || ''}</span>
            </div>`;
          }).join('')}
          ${Array.from({length: artworks.length - selected.length})
            .map(() => `<div class="tl-slot tl-slot--empty"></div>`).join('')}
        </div>
        <div id="daily-feedback" class="timeline-challenge__feedback"></div>
      </div>
    `;

    if (!answered) {
      body.querySelectorAll('.tl-card').forEach(btn => {
        btn.addEventListener('click', () => {
          selected.push(btn.dataset.id);
          if (selected.length === artworks.length) {
            answered = true;
            const correct = selected.every((id, i) => id === sorted[i].id);
            render();
            const fb = document.getElementById('daily-feedback');
            fb.className = 'timeline-challenge__feedback lesson-feedback' + (correct ? '' : ' is-incorrect');
            fb.innerHTML = correct
              ? `Correct order: ${sorted.map(a => `<strong>${a.title}</strong> (${formatYear(a.year)})`).join(' → ')}`
              : `Should have been: ${sorted.map(a => `<strong>${a.title}</strong> (${formatYear(a.year)})`).join(' → ')}`;
            showNextButton(footer, correct);
          } else {
            render();
          }
        });
      });
    }
  }
  render();
}

function renderTechnique(card, body, footer) {
  const art = getArtwork(card.artworkId);
  if (!art) return recordAndAdvance(false);
  const options = shuffle([card.correctTechnique, ...(card.distractorTechniques || [])]);
  const icons = {
    'Fresco': '🖌️', 'Tempera': '🥚', 'Oil on panel': '🪵', 'Oil on canvas': '🎨',
    'Lost-wax bronze': '🔥', 'Carved marble': '⛏️', 'Carved stone': '⛏️',
    'Mosaic': '🟦', 'Stained glass': '🪟', 'Woodblock print': '🌲',
    'Porcelain': '⚪', 'Terracotta': '🏺',
  };

  body.innerHTML = `
    <img referrerpolicy="no-referrer" class="lesson-card-image lesson-card-image--quiz"
         src="${art.image || buildPlacard(art)}"
         data-placard="${buildPlacard(art)}"
         onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
         alt="" />
    <div class="lesson-question">What technique was used to make this?</div>
    <div id="quiz-options">
      ${options.map(t => `
        <button class="quiz-option technique-option" data-id="${t}">
          <span class="technique-option__icon">${icons[t] || '🖼️'}</span>
          <span class="technique-option__label">${t}</span>
        </button>
      `).join('')}
    </div>
    <div id="daily-feedback"></div>
  `;

  body.querySelectorAll('.technique-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const correct = btn.dataset.id === card.correctTechnique;
      body.querySelectorAll('.technique-option').forEach(b => {
        b.disabled = true;
        if (b.dataset.id === card.correctTechnique) b.classList.add('is-correct');
        else if (b === btn) b.classList.add('is-incorrect');
        else b.classList.add('is-disabled');
      });
      const fb = document.getElementById('daily-feedback');
      fb.className = 'lesson-feedback' + (correct ? '' : ' is-incorrect');
      fb.innerHTML = correct
        ? card.explanation || `Correct — ${card.correctTechnique}.`
        : `It's ${card.correctTechnique}. ${card.explanation || ''}`;
      showNextButton(footer, correct);
    });
  });
}

function renderCompare(card, body, footer) {
  const [artA, artB] = (card.artworkIds || []).map(getArtwork).filter(Boolean);
  if (!artA || !artB) return recordAndAdvance(false);
  const options = shuffle(card.options || []);

  body.innerHTML = `
    <div class="compare-challenge">
      <div class="compare-challenge__hint">${card.question || 'What is the key difference?'}</div>
      <div class="compare-challenge__images">
        <div class="compare-item">
          <img referrerpolicy="no-referrer" src="${artA.image || buildPlacard(artA)}"
               data-placard="${buildPlacard(artA)}"
               onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
               alt="${artA.title}" />
          <span class="compare-item__label">${artA.title.length > 24 ? artA.title.slice(0,24)+'…' : artA.title}</span>
        </div>
        <div class="compare-challenge__vs">vs</div>
        <div class="compare-item">
          <img referrerpolicy="no-referrer" src="${artB.image || buildPlacard(artB)}"
               data-placard="${buildPlacard(artB)}"
               onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
               alt="${artB.title}" />
          <span class="compare-item__label">${artB.title.length > 24 ? artB.title.slice(0,24)+'…' : artB.title}</span>
        </div>
      </div>
      <div class="compare-challenge__options">
        ${options.map((o, i) => `
          <button class="quiz-option compare-option" data-idx="${i}">${o.text}</button>
        `).join('')}
      </div>
      <div id="daily-feedback"></div>
    </div>
  `;

  body.querySelectorAll('.compare-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.idx, 10);
      const chosen = options[idx];
      const correctOpt = options.find(o => o.correct);
      const correct = !!chosen.correct;
      body.querySelectorAll('.compare-option').forEach((b, i) => {
        b.disabled = true;
        if (options[i].correct) b.classList.add('is-correct');
        else if (i === idx && !correct) b.classList.add('is-incorrect');
      });
      const fb = document.getElementById('daily-feedback');
      fb.className = 'lesson-feedback' + (correct ? '' : ' is-incorrect');
      fb.innerHTML = chosen.explanation || correctOpt?.explanation || '';
      showNextButton(footer, correct);
    });
  });
}

// ── Next button & advance ───────────────────────────────────────────────────

function showNextButton(footer, wasCorrect) {
  const isLast = currentIndex === questions.length - 1;
  footer.innerHTML = `
    <button class="btn btn--primary btn--full btn--lg" id="daily-next-btn">
      ${isLast ? 'See Results' : 'Next Question'}
    </button>
  `;
  document.getElementById('daily-next-btn').addEventListener('click', () => {
    recordAndAdvance(wasCorrect);
  });
}

function recordAndAdvance(wasCorrect) {
  pattern.push(wasCorrect ? 1 : 0);
  currentIndex++;
  if (currentIndex >= questions.length) {
    renderResults();
  } else {
    renderCurrentQuestion();
  }
}

// ── Results screen ──────────────────────────────────────────────────────────

function renderResults() {
  recordDailyCompletion(pattern);
  renderAlreadyDone();
}

function renderAlreadyDone() {
  const app = document.getElementById('app');
  const result = getTodaysResult();
  const dayNum = getTodayNumber();
  const streak = getCurrentDailyStreak();
  const state = getDailyState();

  if (!result) {
    // Shouldn't happen but be safe
    app.innerHTML = `<div class="view"><p>Loading…</p></div>`;
    return;
  }

  const shareText = generateShareText(dayNum, result.pattern, result.score, result.total);
  const isPerfect = result.score === result.total;

  app.innerHTML = `
    <div class="view view--daily">
      <button class="btn btn--ghost daily-back" id="back-btn">← Back to Today</button>

      <div class="daily-results">
        <div class="daily-results__label">Accession #${dayNum}</div>
        <div class="daily-results__score">${result.score} / ${result.total}${isPerfect ? ' ⭐' : ''}</div>
        ${isPerfect
          ? `<div class="daily-results__perfect">Perfect score — added to your badges</div>`
          : `<div class="daily-results__caption">Come back tomorrow for #${dayNum + 1}.</div>`
        }

        <div class="daily-results__squares">
          ${result.pattern.map(p => p ? '🟩' : '⬛').join('')}
        </div>

        <div class="daily-results__stats">
          <div class="daily-stat">
            <div class="daily-stat__value">${streak}</div>
            <div class="daily-stat__label">day streak</div>
          </div>
          <div class="daily-stat">
            <div class="daily-stat__value">${state.totalCompleted || 0}</div>
            <div class="daily-stat__label">total</div>
          </div>
          <div class="daily-stat">
            <div class="daily-stat__value">${(state.perfectDates || []).length}</div>
            <div class="daily-stat__label">perfect ⭐</div>
          </div>
        </div>

        <div class="daily-share">
          <div class="daily-share__preview">${shareText.replace(/\n/g, '<br>')}</div>
          <button class="btn btn--primary btn--full btn--lg" id="share-btn">Share Result</button>
          <button class="btn btn--secondary btn--full" id="copy-btn">Copy to Clipboard</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById('back-btn').addEventListener('click', () =>
    window.__accessionNav && window.__accessionNav('today'));

  document.getElementById('share-btn').addEventListener('click', async () => {
    if (navigator.share) {
      try {
        await navigator.share({ text: shareText });
      } catch (e) { /* user cancelled, ignore */ }
    } else {
      // Fallback: copy and notify
      copyShareText(shareText);
    }
  });

  document.getElementById('copy-btn').addEventListener('click', () => {
    copyShareText(shareText);
  });
}

function copyShareText(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById('copy-btn');
    if (btn) {
      const orig = btn.textContent;
      btn.textContent = '✓ Copied!';
      setTimeout(() => { btn.textContent = orig; }, 1500);
    }
  }).catch(() => {
    alert('Copy failed — text:\n\n' + text);
  });
}
