/* ============================================================
   ACCESSION - EXHIBITIONS VIEW
   Curated browsing mode: themed exhibitions drawn dynamically
   from the full lesson + artwork catalogue. Works with any
   content that exists now or is added later.
   ============================================================ */

import { getAllLessons, getLesson, getAllArtworks, getArtwork, getEras, getRegions } from '../core/content.js';
import { getCellMastery, getArtworkMastery, RANK_NAMES } from '../core/progression.js';
import { startLesson } from '../app.js';

// ── Exhibition definitions ──────────────────────────────────────────────────
// Each exhibition is a filter function over lessons + artworks.
// New sessions populate them automatically.

function buildExhibitions() {
  const lessons = getAllLessons();
  const artworks = getAllArtworks();

  const completed = new Set();
  // Pull completion from movementProgress in state
  try {
    const raw = localStorage.getItem('accession:state');
    if (raw) {
      const s = JSON.parse(raw);
      for (const movId in s.movementProgress || {}) {
        for (const lid of s.movementProgress[movId].lessonsCompleted || []) {
          completed.add(lid);
        }
      }
    }
  } catch (e) { /* ignore */ }

  function exhibition(id, title, subtitle, era, filter) {
    const matching = lessons.filter(filter);
    const done = matching.filter(l => completed.has(l.id)).length;
    return { id, title, subtitle, era, lessons: matching, done, total: matching.length };
  }

  return [
    exhibition(
      'origins',
      'Origins of Art',
      'The first images made by human hands — caves, ochre, portable objects',
      'prehistoric',
      l => l.eraId === 'prehistoric'
    ),
    exhibition(
      'ancient-europe',
      'Ancient Europe',
      'Minoan, Bronze Age, Greek, Etruscan, and Roman art from 1600 BCE to 150 CE',
      'ancient-worlds',
      l => l.eraId === 'ancient-worlds' && l.regionId === 'europe'
    ),
    exhibition(
      'ancient-world',
      'The Ancient World',
      'Egypt, Mesopotamia, India, China, and the Americas in the first millennium BCE',
      'ancient-worlds',
      l => l.eraId === 'ancient-worlds' && l.regionId !== 'europe'
    ),
    exhibition(
      'sacred-medieval',
      'Sacred Worlds',
      'Buddhist, Hindu, Islamic, Byzantine, and Maya sacred art 500–1400 CE',
      'sacred-medieval',
      l => l.eraId === 'sacred-medieval'
    ),
    exhibition(
      'renaissance',
      'Renaissances & Empires',
      'Florence, Flanders, Mughal courts, Benin, and the Netherlands 1400–1800',
      'renaissances-empires',
      l => l.eraId === 'renaissances-empires'
    ),
    exhibition(
      'modern-world',
      'The Modern World',
      'Impressionism, photography, Ukiyo-e, and the art of industrial change',
      'revolution-industry',
      l => l.eraId === 'revolution-industry'
    ),
    exhibition(
      'modernism',
      'Modernism',
      'Picasso, Hopper, Matisse, Rivera, O\'Keeffe — art after the old rules broke',
      'modernism',
      l => l.eraId === 'modernism'
    ),
    exhibition(
      'materials',
      'Reading Materials',
      'Marble, bronze, fresco, mosaic, faience — how ancient media shape meaning',
      'ancient-worlds',
      l => ['ancient-materials-01', 'ancient-europe-materials-comparison',
            'roman-painting-mosaic-01', 'greek-symposium-01', 'etruscan-ancient-01'].includes(l.id)
    ),
    exhibition(
      'global-migration',
      'People in Motion',
      'Lapita, Jōmon, Sulawesi, Blombos — art as evidence of human migration',
      'prehistoric',
      l => ['oceania-ancient-01', 'prehistoric-sulawesi-01', 'prehistoric-africa-01',
            'prehistoric-global-art', 'jomon-ancient-01', 'jomon-to-yayoi-comparison',
            'prehistoric-east-asia-01'].includes(l.id)
    ),
    exhibition(
      'power',
      'The Art of Power',
      'How rulers across every culture used art to claim divine authority',
      'ancient-worlds',
      l => ['mesopotamian-ancient-01', 'mesopotamian-ancient-02', 'mesopotamian-royal-power-comparison',
            'greek-body-politics-01', 'roman-copies-01', 'egyptian-ancient-01',
            'african-sacred-medieval-01', 'africa-across-eras-comparison',
            'benin-bronzes-renaissances-01', 'americas-ancient-01'].includes(l.id)
    ),
    exhibition(
      'body',
      'The Human Body',
      'How artists across 40,000 years have represented the body — and why it matters',
      'prehistoric',
      l => ['prehistoric-global-venus', 'prehistoric-portable-art', 'greek-ancient-01',
            'greek-arc-ancient-01', 'greek-body-politics-01', 'roman-copies-01',
            'jomon-ancient-01', 'african-ancient-01', 'african-sacred-medieval-01'].includes(l.id)
    ),
    exhibition(
      'death',
      'Art and Death',
      'Tombs, mummies, jade suits, sarcophagi — how art handles mortality',
      'ancient-worlds',
      l => ['ancient-worlds-death-afterlife', 'maya-sacred-medieval-01',
            'americas-across-eras-comparison', 'egyptian-ancient-01',
            'prehistoric-portable-art'].includes(l.id)
    ),
  ].filter(e => e.total > 0);
}

// ── Render ──────────────────────────────────────────────────────────────────

let currentExhibition = null;

export function renderExhibitions() {
  const app = document.getElementById('app');
  if (!app) return;

  let exhibitions = [];
  try {
    exhibitions = buildExhibitions();
  } catch(err) {
    console.error('Exhibitions build error:', err);
    app.innerHTML = `<div class="view" style="padding:var(--space-8) var(--space-6)"><p style="color:var(--color-sepia)">Could not load exhibitions. Try again.</p></div>`;
    return;
  }

  const totalLessons = getAllLessons().length;

  if (currentExhibition) {
    renderExhibitionDetail(currentExhibition, exhibitions);
    return;
  }

  app.innerHTML = `
    <div class="view-exhibitions">
      <div class="view-header">
        <div class="view-header__title" style="font-family:var(--font-display);font-size:var(--type-display-l)">Exhibitions</div>
        <div class="view-header__sub" style="color:var(--color-sepia);font-family:var(--font-serif);font-style:italic;font-size:var(--type-body-m);margin-top:4px">${totalLessons} lessons across ${exhibitions.length} exhibitions</div>
      </div>
      <div class="exhibitions-grid">
        ${exhibitions.map(e => renderExhibitionCard(e)).join('')}
      </div>
    </div>
  `;

  app.querySelectorAll('.exhibition-card').forEach(card => {
    card.addEventListener('click', () => {
      currentExhibition = card.dataset.id;
      renderExhibitions();
    });
  });
}

function renderExhibitionCard(e) {
  const pct = e.total > 0 ? Math.round((e.done / e.total) * 100) : 0;
  const complete = e.done === e.total && e.total > 0;
  return `
    <div class="exhibition-card ${complete ? 'is-complete' : ''}" data-id="${e.id}">
      <div class="exhibition-card__era">${e.era ? ["I","II","III","IV","V","VI"][["prehistoric","ancient-worlds","sacred-medieval","renaissances-empires","revolution-industry","modernism"].indexOf(e.era)] || "" : ""}</div>
      <div class="exhibition-card__body">
        <div class="exhibition-card__title">${e.title}</div>
        <div class="exhibition-card__sub">${e.subtitle}</div>
        <div class="exhibition-card__meta">
          <div class="exhibition-card__progress-bar">
            <div class="exhibition-card__progress-fill" style="width:${pct}%"></div>
          </div>
          <span class="exhibition-card__count">${e.done}/${e.total}</span>
          ${complete ? '<span class="exhibition-badge"> Complete</span>' : ''}
        </div>
      </div>
    </div>
  `;
}

function renderExhibitionDetail(id, exhibitions) {
  const e = exhibitions.find(ex => ex.id === id);
  if (!e) { currentExhibition = null; renderExhibitions(); return; }
  const app = document.getElementById('app');

  const completed = new Set();
  try {
    const raw = localStorage.getItem('accession:state');
    if (raw) {
      const s = JSON.parse(raw);
      for (const movId in s.movementProgress || {}) {
        for (const lid of s.movementProgress[movId].lessonsCompleted || []) completed.add(lid);
      }
    }
  } catch(e) {}

  app.innerHTML = `
    <div class="view-exhibitions">
      <div class="exhibition-detail-header">
        <button class="btn-back" id="back-btn">All Exhibitions</button>
        <div class="exhibition-detail-era">${e.era ? ["I","II","III","IV","V","VI"][["prehistoric","ancient-worlds","sacred-medieval","renaissances-empires","revolution-industry","modernism"].indexOf(e.era)] || "" : ""}</div>
        <div class="exhibition-detail-title">${e.title}</div>
        <div class="exhibition-detail-sub">${e.subtitle}</div>
        <div class="exhibition-detail-progress">${e.done} of ${e.total} lessons complete</div>
      </div>
      <div class="lesson-list">
        ${e.lessons.map(l => {
          const done = completed.has(l.id);
          return `
            <div class="lesson-list-item ${done ? 'is-done' : ''}" data-lesson-id="${l.id}">
              <div class="lesson-list-item__check">${done ? '' : ''}</div>
              <div class="lesson-list-item__body">
                <div class="lesson-list-item__title">${l.title}</div>
                <div class="lesson-list-item__sub">${l.subtitle || ''}</div>
                <div class="lesson-list-item__meta">${l.estimatedMinutes || 7} min · ${l.cards ? l.cards.length : 0} cards</div>
              </div>
              <div class="lesson-list-item__arrow">&#8250;</div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;

  document.getElementById('back-btn').addEventListener('click', () => {
    currentExhibition = null;
    renderExhibitions();
  });

  app.querySelectorAll('.lesson-list-item').forEach(item => {
    item.addEventListener('click', () => startLesson(item.dataset.lessonId));
  });
}
