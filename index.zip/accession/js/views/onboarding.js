/* ============================================================
   ACCESSION - ONBOARDING
   Three steps:
   1. Intro / name
   2. Museum checklist (which of the big ones have you visited?)
   3. Walkthrough: sweep through artworks marking seen/not/maybe.
   ============================================================ */

import { getState, updateState, setSeenInPerson, markEncountered } from '../core/state.js';
import { getAllArtworks, getArtist, getMovement } from '../core/content.js';
import { navigate } from '../app.js';

import { buildPlacard } from '../core/placard.js';
// Museum list — based on what the user has visited per memory.
const MUSEUMS_TO_ASK = [
  { id: 'met',                    name: 'The Met (New York)' },
  { id: 'moma',                   name: 'MoMA (New York)' },
  { id: 'whitney',                name: 'Whitney (New York)' },
  { id: 'frick',                  name: 'The Frick (New York)' },
  { id: 'neue-galerie',           name: 'Neue Galerie (New York)' },
  { id: 'nga-dc',                 name: 'National Gallery of Art (Washington DC)' },
  { id: 'aic',                    name: 'Art Institute of Chicago' },
  { id: 'dma',                    name: 'Dallas Museum of Art' },
  { id: 'british-museum',         name: 'British Museum (London)' },
  { id: 'national-gallery-london',name: 'National Gallery (London)' },
  { id: 'louvre',                 name: 'Musée du Louvre (Paris)' },
  { id: 'vatican-museums',        name: 'Vatican Museums (Rome)' },
  { id: 'tokyo-national',         name: 'Tokyo National Museum' },
  { id: 'national-western-tokyo', name: 'National Museum of Western Art (Tokyo)' },
];

let step = 'intro';
let walkthroughIndex = 0;
let walkthroughQueue = [];

export function renderOnboarding() {
  const state = getState();
  // Resume at the right step
  if (!state.displayName) step = 'intro';
  else if (!state.hasCompletedIntro) step = 'museums';
  else if (!state.hasCompletedWalkthrough) step = 'walkthrough';
  else { navigate('today'); return; }

  if (step === 'intro') renderIntroStep();
  else if (step === 'museums') renderMuseumsStep();
  else if (step === 'walkthrough') renderWalkthroughStep();
}

function renderIntroStep() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="onboarding">
      <div class="onboarding__intro">
        <div class="onboarding__title">Accession</div>
        <div class="onboarding__subtitle">A slow, careful tour through the history of art</div>
      </div>
      <div class="onboarding__body">
        <p style="text-align: center; margin: var(--space-8) auto; max-width: 320px;">
          The plan is simple. Each day, you spend a few minutes with a handful of artworks.
          Over weeks, you build a sense of when, where, and by whom — so that when you next
          walk into a museum, the labels feel like footnotes.
        </p>
        <div style="margin-top: var(--space-8);">
          <label class="eyebrow" style="display: block; margin-bottom: var(--space-2);">Your name</label>
          <input
            type="text"
            id="name-input"
            placeholder="Hunter"
            style="width: 100%; padding: var(--space-4); border: 1.5px solid var(--color-line-strong); border-radius: var(--radius-md); font-family: var(--font-serif); font-size: var(--type-body-l); background: var(--color-paper-light); color: var(--color-ink);"
          />
        </div>
      </div>
      <div class="onboarding__footer">
        <button class="btn btn--primary btn--full btn--lg" id="next-btn">Begin</button>
      </div>
    </div>
  `;
  const input = document.getElementById('name-input');
  input.focus();
  document.getElementById('next-btn').addEventListener('click', () => {
    const name = input.value.trim();
    if (!name) {
      input.focus();
      return;
    }
    updateState({ displayName: name, hasCompletedIntro: true });
    step = 'museums';
    renderMuseumsStep();
  });
}

function renderMuseumsStep() {
  const app = document.getElementById('app');
  const state = getState();
  app.innerHTML = `
    <div class="onboarding">
      <div style="margin-bottom: var(--space-5); padding-top: var(--space-6);">
        <div class="eyebrow" style="margin-bottom: var(--space-2);">Step 1 of 2</div>
        <h1 style="font-size: var(--type-display-l); margin-bottom: var(--space-2);">Which museums have you visited?</h1>
        <p style="font-size: var(--type-body-m);">We will use this to help you remember works you have already stood in front of.</p>
      </div>
      <div class="onboarding__body">
        <div class="museum-checklist" id="museum-checklist">
          ${MUSEUMS_TO_ASK.map(m => `
            <div class="museum-checkbox ${state.visitedMuseums.includes(m.id) ? 'is-checked' : ''}" data-museum-id="${m.id}">
              <div class="museum-checkbox__box"></div>
              <div class="museum-checkbox__name">${m.name}</div>
            </div>
          `).join('')}
        </div>
      </div>
      <div class="onboarding__footer">
        <button class="btn btn--primary btn--full btn--lg" id="continue-btn">Continue</button>
      </div>
    </div>
  `;
  app.querySelectorAll('.museum-checkbox').forEach(box => {
    box.addEventListener('click', () => {
      const id = box.dataset.museumId;
      const visited = getState().visitedMuseums;
      const isChecked = visited.includes(id);
      updateState(s => {
        s.visitedMuseums = isChecked
          ? s.visitedMuseums.filter(x => x !== id)
          : [...s.visitedMuseums, id];
      });
      box.classList.toggle('is-checked');
    });
  });
  document.getElementById('continue-btn').addEventListener('click', () => {
    step = 'walkthrough';
    renderWalkthroughStep();
  });
}

function renderWalkthroughStep() {
  const app = document.getElementById('app');
  const state = getState();
  // Build the queue once: artworks from museums the user has visited,
  // randomly shuffled and capped at 10.
  if (walkthroughQueue.length === 0) {
    const visited = new Set(getState().visitedMuseums);
    const all = getAllArtworks();

    // Prefer artworks whose museumId matches a visited museum
    const fromVisited = all.filter(a => a.museumId && visited.has(a.museumId));

    // Fall back to any artwork if nothing matches (e.g. user skipped selection)
    const pool = fromVisited.length > 0 ? fromVisited : all;

    // Shuffle using Fisher-Yates
    const shuffled = pool.slice();
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }

    walkthroughQueue = shuffled.slice(0, 10);
    walkthroughIndex = 0;
  }
  const art = walkthroughQueue[walkthroughIndex];
  if (!art) {
    finishWalkthrough();
    return;
  }
  const artist = art.artistId ? getArtist(art.artistId) : null;
  const movement = getMovement(art.movementId);
  markEncountered(art.id);

  const progressPct = ((walkthroughIndex + 1) / walkthroughQueue.length) * 100;

  app.innerHTML = `
    <div class="onboarding">
      <div style="margin-bottom: var(--space-4); padding-top: var(--space-2);">
        <div class="lesson-progress-bar" style="margin-bottom: var(--space-4);">
          <div class="lesson-progress-bar__fill" style="width: ${progressPct}%"></div>
        </div>
        <div class="eyebrow" style="margin-bottom: var(--space-2);">Step 2 of 2 · ${walkthroughIndex + 1} of ${walkthroughQueue.length}</div>
        <h1 style="font-size: var(--type-display-m); margin-bottom: 0;">Seen this one?</h1>
        <p style="font-size: var(--type-body-s); margin: var(--space-1) 0 0;">Tap once for each work. Quick and approximate is fine.</p>
      </div>
      <div class="onboarding__body">
        <div class="walkthrough-card">
          <img class="walkthrough-card__image" src="${art.image || buildPlacard(art)}" data-placard="${buildPlacard(art)}" onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" data-met-id="${art.metObjectId || ''}" alt="${art.title}" />
          <div class="walkthrough-card__body">
            <h2 class="walkthrough-question" style="font-size: var(--type-display-m);">${art.title}</h2>
            <div class="walkthrough-meta">${artist ? artist.shortName + ' · ' : ''}${formatYear(art.year)} · ${movement?.shortName || ''}</div>
            <div class="walkthrough-choices">
              <button class="walkthrough-choice" data-value="yes">
                <span class="walkthrough-choice__icon">✓</span>
                Yes
              </button>
              <button class="walkthrough-choice" data-value="maybe">
                <span class="walkthrough-choice__icon">?</span>
                Maybe
              </button>
              <button class="walkthrough-choice" data-value="no">
                <span class="walkthrough-choice__icon">·</span>
                No
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="onboarding__footer">
        <button class="btn btn--secondary btn--full" id="skip-btn">Skip rest</button>
      </div>
    </div>
  `;

  app.querySelectorAll('.walkthrough-choice').forEach(btn => {
    btn.addEventListener('click', () => {
      setSeenInPerson(art.id, btn.dataset.value);
      walkthroughIndex += 1;
      renderWalkthroughStep();
    });
  });
  document.getElementById('skip-btn').addEventListener('click', () => {
    if (confirm('Skip the rest of the walkthrough? You can redo it from your profile any time.')) {
      finishWalkthrough();
    }
  });
}

function finishWalkthrough() {
  updateState({ hasCompletedWalkthrough: true });
  walkthroughQueue = [];
  walkthroughIndex = 0;
  navigate('today');
}

function formatYear(year) {
  if (!year && year !== 0) return '';
  if (year < 0) return `${Math.abs(year)} BCE`;
  return year;
}
