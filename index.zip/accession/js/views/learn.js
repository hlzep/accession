/* ============================================================
   ACCESSION - LEARN VIEW (global thesis + lesson browser)
   Three modes:
   - Regions: lessons grouped by region (default)
   - Eras:    lessons grouped by era
   Both show per-group mastery and tap-to-lesson browsing.
   ============================================================ */

import {
  getRegions, getEras, getAllArtworks, getLesson, getAllLessons, getRegion, getEra,
} from '../core/content.js';
import {
  getRegionMastery, getCuratorRank, getFurthestEraInRegion,
  getEraMastery, getCellMastery, RANK_NAMES,
} from '../core/progression.js';
import { startLesson, navigate } from '../app.js';
import { getState } from '../core/state.js';

// Lazy import to avoid circular dep — final-exhibition exports getEraExhibitionStatus
function getFeStatus(eraId) {
  try { return window.__getEraExhibitionStatus && window.__getEraExhibitionStatus(eraId); }
  catch(e) { return null; }
}

// Persist toggle between renders
let learnMode = 'region'; // 'region' | 'era'

export function renderLearn() {
  const app = document.getElementById('app');
  const samplerCompleted = isLessonCompleted('ancient-worlds-sampler');

  app.innerHTML = `
    <div class="view">
      <div class="eyebrow" style="margin-bottom: var(--space-2);">A path through human civilization</div>
      <h1 style="margin-bottom: var(--space-5);">Learn</h1>

      <!-- Sampler call-to-action for new users -->
      ${!samplerCompleted ? `
        <div class="card card--accent" data-lesson-id="ancient-worlds-sampler" style="cursor:pointer; margin-bottom: var(--space-6);">
          <div class="eyebrow" style="margin-bottom: var(--space-1);">Start here · 7 min</div>
          <h3 style="margin-bottom: var(--space-2);">The First Cities</h3>
          <p style="font-size: var(--type-body-m); color: var(--color-sepia); margin-bottom: var(--space-4);">
            One work from each of several regions in the ancient world. The best introduction to what this app is about.
          </p>
          <button class="btn btn--primary btn--full">Begin sampler</button>
        </div>
      ` : ''}

      <!-- Mode toggle -->
      <div style="display: flex; gap: var(--space-2); margin-bottom: var(--space-6);">
        <button class="btn ${learnMode === 'region' ? 'btn--primary' : 'btn--secondary'}" id="mode-region" style="flex:1;">By Region</button>
        <button class="btn ${learnMode === 'era'    ? 'btn--primary' : 'btn--secondary'}" id="mode-era"    style="flex:1;">By Era</button>
      </div>

      <!-- Content -->
      <div id="learn-content"></div>
    </div>
  `;

  // Wire toggle
  document.getElementById('mode-region').addEventListener('click', () => {
    learnMode = 'region'; renderLearn();
  });
  document.getElementById('mode-era').addEventListener('click', () => {
    learnMode = 'era'; renderLearn();
  });

  // Wire sampler card
  app.querySelectorAll('[data-lesson-id]').forEach(el => {
    el.addEventListener('click', () => startLesson(el.dataset.lessonId));
  });

  const content = document.getElementById('learn-content');
  if (learnMode === 'region') renderByRegion(content);
  else renderByEra(content);
}

/* =========================================================
   BY REGION: populated regions → tap to see era breakdown
   ========================================================= */

function renderByRegion(container) {
  const regions = getRegions();
  const populated = regions.filter(r =>
    getAllArtworks().some(a => a.regionId === r.id)
  );

  container.innerHTML = populated.map(r => {
    const mastery = getRegionMastery(r.id);
    const pct = Math.round(mastery * 100);
    const rank = getCuratorRank(r.id);
    const furthest = getFurthestEraInRegion(r.id);
    return `
      <div class="movement-tile" data-region-id="${r.id}" style="cursor:pointer;">
        <div class="movement-tile__years">${RANK_NAMES[rank]}${furthest ? ' · through ' + furthest.name : ''}</div>
        <h2 class="movement-tile__name" style="color:${r.color||'var(--color-ink)'};">${r.name}</h2>
        <p class="movement-tile__blurb">${r.blurb}</p>
        <div class="movement-tile__footer">
          <div class="movement-tile__progress">
            <div class="movement-tile__progress-fill" style="width:${pct}%; background:${r.color||'var(--color-burgundy)'};"></div>
          </div>
          <div style="font-family:var(--font-sans);font-size:var(--type-caption);letter-spacing:0.06em;color:var(--color-sepia);">${pct}%</div>
        </div>
      </div>
    `;
  }).join('');

  container.querySelectorAll('[data-region-id]').forEach(el => {
    el.addEventListener('click', () => openRegionDetail(el.dataset.regionId));
  });
}

function openRegionDetail(regionId) {
  const app = document.getElementById('app');
  const region = getRegion(regionId);
  if (!region) return;
  const eras = getEras();

  const rows = eras.map(era => {
    const cm = getCellMastery(era.id, region.id);
    if (cm === null) return `
      <div style="padding: var(--space-3) 0; border-bottom: 1px solid var(--color-line);">
        <div class="eyebrow" style="margin-bottom:2px;">${era.name}</div>
        <p style="margin:0; font-size:var(--type-body-s); color:var(--color-sepia-light); font-style:italic;">No content yet.</p>
      </div>
    `;
    const pct = Math.round(cm * 100);
    const lessons = findLessonsForCell(era.id, region.id);
    return `
      <div style="padding: var(--space-4) 0; border-bottom: 1px solid var(--color-line);">
        <div style="display:flex; align-items:center; gap:var(--space-3); margin-bottom:var(--space-2);">
          <div style="flex:1;">
            <div class="eyebrow" style="margin-bottom:2px;">${era.name}</div>
            <div style="font-family:var(--font-sans);font-size:var(--type-body-s);color:var(--color-sepia);">${pct}% mastered</div>
          </div>
          <div style="width:80px;height:2px;background:var(--color-line);">
            <div style="height:100%;background:${region.color||'var(--color-burgundy)'};width:${pct}%;"></div>
          </div>
        </div>
        ${lessons.map(l => lessonCard(l)).join('')}
      </div>
    `;
  }).join('');

  app.innerHTML = `
    <div class="view">
      <div style="display:flex; align-items:center; gap:var(--space-3); margin-bottom:var(--space-5);">
        <button class="lesson-close" id="back-btn" aria-label="Back">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <div class="eyebrow">Region</div>
      </div>
      <h1 style="margin-bottom:var(--space-3);color:${region.color||'var(--color-ink)'};">${region.name}</h1>
      <p style="margin-bottom:var(--space-6);">${region.longForm||region.blurb}</p>
      <h3 class="today-section__title"><span>Through the eras</span></h3>
      ${rows}
    </div>
  `;

  document.getElementById('back-btn').addEventListener('click', renderLearn);
  app.querySelectorAll('[data-lesson-id]').forEach(el => {
    el.addEventListener('click', () => startLesson(el.dataset.lessonId));
  });
}

/* =========================================================
   BY ERA: eras in order → tap to see region breakdown
   ========================================================= */

function renderByEra(container) {
  const eras = getEras();

  container.innerHTML = eras.map(era => {
    const mastery = getEraMastery(era.id);
    const pct = Math.round(mastery * 100);
    const lessonList = getAllLessonsForEra(era.id);
    const completedCount = lessonList.filter(l => isLessonCompleted(l.id)).length;
    return `
      <div class="movement-tile" data-era-id="${era.id}" style="cursor:pointer;">
        <div class="movement-tile__years">${era.yearStart < 0 ? Math.abs(era.yearStart) + ' BCE' : era.yearStart} – ${era.yearEnd < 0 ? Math.abs(era.yearEnd) + ' BCE' : era.yearEnd}</div>
        <h2 class="movement-tile__name" style="color:${era.color||'var(--color-ink)'};">${era.name}</h2>
        <p class="movement-tile__blurb">${era.blurb}</p>
        <div class="movement-tile__footer">
          <div class="movement-tile__progress">
            <div class="movement-tile__progress-fill" style="width:${pct}%; background:${era.color||'var(--color-burgundy)'};"></div>
          </div>
          <div style="font-family:var(--font-sans);font-size:var(--type-caption);letter-spacing:0.06em;color:var(--color-sepia);">
            ${completedCount}/${lessonList.length} lessons · ${pct}% mastered
          </div>
        </div>
      </div>
    `;
  }).join('');

  container.querySelectorAll('[data-era-id]').forEach(el => {
    el.addEventListener('click', () => openEraDetail(el.dataset.eraId));
  });
}

function openEraDetail(eraId) {
  const app = document.getElementById('app');
  const era = getEra(eraId);
  if (!era) return;
  const regions = getRegions();

  const rows = regions.map(region => {
    const cm = getCellMastery(eraId, region.id);
    if (cm === null) return '';
    const pct = Math.round(cm * 100);
    const lessons = findLessonsForCell(eraId, region.id);
    return `
      <div style="padding: var(--space-4) 0; border-bottom: 1px solid var(--color-line);">
        <div style="display:flex; align-items:center; gap:var(--space-3); margin-bottom:var(--space-2);">
          <div style="flex:1;">
            <div class="eyebrow" style="margin-bottom:2px;">${region.name}</div>
            <div style="font-family:var(--font-sans);font-size:var(--type-body-s);color:var(--color-sepia);">${pct}% mastered</div>
          </div>
          <div style="width:80px;height:2px;background:var(--color-line);">
            <div style="height:100%;background:${region.color||'var(--color-burgundy)'};width:${pct}%;"></div>
          </div>
        </div>
        ${lessons.map(l => lessonCard(l)).join('')}
      </div>
    `;
  }).filter(Boolean).join('');

  // Also show sampler-style lessons tagged only to this era
  const samplerLessons = getAllLessonsForEra(eraId).filter(l => l.isSampler || !l.regionId);

  const fe = getFeStatus(eraId);
  const feCard = fe ? (() => {
    if (fe.unlocked && !fe.passed) return `
      <div class="fe-learn-card fe-learn-card--unlocked" id="fe-era-card" data-era-id="${eraId}">
        <div class="fe-learn-card__label">Final Exhibition — Unlocked</div>
        <div class="fe-learn-card__title">Era Examination</div>
        <div class="fe-learn-card__body">All ${fe.totalLessons} lessons complete. Take the final examination to earn your certificate for this era.</div>
        <div class="fe-learn-card__action">Begin Final Exhibition</div>
      </div>
    `;
    if (fe.passed) return `
      <div class="fe-learn-card fe-learn-card--passed" id="fe-era-card" data-era-id="${eraId}">
        <div class="fe-learn-card__label">Final Exhibition — Passed ${fe.previousScore}/${fe.previousTotal}</div>
        <div class="fe-learn-card__title">Era Examination</div>
        <div class="fe-learn-card__body">${fe.needsRefresher ? 'New content has been added. Complete new lessons to retake.' : 'Retake any time to improve your score.'}</div>
        <div class="fe-learn-card__action">${fe.needsRefresher ? 'Complete new lessons first' : 'Retake Examination'}</div>
      </div>
    `;
    if (fe.totalLessons > 0) return `
      <div class="fe-learn-card fe-learn-card--locked">
        <div class="fe-learn-card__label">Final Exhibition — Locked</div>
        <div class="fe-learn-card__title">Era Examination</div>
        <div class="fe-learn-card__body">${fe.completedLessons}/${fe.totalLessons} lessons complete. Finish all lessons to unlock.</div>
        <div class="fe-learn-card__progress">
          <div class="fe-learn-card__progress-fill" style="width:${Math.round(fe.completedLessons/fe.totalLessons*100)}%"></div>
        </div>
      </div>
    `;
    return '';
  })() : '';

  app.innerHTML = `
    <div class="view">
      <div style="display:flex; align-items:center; gap:var(--space-3); margin-bottom:var(--space-5);">
        <button class="lesson-close" id="back-btn" aria-label="Back">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <div class="eyebrow">Era</div>
      </div>
      <h1 style="margin-bottom:var(--space-2);color:${era.color||'var(--color-ink)'};">${era.name}</h1>
      <p style="font-family:var(--font-serif);font-style:italic;color:var(--color-sepia);margin-bottom:var(--space-3);">${era.yearStart < 0 ? Math.abs(era.yearStart) + ' BCE' : era.yearStart} – ${era.yearEnd < 0 ? Math.abs(era.yearEnd) + ' BCE' : era.yearEnd}</p>
      <p style="margin-bottom:var(--space-6);">${era.longForm||era.blurb}</p>

      ${feCard}

      ${samplerLessons.length ? `
        <h3 class="today-section__title" style="margin-bottom:var(--space-3);"><span>Era lessons</span></h3>
        ${samplerLessons.map(l => lessonCard(l)).join('')}
        <div style="margin-bottom:var(--space-6);"></div>
      ` : ''}

      ${rows ? `<h3 class="today-section__title" style="margin-bottom:0;"><span>By region</span></h3>${rows}` : ''}
    </div>
  `;

  document.getElementById('back-btn').addEventListener('click', renderLearn);
  app.querySelectorAll('[data-lesson-id]').forEach(el => {
    el.addEventListener('click', () => startLesson(el.dataset.lessonId));
  });
  const feCardEl = document.getElementById('fe-era-card');
  if (feCardEl) {
    const feStatus = getFeStatus(feCardEl.dataset.eraId);
    if (feStatus && (feStatus.unlocked || feStatus.passed) && !feStatus.needsRefresher) {
      feCardEl.style.cursor = 'pointer';
      feCardEl.addEventListener('click', () => navigate('final-exhibitions'));
    }
  }
}

/* =========================================================
   HELPERS
   ========================================================= */

function lessonCard(lesson) {
  const done = isLessonCompleted(lesson.id);
  return `
    <div class="card" data-lesson-id="${lesson.id}" style="margin-top:var(--space-2);cursor:pointer;padding:var(--space-3);">
      <div style="display:flex;align-items:center;gap:var(--space-2);">
        <div style="flex:1;">
          <div class="eyebrow" style="margin-bottom:2px;">
            ${lesson.isSampler ? 'Sampler' : 'Lesson'} · ${lesson.estimatedMinutes||5} min
            ${done ? ' · <span style="color:var(--color-gold);">✓ Complete</span>' : ''}
          </div>
          <strong style="font-family:var(--font-display);font-size:var(--type-body-l);">${lesson.title}</strong>
          ${lesson.subtitle ? `<p style="margin:0;font-size:var(--type-body-s);color:var(--color-sepia);">${lesson.subtitle}</p>` : ''}
        </div>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--color-sepia)" stroke-width="2" stroke-linecap="round"><path d="M9 6l6 6-6 6"/></svg>
      </div>
    </div>
  `;
}

/**
 * Map era/region cells to their lesson IDs.
 * This is the canonical lesson-to-cell mapping.
 */
/**
 * Find all lessons for a specific era+region cell.
 * Driven entirely from lesson JSON data — no hardcoded map.
 */
function findLessonsForCell(eraId, regionId) {
  return getAllLessons()
    .filter(l => l.eraId === eraId && l.regionId === regionId);
}

/**
 * Get all lessons tagged to an era (for the era detail view).
 * Includes both region-specific lessons and era-wide lessons (no regionId).
 */
function getAllLessonsForEra(eraId) {
  return getAllLessons()
    .filter(l => l.eraId === eraId);
}

function isLessonCompleted(lessonId) {
  const state = getState();
  for (const scopeKey in state.movementProgress) {
    if ((state.movementProgress[scopeKey].lessonsCompleted || []).includes(lessonId)) {
      return true;
    }
  }
  return false;
}
