/* ============================================================
   ACCESSION - FINAL EXHIBITIONS
   Boss-match quizzes unlocked when a user completes all lessons
   in an era. Draws on every artwork in the era for a
   comprehensive cumulative test.

   Rules:
   - Unlocked only when all sequenced lessons in the era are done
   - If new lessons are added after completion, a refresher gate
     appears: user must complete the new lessons before re-taking
   - Quiz: 10 questions drawn from ALL artworks in the era
   - Question types: region, date, before-after, medium
   - Passing score: 7/10
   - State persisted in localStorage under accession:finalExhibitions
   ============================================================ */

import { getAllLessons, getAllArtworks, getArtwork, getEra, getEras, getRegions } from '../core/content.js';
import { getState } from '../core/state.js';
import { buildPlacard } from '../core/placard.js';

// ── Helpers ──────────────────────────────────────────────────────────────────

function getSequencedLessons() {
  // Read the ordered sequence from progression.js via a global set during boot
  // We detect it from the lesson sequence order in state
  return window.__lessonSequence || [];
}

function getCompletedLessons() {
  const s = getState();
  const set = new Set();
  for (const movId in s.movementProgress || {}) {
    for (const lid of s.movementProgress[movId].lessonsCompleted || []) set.add(lid);
  }
  return set;
}

function getFinalExhibitionState() {
  try {
    return JSON.parse(localStorage.getItem('accession:finalExhibitions') || '{}');
  } catch(e) { return {}; }
}

function saveFinalExhibitionState(state) {
  localStorage.setItem('accession:finalExhibitions', JSON.stringify(state));
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ── Era completion logic ──────────────────────────────────────────────────────

export function getEraExhibitionStatus(eraId) {
  const allLessons = getAllLessons();
  const sequenced = allLessons.filter(l => l.eraId === eraId);
  const completed = getCompletedLessons();
  const feState = getFinalExhibitionState();

  const allDone = sequenced.length > 0 && sequenced.every(l => completed.has(l.id));
  const prevRecord = feState[eraId] || null;

  // Check if new lessons were added since last exhibition completion
  let needsRefresher = false;
  if (prevRecord?.completedAt) {
    const lessonsAtCompletion = new Set(prevRecord.lessonsAtCompletion || []);
    const currentLessons = new Set(sequenced.map(l => l.id));
    needsRefresher = [...currentLessons].some(id => !lessonsAtCompletion.has(id)) &&
                     ![...currentLessons].every(id => completed.has(id));
  }

  return {
    eraId,
    totalLessons: sequenced.length,
    completedLessons: sequenced.filter(l => completed.has(l.id)).length,
    unlocked: allDone && !needsRefresher,
    needsRefresher,
    previousScore: prevRecord?.score || null,
    previousTotal: prevRecord?.total || null,
    passed: prevRecord?.passed || false,
    completedAt: prevRecord?.completedAt || null,
  };
}

// ── Question generation ───────────────────────────────────────────────────────

function generateExhibitionQuiz(eraId, count = 10) {
  const arts = getAllArtworks().filter(a => a.eraId === eraId);
  const regions = getRegions();
  if (arts.length < 4) return [];

  // Difficulty ramp: questions 1-4 are factual (region/date/medium/before-after),
  // questions 5-7 are mixed, questions 8-10 are comprehension (synthesis/context).
  // Shuffle artworks and assign question types by position.
  const shuffledArts = shuffle([...arts]);
  const questions = [];
  const used = new Set();

  const factualTypes = ['region', 'date', 'medium', 'before-after'];

  // Helper: build a factual question for one artwork
  function makeFactual(art, preferType) {
    const types = preferType ? [preferType, ...factualTypes.filter(t => t !== preferType)] : factualTypes;
    for (const type of shuffle(types)) {
      if (type === 'region' && art.regionId) {
        const allRegions = regions.map(r => r.id);
        const distractors = shuffle(allRegions.filter(r => r !== art.regionId)).slice(0, 3);
        if (distractors.length < 3) continue;
        return {
          type: 'region',
          artworkId: art.id,
          question: 'Where in the world was this made?',
          options: shuffle([art.regionId, ...distractors]).map(id => ({
            id, label: regions.find(r => r.id === id)?.name || id
          })),
          correctId: art.regionId,
        };
      }
      if (type === 'date' && art.year != null) {
        const y = art.year;
        const deltas = [150, 400, 900, 2000];
        const wrongs = shuffle(deltas).slice(0, 3).map(d =>
          y + (Math.random() > 0.5 ? d : -d)
        );
        return {
          type: 'date',
          artworkId: art.id,
          question: 'Approximately when was this made?',
          options: shuffle([y, ...wrongs]).map(y2 => ({
            id: String(y2),
            label: y2 < 0 ? `${Math.abs(Math.round(y2))} BCE` : `${Math.round(y2)} CE`
          })),
          correctId: String(y),
        };
      }
      if (type === 'medium' && art.medium) {
        const others = shuffle(
          arts.filter(a => a.id !== art.id && a.medium)
            .map(a => a.medium.split('(')[0].split(',')[0].trim())
            .filter((m, i, arr) => arr.indexOf(m) === i)
        ).slice(0, 3);
        if (others.length < 2) continue;
        const correct = art.medium.split('(')[0].split(',')[0].trim();
        return {
          type: 'medium',
          artworkId: art.id,
          question: 'What material or technique was used to make this?',
          options: shuffle([correct, ...others]).map(m => ({ id: m, label: m })),
          correctId: correct,
        };
      }
      if (type === 'before-after') {
        const candidates = shuffledArts.filter(a => a.id !== art.id && a.year != null && art.year != null && a.year !== art.year && !used.has(a.id));
        if (candidates.length === 0) continue;
        const other = candidates[0];
        const earlier = art.year < other.year ? art : other;
        const later = art.year < other.year ? other : art;
        // Mark both used
        used.add(other.id);
        return {
          type: 'before-after',
          artworkId: earlier.id,
          artworkId2: later.id,
          question: 'Which was made first?',
          options: shuffle([
            { id: earlier.id, label: earlier.title },
            { id: later.id, label: later.title },
          ]),
          correctId: earlier.id,
        };
      }
    }
    return null;
  }

  // Helper: build a comprehension question for one artwork
  function makeComprehension(art) {
    const cq = art.comprehensionQuestion;
    if (!cq || !cq.question || !cq.options || cq.options.length < 4) return null;
    // Shuffle options but track the correct answer by content, not index
    const correct = cq.options[cq.correctIndex];
    const shuffledOpts = shuffle(cq.options.map((text, i) => ({ id: String(i), text })));
    const newCorrectId = shuffledOpts.find(o => o.text === correct)?.id || '0';
    return {
      type: 'comprehension',
      artworkId: art.id,
      question: cq.question,
      options: shuffledOpts.map(o => ({ id: o.id, label: o.text })),
      correctId: newCorrectId,
      explanation: cq.explanation || '',
    };
  }

  // Build 10 questions with a difficulty ramp:
  // Q1–4: factual (region/date/medium/before-after)
  // Q5–7: mixed factual + some comprehension
  // Q8–10: comprehension (synthesis/analysis questions from artwork data)

  const artPool = shuffle([...arts]);
  const artIterator = artPool[Symbol.iterator]();

  function nextArt() {
    for (const a of artIterator) {
      if (!used.has(a.id)) { used.add(a.id); return a; }
    }
    // Exhaust — allow reuse for comprehension (different question type)
    return artPool[Math.floor(Math.random() * artPool.length)];
  }

  // Q1-4: pure factual
  for (let i = 0; i < 4 && questions.length < count; i++) {
    const art = nextArt();
    if (!art) break;
    const q = makeFactual(art);
    if (q) questions.push(q);
  }

  // Q5-7: mixed (alternate factual and comprehension)
  for (let i = 0; i < 3 && questions.length < count; i++) {
    const art = nextArt();
    if (!art) break;
    const q = i % 2 === 0 ? makeComprehension(art) || makeFactual(art) : makeFactual(art) || makeComprehension(art);
    if (q) questions.push(q);
  }

  // Q8-10: comprehension only
  for (let i = 0; i < 3 && questions.length < count; i++) {
    const art = nextArt();
    if (!art) break;
    // For comprehension, allow reuse with different question type
    const q = makeComprehension(art) || makeFactual(art);
    if (q) questions.push(q);
  }

  return questions.slice(0, count);
}

// ── View state ────────────────────────────────────────────────────────────────

let feView = 'list';       // 'list' | 'intro' | 'quiz' | 'results'
let feEraId = null;
let feQuiz = null;         // { questions, answers, score }

// ── Entry point ───────────────────────────────────────────────────────────────

export function renderFinalExhibitions() {
  if (feView === 'intro' && feEraId) {
    renderExhibitionIntro(feEraId);
  } else if (feView === 'quiz' && feQuiz) {
    renderExhibitionQuestion();
  } else if (feView === 'results' && feQuiz) {
    renderExhibitionResults();
  } else {
    renderExhibitionList();
  }
}

function renderExhibitionList() {
  const app = document.getElementById('app');
  const eras = getEras();

  const rows = eras.map(era => {
    const s = getEraExhibitionStatus(era.id);
    const pct = s.totalLessons > 0 ? Math.round((s.completedLessons / s.totalLessons) * 100) : 0;
    const artCount = getAllArtworks().filter(a => a.eraId === era.id).length;

    let badge = '', badgeClass = '', actionLabel = '', actionEnabled = false;
    if (s.passed) {
      badge = 'Passed';
      badgeClass = 'fe-badge--passed';
      actionLabel = `Retake · ${s.previousScore}/${s.previousTotal}`;
      actionEnabled = s.unlocked;
    } else if (s.unlocked) {
      badge = 'Unlocked';
      badgeClass = 'fe-badge--unlocked';
      actionLabel = 'Begin Exhibition';
      actionEnabled = true;
    } else if (s.needsRefresher) {
      badge = 'New content';
      badgeClass = 'fe-badge--refresher';
      actionLabel = 'Complete new lessons first';
      actionEnabled = false;
    } else {
      badge = `${s.completedLessons}/${s.totalLessons} lessons`;
      badgeClass = 'fe-badge--locked';
      actionLabel = pct === 100 ? 'Ready' : `${pct}% complete`;
      actionEnabled = false;
    }

    return `
      <div class="fe-era-row ${s.unlocked ? 'is-unlocked' : ''} ${s.passed ? 'is-passed' : ''}"
           data-era-id="${era.id}" data-action="${actionEnabled ? 'start' : ''}">
        <div class="fe-era-row__body">
          <div class="fe-era-row__name">${era.name}</div>
          <div class="fe-era-row__meta">${artCount} artworks · ${s.totalLessons} lessons</div>
          <div class="fe-era-progress">
            <div class="fe-era-progress__bar">
              <div class="fe-era-progress__fill" style="width:${pct}%"></div>
            </div>
          </div>
        </div>
        <div class="fe-era-row__right">
          <span class="fe-badge ${badgeClass}">${badge}</span>
          ${actionEnabled ? `<div class="fe-era-action">${actionLabel}</div>` : `<div class="fe-era-action fe-era-action--disabled">${actionLabel}</div>`}
        </div>
      </div>
    `;
  }).join('');

  app.innerHTML = `
    <div class="view-fe">
      <div class="view-header">
        <div class="view-header__title" style="font-family:var(--font-display);font-size:var(--type-display-l)">Final Exhibitions</div>
        <div class="view-header__sub" style="color:var(--color-sepia);font-family:var(--font-serif);font-style:italic;font-size:var(--type-body-m);margin-top:4px">
          Complete all lessons in an era to unlock its final examination
        </div>
      </div>
      <div class="fe-era-list">${rows}</div>
    </div>
  `;

  app.querySelectorAll('.fe-era-row[data-action="start"]').forEach(row => {
    row.addEventListener('click', () => {
      feEraId = row.dataset.eraId;
      feView = 'intro';
      renderFinalExhibitions();
    });
  });
}

// ── Intro screen ──────────────────────────────────────────────────────────────

function renderExhibitionIntro(eraId) {
  const app = document.getElementById('app');
  const era = getEra(eraId);
  const artCount = getAllArtworks().filter(a => a.eraId === eraId).length;
  const s = getEraExhibitionStatus(eraId);

  app.innerHTML = `
    <div class="view-fe view-fe--intro">
      <button class="btn-back" id="fe-back">All Exhibitions</button>
      <div class="fe-intro-era">${era?.name || eraId}</div>
      <div class="fe-intro-title">Final Exhibition</div>
      <div class="fe-intro-body">
        <p>You have completed all ${s.totalLessons} lessons in the ${era?.name} era.</p>
        <p>This examination draws on all <strong>${artCount} artworks</strong> from this era — including works you've seen in lessons and others you may not have encountered directly.</p>
        <p>10 questions. You need <strong>7 correct</strong> to pass.</p>
        ${s.passed ? `<p class="fe-intro-previous">Your best: <strong>${s.previousScore}/${s.previousTotal}</strong></p>` : ''}
      </div>
      <div class="fe-intro-actions">
        <button class="btn btn--primary btn--full btn--lg" id="fe-start-btn">Begin Examination</button>
        <button class="btn btn--secondary btn--full" id="fe-back2">Back</button>
      </div>
    </div>
  `;

  document.getElementById('fe-back')?.addEventListener('click', () => { feView = 'list'; feEraId = null; renderFinalExhibitions(); });
  document.getElementById('fe-back2')?.addEventListener('click', () => { feView = 'list'; feEraId = null; renderFinalExhibitions(); });
  document.getElementById('fe-start-btn')?.addEventListener('click', () => {
    const questions = generateExhibitionQuiz(eraId, 10);
    if (!questions.length) return;
    feQuiz = { eraId, questions, answers: [], score: 0 };
    feView = 'quiz';
    renderFinalExhibitions();
  });
}

// ── Quiz question ─────────────────────────────────────────────────────────────

function renderExhibitionQuestion() {
  const app = document.getElementById('app');
  const { questions, answers, score } = feQuiz;
  const qIdx = answers.length;

  if (qIdx >= questions.length) {
    feView = 'results';
    // Save result
    const feState = getFinalExhibitionState();
    const allLessons = getAllLessons().filter(l => l.eraId === feQuiz.eraId);
    feState[feQuiz.eraId] = {
      score,
      total: questions.length,
      passed: score >= 7,
      completedAt: new Date().toISOString(),
      lessonsAtCompletion: allLessons.map(l => l.id),
    };
    saveFinalExhibitionState(feState);
    renderFinalExhibitions();
    return;
  }

  const q = questions[qIdx];
  const art = getArtwork(q.artworkId);
  const art2 = q.artworkId2 ? getArtwork(q.artworkId2) : null;

  const isComprehension = q.type === 'comprehension';

  app.innerHTML = `
    <div class="view-fe view-fe--quiz">
      <div class="fe-quiz-header">
        <div class="fe-quiz-progress">Question ${qIdx + 1} of ${questions.length}${qIdx >= 7 ? ' · Synthesis' : ''}</div>
        <div class="fe-quiz-score">${score} correct</div>
      </div>
      <div class="fe-quiz-progress-bar">
        <div class="fe-quiz-progress-fill" style="width:${(qIdx / questions.length) * 100}%"></div>
      </div>

      ${isComprehension ? `<div class="fe-quiz-type-label">Analysis question</div>` : ''}

      <div class="fe-quiz-question">${q.question}</div>

      ${q.type === 'before-after' ? `
        <div class="fe-quiz-two-images">
          <div class="fe-quiz-two-item">
            <img referrerpolicy="no-referrer" class="fe-quiz-img" src="${art?.image || buildPlacard(art)}"
                 data-placard="${buildPlacard(art)}"
                 onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" alt="" />
            <div class="fe-quiz-two-label">${art?.title || ''}</div>
          </div>
          <div class="fe-quiz-two-item">
            <img referrerpolicy="no-referrer" class="fe-quiz-img" src="${art2?.image || buildPlacard(art2)}"
                 data-placard="${buildPlacard(art2)}"
                 onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" alt="" />
            <div class="fe-quiz-two-label">${art2?.title || ''}</div>
          </div>
        </div>
      ` : `
        <img referrerpolicy="no-referrer" class="fe-quiz-img fe-quiz-img--full" src="${art?.image || buildPlacard(art)}"
             data-placard="${buildPlacard(art)}"
             onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}"
             data-met-id="${art?.metObjectId || ''}" alt="" />
        <div class="fe-quiz-artwork-label">${art?.title || ''}${art?.year != null ? ` · ${art.year < 0 ? Math.abs(art.year) + ' BCE' : art.year + ' CE'}` : ''}</div>
      `}

      <div class="fe-quiz-options" id="fe-options">
        ${q.options.map(opt => `
          <button class="fe-quiz-option ${isComprehension ? 'fe-quiz-option--comprehension' : ''}" data-id="${opt.id}">${opt.label}</button>
        `).join('')}
      </div>
      <div id="fe-feedback" class="fe-quiz-feedback"></div>
      ${isComprehension ? `<div id="fe-explanation" class="fe-quiz-explanation"></div>` : ''}
    </div>
  `;

  document.querySelectorAll('.fe-quiz-option').forEach(btn => {
    btn.addEventListener('click', () => handleExhibitionAnswer(btn.dataset.id, q));
  });
}

function handleExhibitionAnswer(chosen, q) {
  const correct = chosen === q.correctId;
  if (correct) feQuiz.score++;
  feQuiz.answers.push({ chosen, correct, questionType: q.type });

  document.querySelectorAll('.fe-quiz-option').forEach(btn => {
    btn.disabled = true;
    if (btn.dataset.id === q.correctId) btn.classList.add('is-correct');
    else if (btn.dataset.id === chosen && !correct) btn.classList.add('is-incorrect');
  });

  const fb = document.getElementById('fe-feedback');
  if (fb) {
    if (q.type === 'comprehension') {
      fb.textContent = correct ? 'Correct' : `Not quite — the answer was: ${q.options.find(o => o.id === q.correctId)?.label?.slice(0, 60)}…`;
    } else {
      fb.textContent = correct ? 'Correct' : `Not quite — ${q.options.find(o => o.id === q.correctId)?.label}`;
    }
    fb.className = 'fe-quiz-feedback ' + (correct ? 'is-correct' : 'is-incorrect');
  }

  // Show explanation for comprehension questions
  const expEl = document.getElementById('fe-explanation');
  if (expEl && q.explanation) {
    expEl.textContent = q.explanation;
    expEl.classList.add('is-visible');
  }

  // Comprehension questions show longer before advancing
  const delay = q.type === 'comprehension' ? (correct ? 2200 : 3500) : (correct ? 1000 : 1800);
  setTimeout(() => renderExhibitionQuestion(), delay);
}

// ── Results ───────────────────────────────────────────────────────────────────

function renderExhibitionResults() {
  const app = document.getElementById('app');
  const { score, questions, eraId } = feQuiz;
  const era = getEra(eraId);
  const passed = score >= 7;
  const pct = Math.round((score / questions.length) * 100);

  const breakdown = questions.map((q, i) => {
    const art = getArtwork(q.artworkId);
    const ans = feQuiz.answers[i];
    return `
      <div class="fe-result-item ${ans?.correct ? 'is-correct' : 'is-incorrect'}">
        <img referrerpolicy="no-referrer" class="fe-result-thumb" src="${art?.image || buildPlacard(art)}"
             data-placard="${buildPlacard(art)}"
             onerror="if(this.dataset.placard&&this.src!==this.dataset.placard){this.src=this.dataset.placard}" alt="" />
        <div class="fe-result-body">
          <div class="fe-result-title">${art?.title || q.artworkId}</div>
          <div class="fe-result-type">${q.type}</div>
          <div class="fe-result-verdict">${ans?.correct ? 'Correct' : 'Incorrect'}</div>
        </div>
      </div>
    `;
  }).join('');

  app.innerHTML = `
    <div class="view-fe view-fe--results">
      <div class="fe-results-header">
        <div class="fe-results-era">${era?.name} — Final Exhibition</div>
        <div class="fe-results-score">${score} / ${questions.length}</div>
        <div class="fe-results-verdict ${passed ? 'is-passed' : 'is-failed'}">
          ${passed ? 'Exhibition passed' : 'Not yet — try again'}
        </div>
        <div class="fe-results-pct">${pct}% correct · ${passed ? 'Pass (7+ required)' : 'Pass requires 7/10'}</div>
      </div>

      <div class="fe-results-breakdown">${breakdown}</div>

      <div class="fe-results-actions">
        ${passed
          ? `<button class="btn btn--primary btn--full btn--lg" id="fe-done-btn">Done</button>`
          : `<button class="btn btn--primary btn--full btn--lg" id="fe-retry-btn">Try Again</button>`
        }
        <button class="btn btn--secondary btn--full" id="fe-list-btn">All Exhibitions</button>
      </div>
    </div>
  `;

  document.getElementById('fe-done-btn')?.addEventListener('click', () => {
    feView = 'list'; feEraId = null; feQuiz = null; renderFinalExhibitions();
  });
  document.getElementById('fe-retry-btn')?.addEventListener('click', () => {
    const questions = generateExhibitionQuiz(feQuiz.eraId, 10);
    feQuiz = { eraId: feQuiz.eraId, questions, answers: [], score: 0 };
    feView = 'quiz';
    renderFinalExhibitions();
  });
  document.getElementById('fe-list-btn')?.addEventListener('click', () => {
    feView = 'list'; feEraId = null; feQuiz = null; renderFinalExhibitions();
  });
}
