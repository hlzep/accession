/* ============================================================
   ACCESSION - APP ENTRY
   Boots the app, loads content, routes between views.
   ============================================================ */

import { loadState, getState, tickSession } from './core/state.js';
import { loadContent } from './core/content.js';
import { initSync } from './core/sync.js';

import { renderToday } from './views/today.js';
import { renderLearn } from './views/learn.js';
import { renderCollection } from './views/collection.js';
import { renderProfile } from './views/profile.js';
import { renderOnboarding } from './views/onboarding.js';
import { renderExhibitions } from './views/exhibitions.js';
import { renderVersus } from './views/versus.js';
import { renderFinalExhibitions } from './views/final-exhibition.js';
import { renderDaily } from './views/daily.js';
import { startLessonImpl, startReviewImpl } from './lessons/engine.js';
import { hydrateMetImage } from './core/metApi.js';

/**
 * Find all <img data-met-id="..."> elements on the page and resolve their
 * canonical Met image URLs. Called automatically after every render.
 */
function hydrateAllMetImages() {
  document.querySelectorAll('img[data-met-id]').forEach(img => {
    const metId = img.getAttribute('data-met-id');
    if (metId && metId !== 'null') hydrateMetImage(img, metId);
  });
}

// Currently rendered view ID, used to highlight the tab.
let currentView = null;

/**
 * Navigate to a named view. Renders the view and updates the tab bar.
 */
export function navigate(view) {
  currentView = view;

  switch (view) {
    case 'today':            renderToday(); break;
    case 'learn':            renderLearn(); break;
    case 'collection':       renderCollection(); break;
    case 'profile':          renderProfile(); break;
    case 'exhibitions':      renderExhibitions(); break;
    case 'final-exhibitions':renderFinalExhibitions(); break;
    case 'versus':           renderVersus(); break;
    case 'daily':            renderDaily(); break;
    case 'onboarding':       renderOnboarding(); break;
    default:                 renderToday();
  }

  // The tab bar lives outside the #app, so we render it once and update its active state.
  renderTabBar();
  // Hydrate any Met images on the page
  hydrateAllMetImages();
  // Scroll to top on navigation
  window.scrollTo(0, 0);
}

/**
 * Start a lesson by ID. Exposed from app.js so views can call it without
 * importing the engine directly (cleaner dependency graph).
 */
export function startLesson(lessonId) {
  currentView = 'lesson';
  startLessonImpl(lessonId);
  renderTabBar();
}

export function startReview() {
  currentView = 'lesson';
  startReviewImpl();
  renderTabBar();
}

/**
 * Render the bottom tab bar. Hidden during lessons and onboarding.
 */
function renderTabBar() {
  let bar = document.getElementById('tab-bar');
  const showBar = ['today', 'learn', 'collection', 'exhibitions', 'final-exhibitions', 'versus', 'profile'].includes(currentView);

  if (!showBar) {
    if (bar) bar.remove();
    return;
  }

  const html = `
    <nav class="tab-bar" id="tab-bar" role="tablist">
      ${tabItem('today',      'Today',      tabIcon('today'))}
      ${tabItem('learn',      'Learn',      tabIcon('learn'))}
      ${tabItem('collection', 'Collection', tabIcon('collection'))}
      ${tabItem('profile',    'Profile',    tabIcon('profile'))}
    </nav>
  `;

  if (!bar) {
    document.body.insertAdjacentHTML('beforeend', html);
    bar = document.getElementById('tab-bar');
    // Wire up clicks once
    bar.querySelectorAll('.tab-bar__item').forEach(btn => {
      btn.addEventListener('click', () => navigate(btn.dataset.view));
    });
  } else {
    // Just update active state
    bar.querySelectorAll('.tab-bar__item').forEach(btn => {
      btn.classList.toggle('is-active', btn.dataset.view === currentView);
    });
  }
}

function tabItem(id, label, iconSvg) {
  return `
    <button class="tab-bar__item ${currentView === id ? 'is-active' : ''}" data-view="${id}" role="tab" aria-label="${label}">
      ${iconSvg}
      <span>${label}</span>
    </button>
  `;
}

/**
 * Inline SVG icons for the tab bar.
 * Drawn fresh rather than imported to keep the bundle tiny.
 */
function tabIcon(name) {
  const stroke = `class="tab-bar__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"`;
  switch (name) {
    case 'today':
      return `<svg ${stroke}><path d="M3 18h18M5 14l7-7 7 7M9 18v-3M15 18v-3"/></svg>`;
    case 'learn':
      return `<svg ${stroke}><path d="M4 5v14a2 2 0 002 2h5V7a2 2 0 00-2-2H4zM20 5v14a2 2 0 01-2 2h-5V7a2 2 0 012-2h5z"/></svg>`;
    case 'exhibitions':
      // Archway / museum columns
      return `<svg ${stroke}><path d="M3 21h18M5 21V10M19 21V10M12 3L3 10h18L12 3zM9 21v-5a3 3 0 016 0v5"/></svg>`;
    case 'finals':
      // Medallion / award ribbon
      return `<svg ${stroke}><circle cx="12" cy="9" r="5"/><path d="M8.5 14.5L7 21l5-2 5 2-1.5-6.5"/></svg>`;
    case 'versus':
      // Crossed swords / VS lightning
      return `<svg ${stroke}><path d="M13 3l4 4-9 9-4-4 9-9zM3 21l4-4M15 9l3 3"/><path d="M19 3l-4 4M5 19l4-4"/></svg>`;
    case 'collection':
      return `<svg ${stroke}><circle cx="6" cy="7" r="1.5"/><circle cx="18" cy="9" r="1.5"/><circle cx="12" cy="17" r="1.5"/><path d="M7 8l10 1M17 10l-5 6M7 8l5 9"/></svg>`;
    case 'profile':
      return `<svg ${stroke}><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/></svg>`;
    default:
      return '';
  }
}

/**
 * Decide what to show on first load.
 * - Brand-new user: onboarding.
 * - Returning user: today.
 */
function decideStartView() {
  const state = getState();
  if (!state.hasCompletedIntro || !state.hasCompletedWalkthrough) {
    return 'onboarding';
  }
  return 'today';
}

/* ===== BOOT SEQUENCE ===== */
async function boot() {
  try {
    // 1. Load persisted state from localStorage
    loadState();
    // 2. Tick the session counter (once per app open, drives SRS)
    tickSession();
    // 3. Load all bundled content (small JSON files)
    await loadContent();
    // 4. Initialize sync (fires & forgets — works without it)
    initSync().catch(err => console.warn('Sync init error:', err));
    // 5. Route to first view
    navigate(decideStartView());
  } catch (err) {
    // Visible error message so the user sees what went wrong even on mobile
    const app = document.getElementById('app');
    if (app) {
      app.innerHTML = `
        <div style="padding: 24px; font-family: -apple-system, sans-serif; color: #1F1B16; line-height: 1.5;">
          <h2 style="font-family: 'DM Serif Display', Georgia, serif; color: #8B1538;">Boot error</h2>
          <p>${(err && err.message) ? err.message : String(err)}</p>
          <pre style="background: #FBF7EE; padding: 12px; font-size: 11px; overflow: auto; border-radius: 6px;">${(err && err.stack) ? err.stack : ''}</pre>
        </div>
      `;
    }
    console.error('Boot error:', err);
  }
}

// Kick off when the DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}

// Global error overlay so we can see what's happening even on mobile
window.addEventListener('error', (event) => {
  const existing = document.getElementById('error-overlay');
  if (existing) return; // only show first error
  const overlay = document.createElement('div');
  overlay.id = 'error-overlay';
  overlay.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#8B1538;color:#FBF7EE;padding:12px;font-family:-apple-system,sans-serif;font-size:12px;z-index:9999;max-height:50vh;overflow:auto;';
  overlay.innerHTML = `<strong>JS error:</strong> ${event.message || 'Unknown'}<br>
    <small>${event.filename || ''}:${event.lineno || ''}:${event.colno || ''}</small>
    <button style="float:right;background:#FBF7EE;color:#8B1538;border:none;padding:4px 8px;border-radius:4px;font-weight:bold;" onclick="this.parentElement.remove()">×</button>`;
  document.body.appendChild(overlay);
});
