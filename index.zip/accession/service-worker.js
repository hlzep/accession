/* ============================================================
   ACCESSION - SERVICE WORKER
   Cache-first strategy for the app shell, network-first for data.
   Lets the app open offline once it has been visited once.
   ============================================================ */

const VERSION = 'accession-v1';

// Files that make up the app shell.
const SHELL = [
  'index.html',
  'manifest.json',
  'css/tokens.css',
  'css/base.css',
  'css/components.css',
  'css/views.css',
  'js/app.js',
  'js/core/state.js',
  'js/core/content.js',
  'js/core/progression.js',
  'js/core/sync.js',
  'js/core/metApi.js',
  'js/core/placard.js',
  'js/lessons/engine.js',
  'js/views/today.js',
  'js/views/learn.js',
  'js/views/collection.js',
  'js/views/profile.js',
  'js/views/onboarding.js',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(VERSION).then(cache => cache.addAll(SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  // Clear old caches
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  // Skip Firebase and other network-only requests
  if (url.hostname.includes('firebaseio.com') || url.hostname.includes('gstatic.com')) {
    return;
  }
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        // Cache successful responses
        if (response.ok && url.origin === location.origin) {
          const clone = response.clone();
          caches.open(VERSION).then(cache => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => cached);
    })
  );
});
